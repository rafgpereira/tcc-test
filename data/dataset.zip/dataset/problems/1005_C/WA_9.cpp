#include <bits/stdc++.h>
using namespace std;
multiset<int> v;
long long a[200000];
int n;
set<long long> s;
int Search(long long x) {
  int s = 0, e = n - 1;
  while (s <= e) {
    int mid = (s + e) / 2;
    if (x == a[mid]) {
      return mid;
    } else if (x > a[mid])
      s = mid + 1;
    else
      e = mid - 1;
  }
  return -1;
}
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  ;
  long long i;
  cin >> n;
  for (i = 0; i < n; i++) cin >> a[i];
  sort(a, a + n);
  for (i = 1; i <= (2 * 1e9 + 1); i *= 2) s.insert(i);
  long long co = 0;
  for (i = 0; i < n; i++) {
    if (*v.begin() == i && v.size()) {
      v.erase(*v.begin());
      continue;
    }
    long long t = a[i];
    a[i] = -1e10;
    bool b = 0;
    for (auto x : s) {
      int ind = Search(x - t);
      if (ind == -1)
        continue;
      else {
        b = 1;
        v.insert(ind);
      }
    }
    if (!b)
      co++;
    else
      a[i] = t;
  }
  cout << co;
  return 0;
}
