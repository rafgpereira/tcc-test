#include <bits/stdc++.h>
using namespace std;
bool func(long long n) {
  if (ceil(log2(n)) == floor(log2(n)))
    return true;
  else
    false;
}
int main() {
  int n, i, *a;
  vector<long long> num;
  long long x;
  cin >> n;
  a = (int *)malloc(sizeof(int) * n);
  for (i = 0; i < n; i++) {
    cin >> x;
    num.push_back(x);
    a[i] = 0;
  }
  if (n == 0) {
    cout << "0\n";
    return 0;
  }
  if (n == 1) {
    cout << "1\n";
    return 0;
  }
  for (i = 0; i < num.size(); i++) {
    for (int j = 0; j < num.size(); j++) {
      if (j != i) {
        if (!func(num[i] + num[j])) a[i]++;
      }
    }
  }
  int ans = 0;
  for (i = 0; i < num.size(); i++) {
    if (a[i] == (n - 1)) ans++;
  }
  cout << ans << endl;
  return 0;
}
