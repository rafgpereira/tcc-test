#include <bits/stdc++.h>
using namespace std;
long long int max(long long int a, long long int b) {
  if (a < b) swap(a, b);
  return a;
}
long long int min(long long int a, long long int b) {
  if (a >= b) swap(a, b);
  return a;
}
long long int sqr(long long int p) { return p * p; }
long long int mohit(long long int a, long long int b) { return (a + b) * 2; }
long long int masahat(long long int a, long long int b) { return a * b; }
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  set<long long int> s;
  long long int n, a, x[200005], c = 0, i, j, sum = 0;
  map<long long int, long long int> map, good;
  cin >> n;
  for (i = 0; i <= 34; i++) s.insert(pow(2, i));
  for (i = 1; i <= n; i++) {
    cin >> a;
    if (!map[a]) x[++c] = a;
    map[a] += 1;
  }
  if (n == 1)
    return cout << 1, 0;
  else {
    for (i = 1; i < c; i++) {
      for (j = i + 1; j <= c; j++) {
        if (s.find(x[i] + x[j]) != s.end()) {
          good[i] = 1;
          good[j] = 1;
        }
      }
    next:
      if (!good[i] && !(s.find(x[i]) != s.end() && map[x[i]] >= 2))
        sum += map[x[i]];
    }
  }
  cout << sum;
  return 0;
}
