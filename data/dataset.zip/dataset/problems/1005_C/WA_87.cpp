#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, ans = 0;
  cin >> n;
  long long a[n];
  for (int i = int(0); i <= int(n - 1); i++) cin >> a[i];
  sort(a, a + n);
  for (int i = int(0); i <= int(n - 1); i++) {
    for (int j = int(1); j <= int(30); j++) {
      if (a[i] < (1 << j)) {
        long long val = (1 << j) - a[i];
        int left = 0, right = n - 1, f = 0;
        while (left <= right) {
          int mid = (left + right) / 2;
          if (mid != i && a[mid] == val) {
            f = 1;
            break;
          } else if (a[mid] < val)
            left = mid + 1;
          else
            right = mid - 1;
        }
        if (f == 1) {
          ans++;
          break;
        }
      }
    }
  }
  cout << n - ans << endl;
}
