#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  if (n == 0) {
    cout << 0;
    return 0;
  }
  int i;
  vector<int> v(n);
  for (i = 0; i < n; i++) {
    cin >> v[i];
  }
  sort(v.begin(), v.end());
  int j;
  int ct = 0;
  int temp, temp2, temp3;
  bool found = false;
  for (i = 0; i < n; i++) {
    temp3 = v[i];
    if (i < n)
      temp2 = v[i + 1];
    else
      temp2 = v[n - 1] + 1;
    for (j = 0; j < 32; j++) {
      found = false;
      if (1 << j > v[i]) {
        temp = (1 << j) - v[i];
        v[i] = temp2;
        ;
        if (binary_search(v.begin(), v.end(), temp)) {
          found = true;
          break;
        }
        v[i] = temp3;
      }
    }
    v[i] = temp3;
    if (!found) {
      ct++;
    }
  }
  cout << ct;
}
