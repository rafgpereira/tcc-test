#include <bits/stdc++.h>
using namespace std;
long long p[35];
const int N = 120005;
long long a[N];
bool vis[N];
bool check(long long x) {
  for (int i = 1; i <= 31; i++)
    if (x == p[i]) return true;
  return false;
}
int main() {
  for (int i = 1; i <= 31; i++) p[i] = pow(2, i);
  int n;
  cin >> n;
  for (int i = 1; i <= n; i++) cin >> a[i];
  for (int i = 1; i <= n; i++) {
    if (vis[i] == true) continue;
    for (int j = i + 1; j <= n; j++)
      if (check(a[i] + a[j])) {
        vis[i] = true;
        vis[j] = true;
      }
  }
  int sum = 0;
  for (int i = 1; i <= n; i++)
    if (vis[i] == false) sum++;
  cout << sum;
  return 0;
}
