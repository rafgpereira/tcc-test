#include <bits/stdc++.h>
using namespace std;
long long a[120005];
long long p[30];
map<long long, long long> m;
int main() {
  long long n, ans = 0;
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cin >> n;
  p[0] = 1;
  p[1] = 2;
  for (long long i = 2; i <= 30; i++) {
    p[i] = 2 * p[i - 1];
  }
  if (n == 0)
    cout << 0 << endl;
  else {
    for (long long i = 1; i <= n; i++) {
      cin >> a[i];
      m[a[i]]++;
    }
    if (n == 1 && a[1] != 0)
      cout << 1 << endl;
    else {
      long long flg;
      for (long long i = 1; i <= n; i++) {
        flg = 0;
        for (long long j = 0; j <= 30; j++) {
          if (m[p[j] - a[i]] != 0 &&
              ((p[j] - a[i] != a[i]) || m[p[j] - a[i]] > 1)) {
            flg = 1;
            break;
          }
        }
        if (flg == 0) ans++;
      }
      cout << ans << endl;
    }
  }
  return 0;
}
