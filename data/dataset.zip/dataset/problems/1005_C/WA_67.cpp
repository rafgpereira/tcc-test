#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, x;
  cin >> n;
  multiset<int> mt;
  for (int i = 0; i < n; i++) {
    cin >> x;
    mt.insert(x);
  }
  int a[31];
  for (int i = 1; i <= 31; i++) a[i - 1] = pow(2, i);
  int cnt = 0;
  for (auto it = mt.begin(); it != mt.end(); it++) {
    bool flag = false;
    for (int i = 0; i < 31; i++) {
      if (mt.find(a[i] - *it) != mt.end() && mt.find(a[i] - *it) != it) {
        flag = true;
        break;
      }
    }
    if (flag == false) cnt++;
  }
  cout << cnt;
  return 0;
}
