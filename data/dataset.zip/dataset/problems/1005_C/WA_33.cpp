#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, rem = 0, j, i;
  cin >> n;
  int arr[n];
  for (i = 0; i < n; i++) cin >> arr[i];
  for (i = 0; i < n; i++) {
    for (j = 0; j < n && arr[j] > 0; j++) {
      if (i == j) continue;
      int sum = arr[i] + arr[j];
      if (__builtin_popcount(sum) == 1) break;
    }
    if (j == n) {
      arr[i] = 0;
      rem++;
    }
  }
  cout << rem;
  return 0;
}
