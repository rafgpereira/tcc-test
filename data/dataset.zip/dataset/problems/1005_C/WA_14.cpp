#include <bits/stdc++.h>
using namespace std;
const long long MOD = 1e9;
const long long N = 1e5 + 1;
const long long MAXN = 5e5 + 1;
const long long INF = 1e9;
set<int> p;
void fix() {
  p.insert(1);
  int y;
  for (y = 1; pow(2, y) <= INF; y++) {
    p.insert(pow(2, y));
  }
}
int n, a[120005];
void SOLUTION() {
  int res = 0;
  cin >> n;
  for (long long i = 1; i <= n; i++) {
    cin >> a[i];
  }
  for (long long i = 1; i <= n; i++) {
    int t = 0, x = 1;
    while (x < a[i]) {
      t++;
      x = pow(2, t);
    }
    if (!p.count(x - a[i])) res++;
  }
  cout << res;
}
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  ;
  fix();
  SOLUTION();
  return 0;
}
