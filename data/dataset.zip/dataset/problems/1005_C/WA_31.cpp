#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  long long t, n, i, j, m, k, c = 0;
  cin >> n;
  map<long long, long long> mp;
  vector<long long> vc, vc2;
  for (int i = 1; i < 1000000010; i *= 2) vc2.push_back(i);
  for (int i = 0; i < n; i++) {
    cin >> m;
    if (mp[m] == 0) {
      vc.push_back(m);
    }
    mp[m]++;
  }
  for (long long i = 0; i < vc.size(); i++) {
    long long f = 0;
    for (long long j = 0; j < vc2.size(); j++) {
      if (mp[vc2[j] - vc[i]]) {
        if (((vc2[j] - vc[i]) == vc[i]) && mp[vc[i]] == 1) continue;
        f = 1;
        break;
      }
    }
    if (f == 0) c++;
  }
  cout << c << endl;
  return 0;
}
