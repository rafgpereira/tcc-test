#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  long long n, i = 1, ans = 0;
  cin >> n;
  map<long long, long long> mp1, mp2;
  for (i = 1; i <= 100000000000; i = i * 2) {
    mp1[i] = 1;
  }
  for (i = 0; i < n; i++) {
    long long x;
    cin >> x;
    mp2[x]++;
  }
  for (auto it = mp2.begin(); it != mp2.end(); it++) {
    long long x = it->first;
    long long flag = false;
    for (auto it1 = mp1.begin(); it1 != mp1.end(); it1++) {
      long long y = (it1->first) - x;
      if (x == y && y > 0) {
        if (mp2[x] >= 2) {
          flag = true;
        }
      } else if (y > 0) {
        auto it3 = mp2.find(y);
        if (it3 != mp2.end()) {
          flag = true;
        }
      }
      if (flag) break;
    }
    if (!flag) {
      ans++;
    }
  }
  cout << ans << endl;
  return 0;
}
