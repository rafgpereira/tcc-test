#include <bits/stdc++.h>
using namespace std;
const int N = (int)2e5 + 5;
const int INF = (int)1e9 + 7;
int dx[8] = {1, 0, -1, 0, -1, -1, 1, 1};
int dy[8] = {0, 1, 0, -1, -1, 1, -1, 1};
int ini() {
  int x;
  scanf("%d", &x);
  return x;
}
long long inl() {
  long long x;
  scanf("%lld", &x);
  return x;
}
int a[100009], b[200009];
map<int, int> m;
map<int, bool> vis;
int main() {
  int n, i, j;
  for (i = 0; i < 31; i++) {
    a[i] = 2 << i;
  }
  n = ini();
  for (i = 1; i <= n; i++) {
    cin >> b[i];
    vis[b[i]] = true;
    int k = log2(b[i]);
    if (2 << k - 1 == b[i]) {
      if (m[b[i]] == 1)
        m[b[i]] = 2;
      else {
        m[b[i]] = 1;
      }
    }
  }
  int res = 0;
  for (i = 1; i <= n; i++) {
    int k = log2(b[i]);
    if (2 << k - 1 == b[i]) {
      if (m[b[i]]) {
        res++;
      }
    } else {
      for (j = 0; j < 18; j++) {
        if (a[j] >= b[i]) {
          int r = a[j] - b[i];
          if (vis[r]) {
            res++;
            break;
          }
        }
      }
    }
  }
  cout << n - res << endl;
  return 0;
}
