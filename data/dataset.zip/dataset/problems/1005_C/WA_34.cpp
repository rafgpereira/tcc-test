#include <bits/stdc++.h>
using namespace std;
int main(int argc, char const *argv[]) {
  long long n;
  cin >> n;
  vector<long long> arr;
  for (int i = 0; i < n; ++i) {
    long long x;
    cin >> x;
    arr.push_back(x);
  }
  sort(arr.begin(), arr.end());
  long long cnt = 0, max_ele = arr[n - 1];
  for (int i = 0; i < n - 1; ++i) {
    double x = log2(arr[i]);
    long long ind;
    x = x + 1;
    x = floor(x);
    if (pow(2, x) > arr[i] + max_ele)
      cnt++;
    else {
      while (1) {
        long long diff = pow(2, x) - arr[i];
        ind = find(arr.begin(), arr.end(), diff) - arr.begin();
        if (ind >= arr.size()) {
          x = x + 1;
          if (pow(2, x) > arr[i] + max_ele) {
            cnt++;
            break;
          }
        } else {
          if (ind == i && i < n - 1) {
            if (arr[i + 1] != arr[i]) {
              x = x + 1;
              if (pow(2, x) > arr[i] + max_ele) {
                cnt++;
                break;
              }
              continue;
            } else
              break;
          } else
            break;
        }
      }
    }
  }
  cout << cnt << endl;
  return 0;
}
