#include <bits/stdc++.h>
using namespace std;
using ll = long long;
ll power(ll x, ll y) {
  ll res = 1;
  x %= 1000000000000000007;
  while (y > 0) {
    if (y & 1) res = (res * x) % 1000000000000000007;
    y = y >> 1, x = (x * x) % 1000000000000000007;
  }
  return res;
}
const int k = 35;
vector<ll> arr;
void calcpower() {
  for (ll i = 0; i < k; i++) {
    arr.push_back(power(2, i));
  }
}
void show() {
  for (auto k : arr) cout << k << " ";
}
bool ok(ll h) {
  for (ll i = 0; i < k; i++) {
    if (arr[i] == h) return true;
  }
  return false;
}
int main() {
  ll t;
  t = 1;
  while (t--) {
    ll n;
    cin >> n;
    ll a[n];
    calcpower();
    show();
    for (ll i = 0; i < n; i++) cin >> a[i];
    vector<bool> v(n, false);
    for (ll i = 0; i < n; i++) {
      if (v[i] == false)
        for (ll j = 0; j < n; j++) {
          if (j == i) continue;
          if (ok(a[i] + a[j]) == true and (v[i] == false || v[j] == false)) {
            v[i] = true;
            v[j] = true;
          }
        }
    }
    ll cnt = 0;
    for (ll i = 0; i < ll((v).size()); i++) {
      if (v[i] == false) cnt++;
    }
    cout << cnt;
  }
}
