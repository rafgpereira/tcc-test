#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  int a[n];
  map<int, int> c;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    c[a[i]]++;
  }
  int ans = 0;
  bool f = false;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < 31; j++) {
      int x = pow(2, j) - a[i];
      if (c.count(x) != 0 && (c[x] > 1 || (c[x] == 1 && (x != a[i])))) f = true;
    }
    if (f == true) ans++;
  }
  cout << ans << endl;
}
