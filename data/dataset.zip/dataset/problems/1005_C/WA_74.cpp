#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n;
  cin >> n;
  vector<long long> a(n);
  vector<long long> v;
  map<long long, long long> c;
  v.push_back(0);
  long long r = 2;
  for (long long i = 1; i < 31; i++) {
    r *= 2;
    v.push_back(r);
  }
  for (long long i = 0; i < n; i++) {
    cin >> a[i];
    c[a[i]]++;
  }
  long long flag = 0, ans = 0, x;
  for (long long i = 0; i < n; i++) {
    flag = 0;
    for (long long j = 0; j < 31; j++) {
      if (a[i] < v[j]) {
        x = v[j] - a[i];
        if (c.count(x) && (c[x] > 1 || (c[x] == 1 && x != a[i]))) {
          flag = 1;
          break;
        }
      }
    }
    if (flag == 0) {
      ans++;
    }
  }
  cout << ans << '\n';
}
