#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n;
  cin >> n;
  int a[n];
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  map<int, int> m;
  set<int> s;
  for (int i = 0; i < n; i++) {
    m[a[i]]++;
    s.insert(a[i]);
  }
  long long int k = 1;
  vector<long long int> v;
  for (int i = 1; i < 32; i++) {
    k = k * 2;
    v.push_back(k);
  }
  set<int>::iterator it;
  long long int ans = 0;
  for (std::set<int>::iterator it = s.begin(); it != s.end(); ++it) {
    long long int j = *it;
    bool f = false;
    for (int i = 0; i < v.size(); i++) {
      long long int sum = v[i] - j;
      if (sum > 0) {
        if (sum == j) {
          if (m[sum] > 1) {
            f = true;
            break;
          }
        } else if (sum != j) {
          if (m.find(sum) != m.end()) {
            f = true;
            break;
          }
        }
      }
    }
    if (f == false) {
      ans++;
    }
  }
  cout << ans << '\n';
}
