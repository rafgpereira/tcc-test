#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  vector<long long int> seq;
  cin >> n;
  while (n--) {
    long long int temp;
    cin >> temp;
    seq.emplace_back(temp);
  }
  map<long long int, bool> m;
  long long int ans = 0;
  for (int i = 0; i < seq.size(); i++) {
    if (m.find(seq[i]) == m.end()) {
      bool flag = false;
      map<long long int, bool> tempMap;
      for (int j = 0; j < seq.size(); j++) {
        if (i != j && (tempMap.find(seq[j]) == tempMap.end()) &&
            ((seq[i] + seq[j]) & (seq[i] + seq[j] - 1)) == 0) {
          m[seq[j]] = true;
          m[seq[i]] = true;
          flag = true;
          break;
        } else
          tempMap[seq[j]] = true;
      }
      if (!flag) ans++;
    }
  }
  cout << ans;
  return 0;
}
