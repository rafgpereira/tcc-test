#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 2 * 1e4 + 1;
int a[N], step[N];
int n;
map<int, int> mp;
int ans;
int main() {
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    mp[a[i]]++;
  }
  sort(a, a + n);
  step[0] = 1;
  for (int i = 1; i <= 21; i++) step[i] = step[i - 1] * 2;
  for (int i = 0; i < n; i++) {
    int k = a[i];
    int r = 20, l = 0, m;
    while (r - l > 1) {
      m = (r + l) >> 1;
      if (step[m] > m)
        r = m;
      else
        l = m;
    }
    for (int j = r; j <= 20; j++)
      if (binary_search(a, a + n, step[j] - k)) {
        if (step[j] - k == k && mp[k] > 1) {
          ans++;
        } else if (step[j] - k != k) {
          ans++;
          break;
        }
      }
  }
  cout << max(n - ans, 0);
}
