#include <bits/stdc++.h>
using namespace std;
int binary_search(long long s, vector<long long> &arr, int l, int r) {
  if (l > r) {
    return -1;
  }
  int mid = l + (r - l) / 2;
  if (arr[mid] == s) {
    return mid;
  } else if (s < arr[mid]) {
    return binary_search(s, arr, l, mid - 1);
  } else {
    return binary_search(s, arr, mid + 1, r);
  }
}
int main() {
  vector<long long> pw(31);
  for (int i = 0; i < 31; i++) {
    pw[i] = (long long)1 << (long long)i;
  }
  int n;
  cin >> n;
  vector<long long> arr(n);
  vector<long long> status(n, 0);
  map<long long, long long> mp;
  for (int i = 0; i < n; i++) {
    cin >> arr[i];
    mp[arr[i]]++;
  }
  int ans = 0;
  for (int i = 0; i < n; i++) {
    bool flag = false;
    for (int j = 1; j < 31; j++) {
      long long req = pw[j] - arr[i];
      if (req == arr[i]) {
        if (mp[arr[i]] >= 2) {
          flag = true;
          break;
        }
      } else {
        if (mp.find(req) != mp.end()) {
          flag = true;
          break;
        }
      }
    }
    if (!flag) {
      ans = ans + mp[arr[i]];
    }
  }
  cout << ans << "\n";
  return 0;
}
