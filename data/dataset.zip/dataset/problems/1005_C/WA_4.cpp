#include <bits/stdc++.h>
using namespace std;
const int mod = 1e9 + 7;
const int N = (int)1e5 + 5;
bool isPowerOfTwo(long long int n) {
  if (n == 0) return 0;
  while (n != 1) {
    if (n % 2 != 0) return 0;
    n = n / 2;
  }
  return 1;
}
int main() {
  ios_base::sync_with_stdio(false), cin.tie(NULL);
  long long int n, v;
  bool flag = false;
  cin >> n;
  int a[n];
  long long int cnt = 0, ok = 0;
  for (long long int i = 0; i < n; i++) cin >> a[i];
  if (n == 1) {
    if (isPowerOfTwo(a[0])) {
      cout << "0" << endl;
      return 0;
    } else {
      cout << "1" << endl;
      return 0;
    }
  }
  for (long long int i = 0; i < n; i++) {
    for (long long int j = 0; j < n; j++) {
      if (i != j) {
        v = a[i] + a[j];
        if (isPowerOfTwo(v)) {
          ok++;
        }
      }
    }
    if (ok == 0) {
      cnt++;
    }
    ok = 0;
  }
  cout << cnt;
  return 0;
}
