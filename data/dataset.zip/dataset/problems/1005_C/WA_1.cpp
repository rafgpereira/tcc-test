#include <bits/stdc++.h>
using namespace std;
long long aD[32];
map<int, int> mp;
map<int, int>::iterator it;
int main() {
  int k = -1, sum = 0, n, b;
  for (long long i = 1; i <= (long long)0x7f7f7f7f * 2; i *= 2) aD[++k] = i;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> b;
    mp[b]++;
  }
  for (it = mp.begin(); it != mp.end(); it++) {
    if (it->second > 0)
      for (int i = 0; i <= k; i++) {
        int t = aD[i] - it->first;
        if (t > 0) {
          if (it->second > 1 || !mp[t]) {
            sum++;
            break;
          }
        }
      }
  }
  for (it = mp.begin(); it != mp.end(); it++)
    cout << it->first << ":" << it->second << endl;
  cout << n - sum << endl;
  return 0;
}
