#include <bits/stdc++.h>
using namespace std;
int b[32], i, j, ans;
int main() {
  b[0] = 1;
  for (i = 1; i <= 30; i++) {
    b[i] = b[i - 1] * 2;
  }
  int n;
  cin >> n;
  int a[n + 1];
  for (i = 1; i <= n; i++) cin >> a[i];
  sort(a + 1, a + n + 1);
  for (i = 1; i <= n; i++) {
    bool flag = false;
    int p;
    for (p = 1; p <= 30; p++)
      if (p > a[i]) break;
    for (j = p; j <= 30; j++) {
      if (binary_search(a + i + 1, a + n + 1, b[j] - a[i])) {
        flag = true;
        break;
      }
    }
    if (flag == false) {
      ans++;
    }
  }
  cout << ans << endl;
  return 0;
}
