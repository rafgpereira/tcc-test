#include <bits/stdc++.h>
using namespace std;
int main() {
  vector<int> v;
  long long int n, x, flg = 1;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> x;
    v.push_back(x);
  }
  int cnt = 0;
  for (int i = 0; i < v.size(); i++) {
    if (v[i] == 0) continue;
    for (int j = i + 1; j < v.size(); j++) {
      if (v[j] == 0) continue;
      long long int tst = v[i] + v[j];
      if ((tst & (tst - 1)) == 0) {
        flg = 0;
        v[j] = 0;
      }
    }
    if (flg) {
      cnt++;
    } else
      flg = 1;
  }
  cout << cnt << endl;
  return 0;
}
