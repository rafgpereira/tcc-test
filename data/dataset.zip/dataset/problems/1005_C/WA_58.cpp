#include <bits/stdc++.h>
using namespace std;
int i, j, k, n, rez, l;
int v[120009];
int w[120009];
bool t[120009];
bool sum(int x) {
  int y = 1;
  while (y < x) y *= 2;
  return y == x;
}
int main() {
  cin >> n;
  for (i = 1; i <= n; i++) cin >> v[i];
  sort(v + 1, v + n + 1);
  i = 1;
  j = 1;
  while (j <= n) {
    l = 1;
    j++;
    while (v[j] == v[i]) {
      l++;
      j++;
    }
    w[i] = l;
    i++;
    v[i] = v[j];
  }
  for (j = 1; j < i; j++) {
    for (k = j + 1; k < i; k++) {
      if (sum(v[j] + v[k])) {
        t[j] = true;
        t[k] = true;
      }
    }
  }
  for (j = 1; j < i; j++) {
    if (t[j]) rez += w[j];
  }
  cout << n - rez;
  return 0;
}
