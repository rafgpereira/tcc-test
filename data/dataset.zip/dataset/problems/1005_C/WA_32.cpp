#include <bits/stdc++.h>
using namespace std;
const long long int M = 12e4 + 8;
long long int arr[M];
bool f[M];
int n;
int search(int i, long long int x) {
  int l = i + 1, r = n, mid, p = -1;
  while (l < r) {
    mid = (l + r) / 2;
    if (mid == p) mid++;
    p = mid;
    if (arr[mid] == x) return mid;
    if (arr[mid] > x)
      r = mid - 1;
    else
      l = mid + 1;
  }
  return -1;
}
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  int i, j, ans = 0;
  arr[0] = -1;
  arr[n + 1] = -1;
  cin >> n;
  for (i = 1; i <= n; i++) cin >> arr[i];
  sort(arr + 1, arr + 1 + n);
  bool fl = 0;
  for (i = 1; i <= n; i++) {
    if (f[i]) continue;
    long long int val = 1;
    fl = 0;
    for (j = 0; j < 31; j++) {
      val = val * 2;
      if (val > arr[i]) {
        if (val - arr[i] <= arr[n]) {
          int x = search(0, val - arr[i]);
          if (x != -1) {
            if (x == i) {
              if (arr[i + 1] == arr[i] || arr[i] == arr[i - 1]) fl = 1;
            } else {
              f[x] = 1;
              fl = 1;
            }
          }
        }
      }
      if (fl == 1) break;
    }
    if (fl == 0) ans++;
  }
  cout << ans << endl;
}
