#include <bits/stdc++.h>
using namespace std;
int n;
long long A[120005];
int Check[120005];
long long F[35];
long long x;
int l, r, mid;
int res = 0;
int BNS(int left, int right, long long key) {
  l = left + 1;
  r = right;
  while (l <= r) {
    mid = (l + r) / 2;
    if (A[mid] == key) {
      for (int i = mid; i >= l; i--) {
        if (A[i] == A[mid]) {
          Check[i] = 1;
        } else {
          break;
        }
      }
      for (int i = mid; i <= r; i++) {
        if (A[i] == A[mid]) {
          Check[i] = 1;
        } else {
          break;
        }
      }
      return mid;
    } else if (A[mid] > key) {
      r = mid - 1;
    } else {
      l = mid + 1;
    }
  }
  return 0;
}
int main() {
  cin >> n;
  for (int i = 1; i <= n; i++) {
    cin >> A[i];
  }
  F[0] = 1;
  sort(A + 1, A + n + 1);
  for (int i = 1; i <= 29; i++) {
    F[i] = F[i - 1] * 2;
  }
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j <= n; j++) {
      if (F[j] > A[i]) {
        x = F[j] - A[i];
        int k = BNS(i, n, x);
        if (k != 0) {
          Check[i] = 1;
          break;
        }
      }
    }
    if (Check[i] == 0) res++;
  }
  cout << res;
  return 0;
}
