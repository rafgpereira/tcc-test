#include <bits/stdc++.h>
using namespace std;
long long int maxx(long long int a, long long int b) {
  if (a > b) return a;
  return b;
}
long long int minn(long long int a, long long int b) {
  if (a > b) return b;
  return a;
}
long long int poww(long long int a, long long int b) {
  if (b == 0) return 1;
  if (b == 1) return a;
  return poww(a, b / 2) * poww(a, b / 2) * poww(a, b % 2);
}
long long int gcdd(long long int a, long long int b) {
  if (b == 0)
    return a;
  else
    return gcdd(b, a % b);
}
signed main() {
  ios::sync_with_stdio(false);
  long long int n;
  cin >> n;
  map<long long int, long long int> mp1;
  long long int a[n], ans = 0;
  for (long long int i = 0; i < n; i++) {
    cin >> a[i];
    mp1[a[i]] = 0;
  }
  for (long long int i = 0; i < n; i++) {
    if (mp1[a[i]] == 0) {
      for (long long int j = i + 1; j < n; j++) {
        long long int x = a[i] + a[j], z;
        double y = log(x) / log(2);
        z = log(x) / log(2);
        double b = z;
        if (b == y) {
          mp1[a[j]] = 1;
          mp1[a[i]] = 1;
        }
      }
      if (mp1[a[i]] == 0) mp1[a[i]] = -1;
    }
  }
  for (long long int i = 0; i < n; i++) {
    if (mp1[a[i]] == -1) ans++;
  }
  cout << ans << endl;
}
