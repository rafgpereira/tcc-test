#include <bits/stdc++.h>
using namespace std;
void precompute() {}
void test_case() {
  long long int n;
  cin >> n;
  ;
  map<long long int, long long int> mp;
  vector<long long int> a(n);
  for (long long int i = 0; i < n; i++) {
    long long int x;
    cin >> x;
    ;
    mp[x]++;
    a[i] = x;
  }
  long long int ans = 0;
  for (long long int i = 0; i < n; i++) {
    bool ok = 0;
    for (long long int j = 0; j <= 32; j++) {
      long long int sum = (1 << j);
      if (mp[sum - a[i]]) {
        ok = 1;
        break;
      }
    }
    if (!ok) {
      ans++;
    }
  }
  cout << ans << endl;
}
int32_t main() {
  srand(time(0));
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  precompute();
  long long int T = 1;
  for (long long int TT = 1; TT <= T; TT++) {
    test_case();
  }
  cerr << "Time : "
       << 1000 * ((long double)clock()) / (long double)CLOCKS_PER_SEC << "ms\n";
}
