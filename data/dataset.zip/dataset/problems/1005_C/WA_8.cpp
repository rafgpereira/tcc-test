#include <bits/stdc++.h>
using namespace std;
struct DATA {
  int val;
  bool check;
};
DATA a[120009];
bool sortFunc(DATA a1, DATA a2) { return a1.val < a2.val; }
int binarySearch(int l, int r, int x) {
  if (r >= l) {
    int mid = l + (r - l) / 2;
    if (a[mid].val == x) return mid;
    if (a[mid].val > x) return binarySearch(l, mid - 1, x);
    return binarySearch(mid + 1, r, x);
  }
  return -1;
}
int main() {
  int n, deleteCount = 0;
  cin >> n;
  for (int i = 0; i < n; ++i) {
    cin >> a[i].val;
    a[i].check = false;
  }
  sort(a, a + n, sortFunc);
  for (int i = 0; i < n; ++i) {
    if (a[i].check == false) {
      int temp = a[i].val, count = 0;
      while (temp != 0) {
        temp = temp >> 1;
        ++count;
      }
      int flag = 1;
      while (count <= 30) {
        int val = pow(2, count) - a[i].val;
        int bans = binarySearch(0, n - 1, val);
        if (bans != -1 && i != bans) {
          flag = 0;
          a[i].check = true;
          a[bans].check = true;
          break;
        }
        count++;
      }
      if (flag == 1) {
        deleteCount++;
      }
    }
  }
  cout << deleteCount << endl;
  return 0;
}
