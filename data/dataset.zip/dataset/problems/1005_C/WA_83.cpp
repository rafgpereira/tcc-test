#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n;
  cin >> n;
  vector<long long int> arr;
  long long int x;
  for (int i = 0; i < n; i++) {
    cin >> x;
    arr.push_back(x);
  }
  sort(arr.begin(), arr.end());
  set<long long int> s;
  for (long long int i = 0; i < n - 1; i++) {
    for (long long int k = 0; k < 32; k++) {
      if ((long long int)(1 << k) - arr[i] < 0) continue;
      long long int pos = lower_bound(arr.begin(), arr.end(),
                                      (long long int)(1 << k) - arr[i]) -
                          arr.begin();
      if (arr[pos] == ((long long int)(1 << k) - arr[i]) && (pos != i)) {
        s.insert(i);
        s.insert(pos);
      }
    }
  }
  cout << n - s.size();
  return 0;
}
