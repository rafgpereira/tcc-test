#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  vector<int> a(n);
  for (int i = 0; i < n; i++) cin >> a[i];
  sort(a.begin(), a.end());
  long long maxi = a[n - 1];
  int res = 0;
  bool done = false;
  for (int j = 0; j < n; j++) {
    done = false;
    for (int i = 2; i <= 2 * maxi; i *= 2) {
      if (i >= a[j]) {
        if (i - a[j] == a[j]) {
          if (j > 0 && a[j - 1] == a[j]) {
            done = true;
            break;
          }
          if (j < n - 1 && a[j + 1] == a[j]) {
            done = true;
            break;
          }
        } else if (binary_search(a.begin(), a.end(), i - a[j])) {
          done = true;
          break;
        }
      }
    }
    if (!done) {
      res++;
    }
    while (j < n - 1 && a[j] == a[j + 1]) {
      j++;
    }
  }
  cout << res << endl;
}
