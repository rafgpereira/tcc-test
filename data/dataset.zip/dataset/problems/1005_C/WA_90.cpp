#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
typedef long double ldb;
typedef pair<ll,ll> pll;
typedef vector<ll> vll;
typedef vector<pll> vpll;

#define pb push_back
#define mpr make_pair
#define tc ll testcase; cin>>testcase; while(testcase--)
#define fast_io() ios_base::sync_with_stdio(false); cin.tie(NULL); cout.tie(NULL);
#define trace1(x)                cout <<#x<<":"<<x<< endl;
#define trace2(x, y)             cout <<#x<<":"<<x<<" | "<<#y<<":"<<y<< endl;
#define trace3(x, y, z)          cout <<#x<<":"<<x<<" | "<<#y<<":"<<y<<" | "<<#z<<":"<<z<<endl;
#define trace4(a, b, c, d)       cout <<#a<<":"<<a<<" | "<<#b<<":"<<b<<" | "<<#c<<":"<<c<<" | "<<#d<<":"<<d<<endl;

const ll mod = 1e9+7;
const ldb PI = acos(-1);

ll POWER[65];
void precompute() {POWER[0]=1; for(int i=1;i<63;i++) POWER[i]=POWER[i-1]<<1LL; }
ll power(ll x,ll y,ll mod) {ll res=1; x%=mod; while(y) {if(y&1) res=(res*x)%mod; y>>=1; x=(x*x)%mod; }return res;}
ll inv(ll x,ll mod){return power(x,mod-2,mod);}
ll fastMul(ll a,ll b,ll mod){ll res = 0; a %= mod; while (b){   if (b & 1){res = (res + a) % mod;} a = (2 * a) % mod; b >>= 1;} return res;}

/*
	s.end() --it;
	-_- -.- -_- -.-
    -_--_--_--_- never use ceil function !!!!
    += is faster than = a + b
    x-1 % mod or x%mod - 1 ??
    when you do x-1 and see minimum of two number watch for it !!!
	freopen("testfile.txt", "r", stdin);
	freopen("output.txt", "w", stdout);
*/

int main()
{
    precompute();

    int n;
    cin >> n;

    ll A[n+2]={0};
    ll B[n+2]={0};
    memset(B,0,sizeof(B));
    for(int i=0;i<n;i++)
    {
        cin >> A[i];
    }

    sort(A,A+n);
    for(int i=0;i<n;i++)
    {
        vector<ll> v;
        for(int j=0;j<35;j++) // change
        {
            if(POWER[j] >= A[i])
            {
                ll idx = lower_bound(A,A+n,POWER[j]-A[i])-A;

                if(idx != n)
                {
                for(int k=idx;k<n;k++)
                {
                    if(A[k] == A[idx] && idx != i)
                        B[k] = -1;
                    else if(idx == i)
                        continue;
                    else
                        break;
                }
                }
            }
        }
    }


    ll cnt=0;
    for(int i=0;i<n;i++)
    {
        if(B[i] != -1)
            cnt++;
    }

    cout << cnt <<"\n";
	return 0;
}
