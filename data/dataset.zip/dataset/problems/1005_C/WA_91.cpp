#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  vector<pair<long long, int>> x;
  long long y;
  int t = 0;
  for (int i = 0; i < n; i++) {
    cin >> y;
    x.push_back(pair<long long, int>(y, 0));
  }
  for (int i = 0; i < n; i++) {
    for (int j = i + 1; j < n; j++) {
      int k;
      int m = x[i].first + x[j].first;
      if (x[j].second == 0) {
        for (k = 0; (1 << k) <= m; k++) {
          if (1 << k == m) {
            x[i].second = x[j].second = 1;
            break;
          }
        }
      }
    }
    if (x[i].second == 0) t++;
  }
  cout << t;
}
