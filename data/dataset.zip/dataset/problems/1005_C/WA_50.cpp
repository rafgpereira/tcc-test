#include <bits/stdc++.h>
using namespace std;
#pragma comment(linker, "/STACK:667177216")
const long long mod = 1000000007;
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  int n;
  scanf("%d", &n);
  vector<int> a(n);
  map<int, int> st;
  for (int i = 0; i < n; i++) {
    scanf("%d", &a[i]);
    st[a[i]]++;
  }
  vector<int> pw(31);
  pw[0] = 1;
  for (int i = 1; i <= 30; i++) pw[i] = pw[i - 1] * 2;
  int ans = 0;
  int f = 1;
  for (int i = 0; i < n; i++) {
    f = 1;
    for (int v = 0; v <= 30; v++) {
      if ((pw[v] - a[i]) == a[i]) {
        if (st[a[i]] > 1) {
          f = 0;
          break;
        }
      }
      if (st.count(pw[v] - a[i])) {
        f = 0;
        break;
      }
    }
    ans += f;
  }
  cout << ans;
  return 0;
}
