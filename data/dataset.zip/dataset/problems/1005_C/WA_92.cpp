#include <bits/stdc++.h>
using namespace std;
int main() {
  map<int, int> ada;
  int n;
  int count = 0;
  int arr[120001];
  int dua = 1;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> arr[i];
    ada[arr[i]]++;
  }
  for (int i = 0; i < n; i++) {
    int flag = 0;
    dua = 1;
    for (int j = 0; j < 32; j++) {
      int a = dua - arr[i];
      dua *= 2;
      if (a == arr[i]) {
        if (ada[a] > 1) {
          flag = 1;
          break;
        }
      } else if (ada[a] > 0) {
        flag = 1;
        break;
      }
    }
    if (flag == 0) {
      count += ada[arr[i]];
    }
  }
  cout << count << endl;
  return 0;
}
