#include <bits/stdc++.h>
using namespace std;
int n, a[120010], ans = 0;
int main() {
  scanf("%d", &n);
  for (int i = 0; i < n; i++) scanf("%d", &a[i]);
  sort(a, a + n);
  for (int i = 0; i < n; i++) {
    bool found = false;
    for (int j = 0; j <= 30; j++) {
      int s = (1 << j) - a[i], p = lower_bound(a, a + n, s) - a;
      if (p != n && p != i && a[p] == s) {
        found = true;
        break;
      }
    }
    if (not found) ans++;
  }
  printf("%d", ans);
}
