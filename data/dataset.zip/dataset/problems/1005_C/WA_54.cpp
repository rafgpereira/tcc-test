#include <bits/stdc++.h>
using namespace std;
int a[120000];
map<int, int> book, ob;
map<int, int>::iterator it, it1;
void init() {
  for (int i = 1; i <= 1000000000; i = i * 2) book[i] = 1;
}
int main() {
  init();
  int n, sum = 0, fa = 0;
  scanf("%d", &n);
  for (int i = 0; i < n; i++) scanf("%d", &a[i]);
  for (int i = 0; i < n; i++) {
    it1 = ob.find(a[i]);
    if (it1 != ob.end()) continue;
    for (int j = i + 1; j < n; j++) {
      int s = a[i] + a[j];
      it = book.find(s);
      if (it != book.end()) {
        ob[a[i]] = 1;
        ob[a[j]] = 1;
        fa = 1;
      }
    }
    if (fa == 0) sum++;
    fa = 0;
  }
  printf("%d\n", sum);
}
