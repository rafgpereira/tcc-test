#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false), cin.tie(0), cout.tie(0);
  srand(time(NULL));
  long long n;
  cin >> n;
  long long a[n];
  map<long long, long long> s;
  for (long long i = 0; i < n; i++) {
    cin >> a[i];
    s[a[i]]++;
  }
  long long p[35];
  p[0] = 1;
  for (long long i = 1; i < 35; i++) {
    p[i] = p[i - 1] * 2;
  }
  long long ans = 0;
  for (long long i = 0; i < n; i++) {
    bool f = false;
    for (long long j = 0; j < 35; j++) {
      long long t = p[j] - a[i];
      if ((t == a[i] && s[t] >= 2) || s[t]) {
        f = true;
        break;
      }
    }
    if (f == false) ans++;
  }
  cout << ans;
  return 0;
}
