#include <bits/stdc++.h>
using namespace std;
const int N = 120000 + 10;
int arr1[N];
int arr2[N];
int arr[35];
int ar[N];
map<int, int> mp;
map<int, pair<int, int> > mp1;
int main() {
  for (int i = 1; i <= 33; i++) arr[i] = pow(2, i);
  int n, cnt = 0;
  scanf("%d", &n);
  for (int i = 1; i <= n; i++) {
    int x;
    scanf("%d", &x);
    arr1[i] = x;
    mp[x] = i;
    mp1[x].first++;
  }
  int a = 1;
  for (int i = 1; i <= n; i++) {
    for (int j = 1; j < 33; j++) {
      if (arr[j] > arr1[i]) {
        arr2[a] = arr[j] - arr1[i];
        a++;
        break;
      }
    }
  }
  if (n == 1)
    printf("1\n");
  else {
    for (int i = 1; i <= n; i++) {
      if (mp[arr2[i]] != 0 && i == mp[arr2[i]]) {
        cnt++;
        ar[i] = 1;
      } else if (mp[arr2[i]] == 0) {
        cnt++;
        ar[i] = 1;
      } else if (mp[arr2[i]] != 0 && ar[mp[arr2[i]]] == 1)
        cnt--;
    }
    printf("%d\n", cnt);
  }
}
