#include <bits/stdc++.h>
using namespace std;
vector<int> vec;
vector<int> vec2;
int visit[120009];
int main() {
  int n, x;
  scanf("%d", &n);
  for (int i = 0; i < n; i++) scanf("%d", &x), vec.push_back(x);
  sort(vec.begin(), vec.end());
  memset(visit, -1, sizeof visit);
  for (int i = 1; i < 31; i++) vec2.push_back(1 << i);
  int cnt = 0;
  for (int i = 0; i < n; i++) {
    int temp = vec[i];
    for (int j = 0; j < vec2.size(); j++) {
      if (vec2[j] > temp) {
        int idx = lower_bound(vec.begin() + i + 1, vec.end(), vec2[j] - temp) -
                  vec.begin();
        if (vec[idx] == vec2[j] - temp) {
          if (visit[i] == -1 && visit[idx] == -1)
            cnt += 2;
          else if (visit[i] == 1 && visit[idx] == 1)
            cnt += 0;
          else
            cnt++;
          visit[i] = 1, visit[idx] = 1;
        }
      }
    }
  }
  cout << n - cnt << endl;
  return 0;
}
