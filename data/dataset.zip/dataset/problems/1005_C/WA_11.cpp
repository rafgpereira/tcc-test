#include <bits/stdc++.h>
using namespace std;
map<long long int, int> two;
long long int R = 1000000005;
void power() {
  for (long long int i = 1; i * 2 <= R; i *= 2) {
    two[i] = 5;
  }
}
int main() {
  power();
  vector<long long int> arr;
  long long int n;
  cin >> n;
  map<long long int, bool> mapp, visit;
  for (long long int i = 0; i < n; i += 1) {
    long long int x;
    cin >> x;
    arr.push_back(x);
    mapp[x] = false;
    visit[x] = false;
  }
  sort(arr.begin(), arr.end());
  long long int c = 0;
  for (long long int i = 0; i + 1 < n; i += 1) {
    if (visit[arr[i]] == true) {
      continue;
    }
    visit[arr[i]] = true;
    for (long long int j = i + 1; j < n; j += 1) {
      long long int x = arr[i] + arr[j];
      if (x & 1) {
        continue;
      }
      if (two[x] == 5) {
        mapp[arr[j]] = true;
      }
    }
  }
  for (long long int i = 0; i < n; i += 1) {
    if (mapp[arr[i]] == false) {
      c += 1;
    }
  }
  cout << c << endl;
}
