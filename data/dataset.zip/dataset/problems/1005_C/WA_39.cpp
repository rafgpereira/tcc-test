#include <bits/stdc++.h>
using namespace std;
int n;
int pre[120005];
map<int, int> ma;
map<int, int> mb;
void Check() {
  for (int i = 1; i <= 26; i++) {
    mb[pow(2, i)] = 1;
  }
  return;
}
int main() {
  scanf("%d", &n);
  for (int i = 0; i < n; i++) {
    scanf("%d", &pre[i]);
  }
  int sum = 0;
  Check();
  for (int i = 0; i < n; i++) {
    if (ma[pre[i]]) continue;
    for (int j = i + 1; j < n; j++) {
      if (mb[pre[i] + pre[j]] == 1) {
        ma[pre[i]] = 1;
        ma[pre[j]] = 1;
      }
    }
    if (ma[pre[i]] == 0) {
      sum++;
    }
  }
  printf("%d\n", sum);
  return 0;
}
