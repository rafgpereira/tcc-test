#include <bits/stdc++.h>
using namespace std;
int binsearch(int* a, int n, int val) {
  int l = 0, h = n - 1;
  int m = (l + h) >> 1;
  while (l <= h) {
    if (a[m] == val)
      return m;
    else if (a[m] > val)
      h = m - 1;
    else
      l = m + 1;
    m = (l + h) >> 1;
  }
  return -1;
}
int main() {
  int n;
  cin >> n;
  int a[n];
  int vis[n];
  for (int i = 0; i < n; ++i) {
    vis[i] = 0;
    cin >> a[i];
  }
  sort(&a[0], &a[n]);
  if (n == 1) {
    cout << "1\n";
    return 0;
  }
  int val = 1;
  for (int i = 0; i < n; i++) {
    while (val < a[i]) val *= 2;
    int temp = val;
    int ind;
    while (temp - a[i] <= a[n - 1]) {
      int sea = temp - a[i];
      ind = binsearch(a + i + 1, n - 1 - i, sea);
      if (ind != -1) {
        vis[ind + 1 + i] = 1;
        vis[i] = 1;
      }
      temp *= 2;
    }
  }
  int cnt = 0;
  for (int i = 0; i < n; i++) {
    if (vis[i] == 0) cnt++;
  }
  cout << cnt << "\n";
  return 0;
}
