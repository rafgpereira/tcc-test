#include <bits/stdc++.h>
using namespace std;
int main() {
  long long i, j, k = 0, n, s;
  cin >> n;
  long long a[n];
  double x;
  for (i = 0; i < n; i++) {
    cin >> a[i];
  }
  int r;
  for (i = 0; i < n; i++) {
    r = 0;
    for (j = i + 1; j < n; j++) {
      if (i != j) {
        s = a[i] + a[j];
        x = log2(s);
        if (s == (pow(2, x)))
          break;
        else
          r = 1;
      }
    }
    if (r) k++;
  }
  cout << k;
  return 0;
}
