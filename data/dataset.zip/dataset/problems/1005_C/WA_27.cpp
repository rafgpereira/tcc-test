#include <bits/stdc++.h>
using namespace std;
long long n, a[1000001], ans = 0, mx = -9999999999;
set<long long> s;
int main() {
  cin >> n;
  for (int i = 1; i <= n; i++) {
    cin >> a[i];
    mx = max(mx, a[i]);
    s.insert(a[i]);
  }
  for (int i = 1; i <= n; i++) {
    long long x = 1, l = 0;
    for (int j = 1; j <= 30; j++) {
      if (x >= a[i]) {
        if (*(s.lower_bound(x - a[i])) == x - a[i] && x - a[i] <= mx) l = 1;
      }
      x *= 2;
    }
    if (!l) ans++;
  }
  cout << ans;
  return 0;
}
