#include <bits/stdc++.h>
#define ll long long
#define pb push_back
#define mp make_pair
#define mod 1000000007
#define all(c) (c).begin(),(c).end()
#define x           first
#define y           second
#define pii         pair<int,int>
#define vi          vector<int>
#define vii         vector<pii>
#define mi          map<int,int>
#define mii         map<pii,int>
#define sz(x)       (int)x.size()
#define rep(i,a,n)   for (int i = a; i < n; i++)
#define per(i,a,b)  for(int i=a;i>=b;i--)
using namespace std;
int main()
{
    int n;
    cin>>n;
    int a[n];
    rep(i,0,n)
    cin>>a[i];
    sort(a,a+n);
    int flag[n]={0};
    if(n==1)
    {
    	if(log2(a[0])==int(log2(a[0])))
    	{
    		cout<<"0";
    		
		}
		else cout<<"1";
		return 0;
	}
    rep(i,0,n)
    {
    	int f=0;
    	ll max=a[i]+a[n-1];
    	if(i==n-1)
    	max=a[n-1]+a[n-2];
    	ll j;
    	if(log2(a[i])==int(log2(a[i])))
    	j=a[i];
    	else
    	j=pow(2,int(log2(a[i]))+1);
    	//cout<<max<<" ";
    	//cout<<j<<" ";
    	while(j<=max)
    	{
    		ll s=-a[i]+j;
    		int l=0,h=n;
    		
    		
    			while(l<=h)
    			{
    				int mid=(l+h)/2;
    				if(a[mid]==s&&mid!=i)
    				{
    					f=1;
    					break;
					}
					else if(a[mid]>s)
					h=mid-1;
					else
					l=mid+1;
				}
				
			
			if(f==1)
			{
			break;
		}
    		j=j*2;
    		
		}
		if(f==1)
		flag[i]=1;
	}
	int c=0;
	rep(i,0,n)
	{
		if(flag[i]==0)
		{
		//	cout<<a[i]<<" ";
			c++;
		}
		
		
	}
	cout<<c;
	return 0;	
	
}
