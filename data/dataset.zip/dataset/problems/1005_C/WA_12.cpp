#include <bits/stdc++.h>
using namespace std;
long long modulo(long long base, long long exp, long long m);
int main() {
  long long n;
  cin >> n;
  map<long long, long long> s;
  for (int i = 0; i < n; i++) {
    int x;
    cin >> x;
    s[x]++;
  }
  long long cnt = 0;
  set<long long> elem;
  for (long long i = 63; i >= 0; i--) {
    long long sum = 1LL << i;
    for (map<long long, long long>::iterator it = s.begin(); it != s.end();
         it++) {
      map<long long, long long>::iterator tmp = s.find(sum - it->first);
      if (tmp != s.end()) {
        if (tmp->first == it->first && tmp->second > 1) {
          elem.insert(tmp->first);
          cnt += tmp->second - 1;
          tmp->second = 1;
        } else if (tmp->first != it->first) {
          elem.insert(tmp->first);
          elem.insert(it->first);
        }
      }
    }
  }
  cout << n - cnt - elem.size();
  return 0;
}
long long modulo(long long base, long long exp, long long m) {
  long long answer = 1;
  while (exp > 0) {
    if (exp % 2 == 1) answer = (answer * base) % m;
    exp = exp / 2;
    base = (base * base) % m;
  }
  return answer;
}
