#include <bits/stdc++.h>
using namespace std;
vector<long long int> v(0);
map<long long int, long long int> mp, m;
long long int check(long long int x, long long int mx) {
  long long int counter = 0, l;
  for (long long int i = 0; i < v.size(); i++) {
    if ((double)(log2(v[i] + x)) == (int)(log2(v[i] + x)) && v[i] != x) {
      return 1;
    }
  }
  return 0;
}
int main() {
  long long int n, x, mx, ans = 0, num, mn, fun, mm;
  long double j;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> x;
    v.push_back(x);
    mp[v[i]]++;
    m[v[i]]++;
  }
  mx = *max_element(v.begin(), v.end());
  for (int i = 0; i < n; i++) {
    j = ceil((long double)log2(v[i]));
    j = (long double)pow(2.0, j);
    if (j == v[i]) j *= 2;
    num = mp[j - v[i]];
    if (num == 0 && j > v[i] && j - v[i] <= mx)
      ans++;
    else if (num == 1 && j - v[i] == v[i] && (check(v[i], mx) == 0) &&
             j > v[i] && j - v[i] <= mx)
      ans++;
  }
  cout << ans;
  return 0;
}
