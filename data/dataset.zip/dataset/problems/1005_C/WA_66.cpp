#include <bits/stdc++.h>
using namespace std;
int main() {
  long long i, j;
  long long n;
  cin >> n;
  map<long long, long long> two;
  vector<long long> a(n);
  for (i = 0; i < n; i++) {
    cin >> a[i];
    if (two.count(a[i]) != 0)
      two[a[i]]++;
    else
      two[a[i]] = 1;
  }
  if (n == 1) {
    cout << 1 << "\n";
    return 0;
  }
  vector<long long> result;
  for (i = 0; i < n; i++) {
    for (j = 1; j < 32; j++) {
      if (((1 << j) - a[i]) > 0 && two.count((1 << j) - a[i]) > 0) {
        result.push_back(i);
        break;
      } else if (((1 << j) - a[i]) == 0) {
        if (two[a[i]] >= 2) result.push_back(i);
        break;
      }
    }
  }
  cout << n - result.size() << "\n";
  return 0;
}
