/*
        HELLO WORLD
        -----------
        SHUBHAM
        -----------
        :) CODING
*/
#include<bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>

using namespace std;
using namespace __gnu_pbds;

#define ff                                         first
#define ss                                         second
#define pb                                         push_back
#define int                                        long long
#define mp                                         make_pair
#define pii                                        pair<int,int>
#define vi                                         vector<int>
#define mii                                        map<int,int>
#define umii                                       unordered_map<int,int>
#define pqb                                        priority_queue<int>
#define pqs                                        priority_queue<int,vi,greater<int>>
#define setbits(x)                                 __builtin_popcountll(x)
#define zrobits(x)                                 __builtin_ctzll(x)
#define mod                                        1000000007
#define inf                                        1e18
#define ps(x,y)                                    fixed<<setprecision(y)<<x
#define mk(arr,n,type)                             type *arr=new type[n]
#define test(t)                                    int t;cin>>t;while(t--)
#define rep(i,n)                                   for(int i=0;i<n;i++)
#define rep1(i,n)                                  for(int i=1;i<=n;i++)
#define fio                                        ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0)
#define SIZE                                       1000001
#define all(x)                                     (x).begin(),(x).end()

int powmod(int a,int b) {int res=1;a%=mod; assert(b>=0); for(;b;b>>=1){if(b&1)res=res*a%mod;a=a*a%mod;}return res;}
int gcd(int a,int b) { return b?gcd(b,a%b):a;}

typedef tree<int,null_type,less<int>,rb_tree_tag,tree_order_statistics_node_update> ordered_set;

void f_io()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        freopen("output.txt","w",stdout);
    #endif // ONLINE_JUDGE
}
int32_t main()
{
    int n;
    cin>>n;
    map<int,int> mop;
    rep(i,n)
    {
        int temp;
        cin>>temp;
        mop[temp]+=1;
    }
    int ans=0;
    for(auto itr=mop.begin();itr!=mop.end();itr++)
    {
        int val=(*itr).ff;
        int k=1;
        int ok=0;
        while(k-val <= 1e9)
        {
            if(k > val )
            {
               // cout<<val<<" "<<st.count(val)<<endl;
                if(val==k-val && mop[val]>1)
                {
                    ok=1;
                    break;
                }
                else if(val != k-val)
                {
                    auto itr2=mop.find(k - val);
                    if(itr2!=mop.end())
                    {
                    //  cout<<val<<" "<<(k - val)<<endl;
                        ok=1;
                        break;
                    }
                }
            }
            k=k<<1;
        }
        if(ok==0)
            ans+=1;
    }
  cout<<ans;
    return 0;
}
