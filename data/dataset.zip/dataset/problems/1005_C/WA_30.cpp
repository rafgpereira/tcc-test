#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n;
  cin >> n;
  long long a[n + 1];
  map<long long, long long> ma;
  for (long long i = 1; i <= n; i++) {
    cin >> a[i];
    ma[a[i]] = i;
  }
  long long ans = 0;
  for (long long i = 1; i <= n; i++) {
    long long f = 0;
    for (long long j = 1; j <= 35; j++) {
      long long no = 1 << j;
      if (no > a[i] && ma[no - a[i]] > 0 && ma[no - a[i]] != i) f = 1;
    }
    if (f == 0) ans++;
  }
  cout << ans << endl;
}
