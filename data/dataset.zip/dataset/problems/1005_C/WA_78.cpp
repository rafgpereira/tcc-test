#include <bits/stdc++.h>
using namespace std;
long long n, x[200005], a;
set<long long> s, v;
void sqrt() {
  for (long long i = 2; i < 120000; i *= 2) s.insert(i);
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  cin >> n;
  sqrt();
  for (long long i = 0; i < n; ++i) {
    cin >> a;
    v.insert(a);
  }
  if (n == 1) {
    cout << 1;
    return 0;
  }
  long long num = 0;
  for (auto x : v) {
    long long numm = 0;
    for (auto g : s) {
      long long q = abs(x - g);
      if (s.find(q) != s.end()) {
        numm = 1;
        break;
      }
    }
    if (numm == 1) num += 1;
  }
  cout << num;
  return 0;
}
