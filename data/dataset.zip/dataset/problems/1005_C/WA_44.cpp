#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n;
  cin >> n;
  long long a[n];
  for (long long i = 0; i < n; i++) cin >> a[i];
  sort(a, a + n);
  long long ans = 0;
  for (long long i = 0; i < n; i++) {
    long long j = 0;
    for (j = 0; j < 33; j++) {
      if ((1LL << j) < a[i]) continue;
      int law = lower_bound(a, a + n, (1LL << j) - a[i]) - a;
      int upp = upper_bound(a, a + n, (1LL << j) - a[i]) - a;
      if (upp - law > 1)
        break;
      else if (upp - law == 1 && a[i] != a[law])
        break;
    }
    if (j == 34) {
      ans++;
    }
  }
  cout << ans << endl;
}
