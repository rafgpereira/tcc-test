#include <bits/stdc++.h>
using namespace std;
const long long MOD = (long long)1e9 + 7;
const int inf = (int)1e9 + 7;
const double eps = 1e-7;
const double pi = 3.14159265359;
const int N = 12e4;
vector<int> two_powers;
int n, ans, elem;
map<int, int> a;
int main() {
  scanf("%d", &n);
  for (int i = 0; i < n; ++i) {
    scanf("%d", &elem);
    ++a[elem];
  }
  for (int i = 1; i <= 1e9; i *= 2) two_powers.push_back(i);
  for (auto elem : a) {
    bool f = false;
    for (auto pow_ : two_powers) {
      auto it = a.find(pow_ - elem.first);
      if (it != a.end() && (it->first != elem.first || it->second > 1)) {
        cout << elem.first << " " << pow_ << endl;
        f = true;
        break;
      }
    }
    if (!f) ans += elem.second;
  }
  printf("%d", ans);
  return 0;
}
