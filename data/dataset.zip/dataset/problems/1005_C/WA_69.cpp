#include <bits/stdc++.h>
using namespace std;
bool isPowerOfTwo(int n) { return (n & (n - 1)) == 0; }
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  int n;
  cin >> n;
  int arr[n];
  for (int i = 0; i < n; i++) {
    cin >> arr[i];
  }
  int foundPair[n];
  memset(foundPair, 0, sizeof(foundPair));
  for (int i = 0; i < n; i++) {
    if (!foundPair[i]) {
      for (int j = i + 1; j < n; j++) {
        if (isPowerOfTwo(arr[i] + arr[j])) {
          foundPair[i] = 1;
          foundPair[j] = 1;
        }
      }
    }
  }
  int ans = count(foundPair, foundPair + n, 0);
  cout << ans << endl;
  return 0;
}
