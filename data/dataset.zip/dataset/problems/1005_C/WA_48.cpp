#include <bits/stdc++.h>
#include <bits/extc++.h>

#define Optimize ios_base::sync_with_stdio(false); cin.tie(0);
#define F first
#define S second
#define mp(a, b) make_pair(a, b)
#define iter(a) a.begin(), a.end()
#define pb(a) push_back(a)
#define eb(a) emplace_back(a)
#define ariter(_a, _n) _a, _a+_n
#define dbg(a, b) cout << "var " << a << " -> " << b << '\n';
#define dbg_itv(l, r, val) cout << "### (" << l << ", " << r << ") -> " << val << '\n';
#define flag(_a) cout << "Still alive at flag " << _a << '\n';
#define printv(_a) for (auto& _i : _a) cout << _i << ' '; cout << '\n';
#define printchar(_c, _n) for (int i = 0; i < _n; i++) cout << _c;
#define clear_stk(_s) while (!_s.empty()) _s.pop();
#define clear_qu(_q) while (!_q.empty()) _q.pop();
#define updmx(a, val) a = max(a, val)
#define updmi(a, val) a = min(a, val)
using namespace std;
//using namespace __gnu_pbds;

typedef long long ll;
typedef pair<int, int> pii;
typedef pair<pair<ll, ll>, ll> itv;
typedef pair<ll, ll> pll;
typedef long double ld;
typedef pair<ld, ld> pdd;

const int maxn = 1e4 + 1;
const int INF = 2147483647;
const ll LLINF = 1e18;
const int MOD = 1e9 + 7;

ostream& operator<<(ostream& os, const pair<int, int>& a) {
    return os << a.first << ' ' << a.second << '\n';
}

template<typename T>
istream& operator>>(istream& is, pair<T, T>& a) {
    return is >> a.first >> a.second;
}

ll len(ll L, ll R) {
    return R-L+1;
}

int ctoi(char c) {
    return c - '0';
}

int lb(int x) {return x & (-x);}

ll posmd(ll a, ll mod) {
    return (((a) % (mod) + (mod)) % (mod));
}

/* ------------------------------------------- */



int main() {
    Optimize

    int n;
    cin >> n;
    map<ll, int> s;
    for (int i = 0; i < n; i++) {
        ll t;
        cin >> t;
        s[t]++;
    }

    int ans = 0;
    for (auto& it : s) {
        ll i = it.F;
        int flg = 0;
        s[i]--;
        for (int j = 0; j < 33; j++) {
            if (i != (1<<j) && s[(1<<j)-i]) {
//                cout << i << ' ' << (1<<j) << '\n';
                flg = 1;
                break;
            }
        }
        s[i]++;
        if (!flg) ans++;
    }
    cout << ans << '\n';

    return 0;
}
/*

 */
