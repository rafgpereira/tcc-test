#include <bits/stdc++.h>
using namespace std;
long long n, x[200005], a;
vector<long long> v;
set<long long> s;
void sqrt() {
  for (long long i = 2; i < 120000; i *= 2) s.insert(i);
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  cin >> n;
  sqrt();
  for (long long i = 0; i < n; ++i) {
    cin >> a;
    v.push_back(a);
  }
  long long num = 0, r = v.size() - 1;
  while (r > 0) {
    long long numm = 0;
    for (long long i = 0; i < v.size(); ++i) {
      if (i == r) continue;
      long long sum = v[i] + v[r];
      if ((s.find(sum)) != s.end()) numm += 1;
    }
    if (numm == 0) num += 1;
    r -= 1;
  }
  cout << num;
  return 0;
}
