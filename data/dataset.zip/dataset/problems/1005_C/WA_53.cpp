#include <bits/stdc++.h>
using namespace std;
string s;
int dp[200000][4];
int calc(int idx, int sum) {
  if (idx == s.size()) return 0;
  int &ref = dp[idx][sum % 3];
  if (ref != -1)
    return ref;
  else
    ref = 0;
  sum += s[idx] - '0';
  if (s[idx] == '0' && sum == 0)
    return ref = calc(idx + 1, sum) + 1;
  else if (sum % 3 == 0)
    return ref = max(calc(idx + 1, 0) + 1, calc(idx + 1, sum));
  else
    return ref = max(calc(idx + 1, 0), calc(idx + 1, sum));
}
int main() {
  cin >> s;
  memset(dp, -1, sizeof dp);
  cout << calc(0, 0) << endl;
  return 0;
}
