#include <bits/stdc++.h>
class TaskC {
 public:
  void solve(std::istream& in, std::ostream& out) {
    int n;
    in >> n;
    std::vector<int> a(n);
    for (int i = 0; i < n; ++i) {
      in >> a[i];
    }
    std::vector<int> powers(31);
    for (int i = 0; i < 31; ++i) {
      powers[i] = 1 << (i);
    }
    std::map<int, int> set;
    for (int i = 0; i < n; ++i) {
      if (set.find(a[i]) == set.end()) {
        set[a[i]] = 1;
      } else {
        set[a[i]]++;
      }
    }
    int removal = 0;
    for (auto it = set.begin(); it != set.end(); ++it) {
      bool found = false;
      for (int p = 0; p < 31; ++p) {
        if (set.find(powers[p] - it->first) != set.end()) {
          if (powers[p] - it->first != it->first || set[it->first] > 1) {
            found = true;
            break;
          }
        }
      }
      if (!found) {
        removal++;
      }
    }
    out << removal;
  }
};
int main() {
  TaskC solver;
  std::istream& in(std::cin);
  std::ostream& out(std::cout);
  solver.solve(in, out);
  return 0;
}
