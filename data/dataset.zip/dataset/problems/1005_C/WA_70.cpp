#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  int many;
  cin >> many;
  map<int, int> mapping;
  for (int i = 0; i < many; i++) {
    int temp;
    cin >> temp;
    mapping[temp]++;
  }
  int answer = 0;
  for (auto it : mapping) {
    bool condition = false;
    for (int j = 0; j <= 30; j++) {
      int temp = (1 << j) - it.first;
      if (mapping.count(temp)) {
        if (temp == it.first && it.second < 2) continue;
        condition = true;
        break;
      }
    }
    if (!condition) answer++;
  }
  cout << answer << endl;
  cerr << "\nTime elapsed: " << 1000 * clock() / CLOCKS_PER_SEC << " ms\n";
  return 0;
}
