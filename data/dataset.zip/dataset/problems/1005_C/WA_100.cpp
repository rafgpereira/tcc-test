#include <bits/stdc++.h>
using namespace std;
int n, temp, cnt;
vector<int> a;
long long t = 1;
vector<long long> step;
int main() {
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> temp;
    a.push_back(temp);
  }
  sort(a.begin(), a.end());
  for (int i = 0; i < 32; i++) {
    step.push_back(t);
    t <<= 1;
  }
  for (int i = 0; i < a.size(); i++) {
    for (int j = 0; j < 32; j++) {
      if (a[i] > step[j]) continue;
      vector<int>::iterator it =
          lower_bound(a.begin(), a.end(), step[j] - a[i]);
      if (*it == step[j] - a[i] && *it != a[i] ||
          *it == a[i] && *(++it) == a[i]) {
        cnt++;
        break;
      }
    }
  }
  cout << a.size() - cnt;
  return 0;
}
