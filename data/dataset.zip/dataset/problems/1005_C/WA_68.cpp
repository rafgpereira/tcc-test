#include <bits/stdc++.h>
using namespace std;
long long gcd(long long a, long long b) {
  for (; b; a %= b, swap(a, b))
    ;
  return a;
}
int dx[4] = {1, -1, 0, 0};
int dy[4] = {0, 0, 1, -1};
int main(void) {
  ios::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
  long long n;
  cin >> n;
  long long ans = 0;
  vector<long long> a(n);
  multiset<long long> ms;
  for (long long i = 0; i < n; i++) {
    cin >> a[i];
    ms.insert(a[i]);
  }
  for (long long i = 0; i < n; i++) {
    bool flag = false;
    ms.erase(a[i]);
    for (long long j = 0; j <= 30; j++) {
      if ((1ll << j) - a[i] < 0) continue;
      if (ms.find((1ll << j) - a[i]) != ms.end()) {
        flag = true;
        break;
      }
    }
    if (!flag)
      ans++;
    else
      ms.insert(a[i]);
  }
  cout << ans;
}
