#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n, i, x, y, arr[35], cnn = 0;
  map<long long int, int> numbers;
  arr[0] = 0;
  arr[1] = 1;
  for (i = 2; i < 33; ++i) {
    arr[i] = arr[i - 1] * 2;
  }
  scanf("%lld", &n);
  for (i = 0; i < n; ++i) {
    scanf("%lld", &x);
    numbers[x] += 1;
  }
  bool flag;
  map<long long int, int>::iterator it;
  for (it = numbers.begin(); it != numbers.end(); ++it) {
    flag = false;
    for (i = 1; i < 33; ++i) {
      y = it->first;
      x = arr[i] - y;
      if (x <= 0 || x == y) continue;
      if (numbers.find(x) != numbers.end()) {
        flag = true;
        numbers[x] -= 1;
        break;
      }
    }
    if (!flag) {
      ++cnn;
    }
  }
  cout << cnn << endl;
  return (0);
}
