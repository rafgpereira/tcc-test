#include <bits/stdc++.h>
using namespace std;
const int maxn = 12e4 + 10;
const long long inf = 1e9 + 7;
long long mod = 998244353;
int n, a[maxn], b[30];
map<int, int> mp;
int main(void) {
  scanf("%d", &n);
  for (int i = 0; i < n; i++) {
    scanf("%d", &a[i]);
    mp[a[i]]++;
  }
  b[0] = 1;
  for (int i = 1; i <= 31; i++) {
    b[i] = b[i - 1] * 2;
  }
  int ans = n;
  for (int i = 0; i < n; i++) {
    for (int j = 0; j <= 31; j++) {
      if (b[j] >= a[i]) {
        int t = b[j] - a[i];
        if (t != a[i] && mp[t] != 0) {
          ans--;
          break;
        } else if (t == a[i] && mp[t] > 1) {
          ans--;
          break;
        }
      }
    }
  }
  printf("%d\n", ans);
  return 0;
}
