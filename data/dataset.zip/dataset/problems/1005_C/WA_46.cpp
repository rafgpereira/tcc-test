#include<bits/stdc++.h>
using namespace std;
#define ll long long int
#define deb1(x)                cout<<#x<<": "<<x<<endl
#define deb2(x, y)             cout<<#x<<": "<<x<<" | "<<#y<<": "<<y<<endl
#define deb3(x, y, z)          cout<<#x<<":" <<x<<" | "<<#y<<": "<<y<<" | "<<#z<<": "<<z<<endl
#define deb4(a, b, c, d)       cout<<#a<<": "<<a<<" | "<<#b<<": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<endl
#define deb5(a, b, c, d, e)    cout<<#a<<": "<<a<<" | "<<#b<<": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<" | "<<#e<< ": "<<e<<endl
#define deb6(a, b, c, d, e, f) cout<<#a<<": "<<a<<" | "<<#b<<": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<" | "<<#e<< ": "<<e<<" | "<<#f<<": "<<f<<endl

// ll kadane()
// {
// 	ll maxsofar=0,maxendinghere=0,n,i;
// 	cin>>n;
// 	ll a[n];
// 	for(i=0;i<n;i++)
// 	{
// 		cin>>a[i];
// 		maxendinghere+=a[i];
// 		if(maxendinghere<0) maxendinghere=0;
// 		else
// 		{
// 			if(maxendinghere>maxsofar)
// 			{
// 				maxsofar=maxendinghere;
// 			}
// 		}
// 	}
// 	return maxsofar;
// }


// vector <int> adj[10];
//     bool visited[10];

//     void dfs(int s) {
//         visited[s] = true;
//         for(int i = 0;i < adj[s].size();++i)    {
//          if(visited[adj[s][i]] == false)
//              dfs(adj[s][i]);
//         }
//     }

//     void initialize() {
//         for(int i = 0;i < 10;++i)
//          visited[i] = false;
//     }

//     int main() {
//         int nodes, edges, x, y, connectedComponents = 0;
//         cin >> nodes;                       //Number of nodes
//         cin >> edges;                       //Number of edges
//         for(int i = 0;i < edges;++i) {
//          cin >> x >> y;     
//      //Undirected Graph 
//          adj[x].push_back(y);                   //Edge from vertex x to vertex y
//          adj[y].push_back(x);                   //Edge from vertex y to vertex x
//         }

//         initialize();                           //Initialize all nodes as not visited

//         for(int i = 1;i <= nodes;++i) {
//          if(visited[i] == false)     {
//              dfs(i);
//              connectedComponents++;
//          }
//         }
//         cout << "Number of connected components: " << connectedComponents << endl;
//         return 0;
//     }

int main()
{
	ll n,i,j,count=0,sum=0,flag=0;
	cin>>n;
	long double fractpart,intpart,value=0;
	long double a[n+1]={0},temp[n+1]={0};
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=n;i++)
	{
		if(temp[i]!=1)
		{
			flag=0;
			for(j=1;j<=n;j++)
			{
				if(j!=i && temp[j]!=2)
				{
					value=log10(a[i]+a[j])/(log10(2));
					fractpart=modf(value,&intpart);
					if(fractpart==0)
					{
						flag=1;
						break;
					}
					else
					{
						continue;
					}
				}
			}
			if(flag==1)
			{
				temp[i]=1;
				temp[j]=1;
			}
			else
			{
				count++;
				temp[j]=2;
			}
		}
	}
	cout<<count<<endl;
	return 0;
}