#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n, rem = 0, j, i, k;
  cin >> n;
  vector<long long> arr;
  for (i = 0; i < n; i++) {
    cin >> k;
    arr.push_back(k);
  }
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      if (i == j) continue;
      int sum = arr[i] + arr[j];
      if (__builtin_popcount(sum) == 1) break;
    }
    if (j == n) {
      arr.erase(arr.begin() + i);
      rem++;
      n--;
    }
  }
  cout << rem;
  return 0;
}
