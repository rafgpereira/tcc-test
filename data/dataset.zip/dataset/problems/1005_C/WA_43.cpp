#include <bits/stdc++.h>
using namespace std;
bool power_of_tow(int x) { return x & (x - 1) == 0; }
int a[1000000];
map<int, int> d;
int main() {
  int n;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    d[a[i]]++;
  }
  int sum = 0;
  for (int i = 0; i < n + 1; i++) {
    bool c = 0;
    d[a[i]]--;
    for (int j = 0; j < 31; j++) {
      long long g = (1LL << j) - a[i];
      if (g > 0LL)
        if (d[g] > 0) {
          c = 1;
          break;
        }
    }
    if (!c) {
      sum++;
    }
    d[a[i]]++;
  }
  cout << sum;
}
