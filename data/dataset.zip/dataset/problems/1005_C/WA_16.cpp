#include <bits/stdc++.h>
using namespace std;
const int MAXN = 2e5 + 5;
int a[35];
int main() {
  int n;
  a[0] = 1;
  for (int(i) = (1); (i) < (31); (i)++) {
    a[i] = a[i - 1] << 1;
  }
  while (scanf("%d", &n) == 1) {
    set<int> si;
    map<int, int> mi;
    for (int(i) = (0); (i) < (n); (i)++) {
      int x;
      scanf("%d", &x);
      si.insert(x);
      mi[x]++;
    }
    int ans = 0;
    for (int i : si) {
      bool f = false;
      for (int(x) = (0); (x) < (31); (x)++) {
        int o = a[x] - i;
        if (o == i) {
          if (mi[o] != 1) {
            f = true;
            break;
          }
        } else {
          if (si.find(o) != si.end()) {
            f = true;
            break;
          }
        }
      }
      if (!f) ans++;
    }
    cout << ans << endl;
  }
  return 0;
}
