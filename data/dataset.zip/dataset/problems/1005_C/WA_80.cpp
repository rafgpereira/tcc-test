#include <bits/stdc++.h>
using namespace std;
long long int i, j, k, n, h, m, s, t, a[100009], d, p, b[120009], q;
int main() {
  map<long long int, long long int> v;
  cin >> n;
  int c[9] = {0};
  for (i = 0; i < n; i++) {
    cin >> a[i];
    v[a[i]]++;
  }
  sort(a, a + n);
  for (i = 0; i < n; i++) {
    a[i] = a[i] % 8;
    c[a[i]]++;
  }
  for (i = 0; i < n; i++) {
    d = 8 - a[i];
    if (d == a[i]) {
      if (c[d] >= 2) a[c[d]] = 1;
    } else if (a[i] != d) {
      if (d == 8) {
        if (c[0] >= 2) a[c[0]] = 1;
      } else {
        if (c[d] >= 1) a[c[d]] = 1;
      }
    }
  }
  for (i = 0; i < n; i++) {
    if (i == 1 || i == 2) {
      if (v[i] >= 2 || a[i] == 1) p++;
    } else {
      if (a[i] == 1) p++;
    }
  }
  cout << max(q, (n - p) - 1) << endl;
}
