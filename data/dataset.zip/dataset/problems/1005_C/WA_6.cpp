#include <bits/stdc++.h>
int fun(int n) {
  if ((n & (n - 1))) return -1;
  return 1;
}
int main() {
  int n, i, x, k, j;
  int s[120001];
  while (scanf("%d", &n) != EOF) {
    x = 0;
    for (i = 0; i < n; i++) scanf("%d", &s[i]);
    for (i = 0; i < n; i++) {
      k = 0;
      for (j = 0; j < n; j++) {
        if (j == i) j++;
        if (fun(s[i] + s[j]) == 1) k = 1;
      }
      if (k == 0) x++;
    }
    printf("%d\n", x);
  }
  return 0;
}
