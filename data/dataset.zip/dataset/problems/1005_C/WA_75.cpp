#include <bits/stdc++.h>
using namespace std;
int binsearch(long long int* a, int n, long long int val) {
  int l = 0, h = n - 1;
  int m = (l + h) >> 1;
  while (l <= h) {
    if (a[m] == val)
      return m;
    else if (a[m] > val)
      h = m - 1;
    else
      l = m + 1;
    m = (l + h) >> 1;
  }
  return -1;
}
int main() {
  int n;
  cin >> n;
  long long int a[n];
  long long int mark[n];
  for (int i = 0; i < n; ++i) {
    cin >> a[i];
    mark[i] = 0;
  }
  long long int pow2[32];
  pow2[0] = 1;
  for (int i = 1; i < 32; i++) pow2[i] = pow2[i - 1] * 2;
  sort(&a[0], &a[n]);
  for (int i = 0; i < n - 1; i++) {
    int j = 1;
    while (pow2[j] <= a[i]) j++;
    for (; j < 32; j++) {
      int ind;
      ind = binsearch(a + i + 1, n - i - 1, pow2[j] - a[i]);
      if (ind != -1) {
        mark[i] = 1;
        mark[ind + i + 1] = 1;
      }
    }
  }
  int cnt = 0;
  for (int i = 0; i < n; i++)
    if (!mark[i]) cnt++;
  cout << cnt << "\n";
  return 0;
}
