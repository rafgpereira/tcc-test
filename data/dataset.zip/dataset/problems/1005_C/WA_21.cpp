#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  vector<int> a;
  vector<int> m1(n + 10, 0);
  for (int i = 0; i < n; i++) {
    int q;
    cin >> q;
    a.push_back(q);
  }
  int ans = 0;
  vector<int> g1{1};
  int prod = 1;
  for (int i = 1; i <= 30; i++) {
    prod *= 2;
    g1.push_back(prod);
  }
  if (n == 1) {
    cout << 1 << "\n";
  } else {
    for (int i = 0; i < n - 1; i++) {
      bool temp_con = true;
      for (int j = i + 1; j < n; j++) {
        int temp_sum = a[i] + a[j];
        for (int k = 0; k < g1.size(); k++) {
          if (g1[k] == temp_sum) {
            m1[i] = 1;
            m1[j] = 1;
            temp_con = false;
          }
        }
      }
      if (temp_con) {
        ans++;
      }
    }
    if (m1[n - 1] == 0) {
      ans++;
    }
    cout << ans << "\n";
  }
}
