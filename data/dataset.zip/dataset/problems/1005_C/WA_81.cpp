#include <bits/stdc++.h>
using namespace std;
using ll = long long;
const int N = 2e5 + 7;
const int M = 1e6 + 7, ML = 1e6;
const long long MOD = 1e6 + 3;
const long long INF = 1e18;
const int SM = 1e4 + 5;
const long long logN = 30, BL = 400;
const double EPS = 1e-9;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0), cout.tie(0);
  long long n;
  cin >> n;
  map<long long, long long> m;
  for (long long i = 0; i < n; i++) {
    long long x;
    cin >> x;
    m[x]++;
  }
  long long ans = 0;
  for (auto i : m) {
    long long val = i.first, cnt = i.second;
    bool found = false;
    for (long long j = 1; j <= logN; j++) {
      long long pw = (1 << j), d = pw - val;
      if (m.count(d) > 0) {
        if (val == d) {
          if (cnt > 1) {
            found = true;
            break;
          }
        } else {
          found = true;
          break;
        }
      }
    }
    if (!found) {
      ans++;
    }
  }
  cout << ans;
  return 0;
}
