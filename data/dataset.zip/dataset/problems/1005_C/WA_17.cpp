#include <bits/stdc++.h>
using namespace std;
int32_t main() {
  long long n, i, j = 1e18, k, l = 0, l1 = 0;
  vector<long long> v;
  long long x = 1;
  while (x <= j) {
    v.push_back(x);
    x = x * 2;
  }
  k = v.size();
  long long a[n];
  map<long long, long long> m;
  for (i = 0; i < n; i++) {
    cin >> a[i];
    m[a[i]]++;
  }
  for (i = 0; i < n; i++) {
    for (j = 0; j < k; j++) {
      if (m.count(v[j] - a[i])) {
        if (m[v[j] - a[i]] >= 2) {
          l++;
          break;
        }
        if (v[j] != 2 * a[i]) {
          l++;
          break;
        }
      }
    }
  }
  cout << n - l;
}
