#include <bits/stdc++.h>
using namespace std;
long long n, k;
string s;
int MOD = 1e9 + 7;
const int INF = 1e9;
const long long INF64 = 2e18;
const double PI = 3.141592653589793238463;
long long ar[1000004], ar1[1000004], vis[1000004], pre[1000004], dp[2][1000004];
vector<long long> le, rt;
set<long long> myset;
pair<long long, long long> seg[1000004];
map<long long, long long> mymap;
long long c = 1;
string st1[1000004], st2[1000004];
vector<long long> arr[1000004];
int comp(string a, string b) {
  int i = 0, j = 0;
  while (i < a.size() && j < b.size()) {
    if (a[i] != b[j]) return a[i] < b[j];
    i++, j++;
  }
  return a.size() < b.size();
}
int binsearch(int l, int r, int val) {
  while (l < r) {
    int m = l + r >> 1;
    if (ar[m] == val) return m;
    if (ar[m] > val)
      r = m;
    else
      l = m + 1;
  }
  if (ar[l] == val) return l;
  return -1;
}
int main() {
  std::ios_base::sync_with_stdio(false);
  std::cin.tie(nullptr);
  cin >> n;
  for (int i = 0; i < int(n); i++) cin >> ar[i];
  sort(ar, ar + n);
  int i = 0, l = 0;
  while (i < n) {
    long long a = ar[i], j = i;
    c = 0;
    while (j < n && a == ar[j]) j++, c++;
    le.push_back(a);
    ar1[l] = c;
    l++;
    i++;
  }
  long long ans = 0;
  for (int i = 0; i < int(l); i++) {
    if (!vis[i]) {
      for (int j = 1; j < int(40); j++) {
        long long val = pow(2, j);
        if (val - ar[i] > 0) {
          if (val - ar[i] == ar[i]) {
            if (ar1[i] > 1) {
              vis[i] = 1;
            }
          } else {
            long long v = binsearch(0, n - 1, val - ar[i]);
            if (v != -1) {
              vis[v] = 1;
              vis[i] = 1;
            }
          }
        }
      }
      if (!vis[i]) ans += ar1[i];
    }
  }
  return cout << ans, 0;
}
