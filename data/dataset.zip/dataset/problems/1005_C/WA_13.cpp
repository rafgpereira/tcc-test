#include <bits/stdc++.h>
using namespace std;
long long f(long long n) {
  long long k = log2(n);
  return pow(2, k);
}
void solve() {
  long long cnt = 0, sum = 0, i, j, k;
  long long n;
  cin >> n;
  vector<long long> v(n);
  map<long long, long long> mp;
  for (long long i = 0; i < n; i++) {
    cin >> v[i];
    mp[v[i]]++;
  }
  for (long long i = 0; i < n; i++) {
    long long no = f(v[i]);
    if (v[i] != 1 and no == v[i]) {
      if (mp[v[i]] > 1)
        continue;
      else
        cnt++;
    } else {
      no <<= 1;
      bool f = 0;
      while (no < 1e9) {
        if (mp[no - v[i]] > 0) {
          f = 1;
          break;
        }
        no <<= 1;
      }
      if (f == 1)
        continue;
      else
        cnt++;
    }
  }
  cout << cnt;
}
void init() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
}
int32_t main() {
  init();
  { solve(); }
  return 0;
}
