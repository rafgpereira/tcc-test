#include <bits/stdc++.h>
using namespace std;
long long int gcd(long long int a, long long int b) {
  if (b == 0) return a;
  return gcd(b, a % b);
}
void solve() {
  long long int check[51];
  check[0] = 1;
  for (long long int i = 1; i <= 50; i++) check[i] = 2 * check[i - 1];
  map<long long int, long long int> mp;
  long long int n;
  cin >> n;
  long long int *arr = new long long int[n];
  for (long long int i = 0; i < n; i++) {
    cin >> arr[i];
    mp[arr[i]]++;
  }
  long long int x, count1 = 0;
  for (long long int i = 0; i < n; i++) {
    bool flag = 0;
    for (long long int j = 0; j <= 50; j++) {
      if (check[j] > arr[i]) {
        x = check[j] - arr[i];
        if (x == arr[i] && mp[x] > 1)
          flag = 1;
        else if (mp[x] > 0)
          flag = 1;
      }
    }
    if (flag == 0) count1++;
  }
  cout << count1 << endl;
}
int main() {
  int t;
  t = 1;
  while (t--) {
    solve();
  }
}
