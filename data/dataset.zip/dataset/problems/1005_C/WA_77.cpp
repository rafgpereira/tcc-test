#include <bits/stdc++.h>
using namespace std;
long long int max(long long int a, long long int b) {
  if (a < b) swap(a, b);
  return a;
}
long long int min(long long int a, long long int b) {
  if (a >= b) swap(a, b);
  return a;
}
long long int sqr(long long int p) { return p * p; }
long long int mohit(long long int a, long long int b) { return (a + b) * 2; }
long long int masahat(long long int a, long long int b) { return a * b; }
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  set<long long int> s;
  long long int n, a, x[200005], c = 0, i, j, sum = 0;
  map<long long int, long long int> map, good;
  cin >> n;
  for (i = 0; i <= 34; i++) s.insert(pow(2, i));
  for (i = 1; i <= n; i++) {
    cin >> a;
    if (!map[a]) {
      map[a] = 1;
      x[++c] = a;
    } else
      map[a] += 1;
  }
  if (n == 1) return cout << 1, 0;
  for (i = 1; i <= c; i++) {
    if (s.find(x[i]) != s.end() && map[x[i]] >= 2) {
      good[i] = 1;
      goto next;
    } else {
      for (j = 1; j <= c; j++) {
        if (j != i) {
          if (!good[i]) {
            if (s.find(x[i] + x[j]) != s.end()) {
              good[i] = 1;
              goto next;
            }
          } else
            goto next;
        }
      }
    }
  next:
    a += 0;
  }
  for (i = 1; i < c; i++) {
    if (!good[i]) sum += map[x[i]];
  }
  cout << sum;
  return 0;
}
