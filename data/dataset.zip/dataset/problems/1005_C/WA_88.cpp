#include <bits/stdc++.h>
using namespace std;
long long i, j, map[200][200], a[200100], x, y, xa, ya, xb, yb, l, r, m, n, t,
    k, num, flag[200100], minn, ans, key, p, c[300], d[300], pre[200100];
char b[200100], zz;
double dd, ee;
struct qq {
  long long xx, yy, dd;
} q[10010];
bool cmp(qq u, qq v) { return u.dd < v.dd; }
long long find(long long x) {
  if (x == pre[x]) {
    return x;
  } else {
    pre[x] = find(pre[x]);
    return pre[x];
  }
}
void meg(long long x, long long y) {
  long long fx = find(x), fy = find(y);
  if (fx != fy) {
    pre[fy] = fx;
  }
}
long long f(long long x) {
  long long aaa = 0;
  while (x > 0) {
    x /= 2;
    aaa++;
  }
  return aaa;
}
int main() {
  memset(flag, 0, sizeof(flag));
  scanf("%lld", &n);
  for (i = 0; i < n; i++) scanf("%lld", &a[i]);
  sort(a, a + n);
  for (i = 0, num = 0; i < n; i++) {
    if (flag[i] == 0) {
      t = f(a[i]);
      for (j = 0;; j++) {
        key = pow(2, t + j) - a[i];
        if (key > a[n - 1]) break;
        l = 0;
        r = n - 1;
        p = -1;
        while (l < r) {
          long long mid = (l + r) / 2;
          if (a[mid] <= key) {
            l = mid + 1;
            p = mid;
          } else
            r = mid - 1;
        }
        if ((a[p] == key && p != i && p >= 0) ||
            (p == i && (a[p - 1] == key || a[p + 1 == key]))) {
          flag[p] = 1;
          flag[i] = 1;
          break;
        }
      }
    }
  }
  for (i = 0; i < n; i++) {
    if (flag[i] == 0) num++;
  }
  printf("%lld", num);
}
