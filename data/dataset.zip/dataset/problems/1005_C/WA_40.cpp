#include <bits/stdc++.h>
using namespace std;
const int maxn = 2e5 + 10;
const int maxm = 2e6 + 10;
const int INF = 0x3f3f3f3f;
int casn, n, m, k;
inline char nc() {
  static char buf[1000000], *p1 = buf, *p2 = buf;
  return p1 == p2 && (p2 = (p1 = buf) + fread(buf, 1, 1000000, stdin), p1 == p2)
             ? EOF
             : *p1++;
}
inline void read(long long &sum) {
  char ch = nc();
  sum = 0;
  while (!(ch >= '0' && ch <= '9')) ch = nc();
  while (ch >= '0' && ch <= '9')
    sum = (sum << 3) + (sum << 1) + (ch - 48), ch = nc();
}
map<long long, long long> vis;
long long num[maxn];
long long rk[maxn];
struct node {
  long long num, cnt;
} cnt[maxn];
int cmp(node a, node b) { return a.cnt < b.cnt; }
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  cin >> n;
  if (n == 1) {
    cout << 1 << endl;
    return 0;
  }
  for (int i = 1; i <= n; i++) {
    cin >> num[i];
    vis[num[i]]++;
  }
  for (map<long long, long long>::iterator i = vis.begin(); i != vis.end();
       i++) {
    cnt[m++] = (node){i->first, i->second};
  }
  n = m;
  sort(cnt + 1, cnt + 1 + n, cmp);
  int ans = 0;
  for (int j = 1; j <= n; j++) {
    int flag = 0;
    for (int i = 1; i <= 32; i++) {
      if ((1ll << i) > 1e9) break;
      if (cnt[j].num < (1ll << i) &&
          (((1ll << i) - cnt[j].num != cnt[j].num &&
            vis[(1ll << i) - cnt[j].num] > 0) ||
           ((1ll << i) - cnt[j].num == cnt[j].num && cnt[j].cnt > 1))) {
        flag = 1;
        break;
      }
    }
    if (flag == 0) {
      ans += cnt[j].cnt;
      vis[cnt[j].num] = 0;
    }
  }
  cout << ans << endl;
  return 0;
}
