#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  int n = s.size();
  vector<pair<int, int> > ans;
  pair<int, int> one;
  one.first = 1;
  pair<int, int> two;
  two.first = 2;
  pair<int, int> zero;
  zero.first = 0;
  for (int i = 0; i < n; i++) {
    if (s[i] == '0') {
      if (two.second > 0) {
        ans.push_back(one);
        one.second = 0;
        ans.push_back(two);
        two.second = 0;
      }
      zero.second++;
    } else if (s[i] == '1') {
      one.second++;
    } else if (s[i] == '2') {
      if (zero.second > 0) {
        ans.push_back(zero);
        zero.second = 0;
        ans.push_back(one);
        one.second = 0;
      }
      two.second++;
    }
  }
  if (zero.second != 0) {
    ans.push_back(zero);
  }
  if (one.second != 0) {
    ans.push_back(one);
  }
  if (two.second != 0) {
    ans.push_back(two);
  }
  for (int i = 0; i < ans.size(); i++) {
    if (ans[i].first == 0) {
      for (int j = 0; j < ans[i].second; j++) {
        cout << 0;
      }
    } else if (ans[i].first == 1) {
      for (int j = 0; j < ans[i].second; j++) {
        cout << 1;
      }
    } else {
      for (int j = 0; j < ans[i].second; j++) {
        cout << 2;
      }
    }
  }
  cout << endl;
}
