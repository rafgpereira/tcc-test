#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;
using ll = long long;
using P = pair<ll, ll>;
template <class T>
using V = vector<T>;
const ll inf = (1e18);
const ll mod = 1000000007;
ll GCD(ll a, ll b) { return b ? GCD(b, a % b) : a; }
ll LCM(ll c, ll d) { return c / GCD(c, d) * d; }
struct __INIT {
  __INIT() {
    cin.tie(0);
    ios::sync_with_stdio(false);
    cout << fixed << setprecision(15);
  }
} __init;
template <class T>
bool chmax(T &a, const T &b) {
  if (a < b) {
    a = b;
    return 1;
  }
  return 0;
}
template <class T>
bool chmin(T &a, const T &b) {
  if (a > b) {
    a = b;
    return 1;
  }
  return 0;
}
int main() {
  string s;
  cin >> s;
  string ans = {};
  int n = s.size();
  V<int> used(4, 0);
  bool esp = false;
  for (int i = 0; i < n; i++) {
    if (s[i] == '0' && used[2]) esp = true;
    if ((s[i] == '2' && used[0] && !esp)) {
      while (used[0]) {
        ans.push_back('0');
        used[0]--;
      }
      while (used[1]) {
        ans.push_back('1');
        used[1]--;
      }
      while (used[2]) {
        ans.push_back('2');
        used[2]--;
      }
    } else if ((s[i] == '2' && used[0] && esp)) {
      while (used[1]) {
        ans.push_back('1');
        used[1]--;
      }
      while (used[2]) {
        ans.push_back('2');
        used[2]--;
      }
      while (used[0]) {
        ans.push_back('0');
        used[0]--;
      }
      esp = false;
    }
    used[s[i] - '0']++;
  }
  if (!esp) {
    while (used[0]) {
      ans.push_back('0');
      used[0]--;
    }
    while (used[1]) {
      ans.push_back('1');
      used[1]--;
    }
    while (used[2]) {
      ans.push_back('2');
      used[2]--;
    }
  } else {
    while (used[1]) {
      ans.push_back('1');
      used[1]--;
    }
    while (used[2]) {
      ans.push_back('2');
      used[2]--;
    }
    while (used[0]) {
      ans.push_back('0');
      used[0]--;
    }
  }
  cout << ans << "\n";
}
