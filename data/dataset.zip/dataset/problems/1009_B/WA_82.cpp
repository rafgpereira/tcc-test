#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  string sn = "";
  int cnt = 0;
  bool found = false;
  int ind = 0;
  for (int i = 0; i < s.size(); i++) {
    char elem = s[i];
    if (elem == '1')
      cnt += 1;
    else {
      if (elem == '2' && !found) {
        found = true;
        ind = i;
      } else {
        if (elem != '2') {
          if (!found) sn.push_back(elem);
        }
      }
    }
  }
  for (int i = 0; i < cnt; i++) sn.push_back('1');
  for (int i = ind; i < s.size(); i++)
    if (s[i] != '1') sn.push_back(s[i]);
  cout << sn << '\n';
  return 0;
}
