#include <bits/stdc++.h>
using namespace std;
vector<int> adj[200000];
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  string s;
  cin >> s;
  int zero = 0, on = count(s.begin(), s.end(), '1');
  int st = 0;
  for (int i = 0; i < s.size(); i++) {
    if (s[i] == '2') {
      st = i;
      break;
    }
    if (s[i] == '0') zero++;
  }
  string res = string(zero, '0') + string(on, '1');
  for (int i = st; i < s.size(); i++) {
    if (s[i] != '1') res.push_back(s[i]);
  }
  cout << res;
}
