#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1005;
const int INF = 0x3f3f3f3f;
string s, ans;
int main() {
  cin >> s;
  int one = 0;
  for (int i = 0; i < s.size(); i++) {
    if (s[i] == '0') ans += "0";
    if (s[i] == '1') one++;
    if (s[i] == '2') ans += "2";
  }
  bool flag = false;
  for (int i = 0; i < ans.size(); i++) {
    if (s[i] == '2' && !flag) flag = true, cout << string(one, '1');
    cout << s[i];
  }
  return 0;
}
