#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, i, j, k, t = 0, c, cnt = 0, m;
  string s;
  cin >> s;
  n = s.size();
  while (1) {
    c = 0;
    for (i = 0; i < n - 1; i++) {
      if (s[i] == '2' && s[i + 1] == '1') {
        swap(s[i], s[i + 1]);
        ++c;
      }
    }
    if (c == 0) break;
  }
  while (1) {
    c = 0;
    for (i = 0; i < n - 1; i++) {
      if (s[i] == '1' && s[i + 1] == '0') {
        swap(s[i], s[i + 1]);
        ++c;
      }
    }
    if (c == 0) break;
  }
  while (1) {
    c = 0;
    for (i = 0; i < n - 1; i++) {
      if (s[i] == '1' && s[i + 1] == '0') {
        swap(s[i], s[i + 1]);
        ++c;
      } else if (s[i] == '2' && s[i + 1] == '1') {
        swap(s[i], s[i + 1]);
        ++c;
      }
    }
    if (c == 0) break;
  }
  cout << s << endl;
}
