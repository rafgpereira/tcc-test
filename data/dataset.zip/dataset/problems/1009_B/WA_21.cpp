#include <bits/stdc++.h>
using namespace std;
int main() {
  string s, out = "", temp = "";
  cin >> s;
  int l = s.length();
  for (int i = 0; i < l; i++) {
    if (temp.empty()) {
      if (s[i] == '0') {
        out += '0';
      } else {
        temp += s[i];
      }
    } else {
      if (s[i] == temp[0]) {
        temp += s[i];
      } else if (s[i] + 1 == temp[0]) {
        out += s[i];
      } else {
        out += temp;
        temp = "";
        i--;
      }
    }
  }
  cout << out + temp;
  return 0;
}
