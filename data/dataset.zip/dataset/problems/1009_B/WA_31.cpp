#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  string str = "";
  cin >> s;
  int c = 0;
  int d = 0;
  int c2 = 0;
  int j;
  string temp;
  for (int i = 0; i < s.length(); i++) {
    if (s[i] == '1') {
      c++;
      str = str + s[i];
      s.erase(s.begin() + i);
      i--;
    }
  }
  for (int j = 0; j < s.length(); j++) {
    if (c2 == 0 && s[j] == '2') {
      if (j == 0) {
        s.insert(0, str);
      } else {
        s.insert(j, str);
      }
      c2++;
    }
  }
  cout << s << endl;
  return 0;
}
