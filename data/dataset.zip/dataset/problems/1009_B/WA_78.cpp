#include <bits/stdc++.h>
using namespace std;
const int MX = 1 << 22;
const int MOD = 1000000007;
const int64_t mod2 = 1000000007 * 1LL * 1000000007;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  string second;
  cin >> second;
  int n = second.length();
  int i = 0;
  while (i < n) {
    if (second[i] == '0') {
      cout << second[i];
      i++;
    } else {
      if (second[i] == '1') {
        int j = i;
        int z = 0, o = 0;
        while (j < n && second[j] != '2') {
          if (second[j] == '1')
            o++;
          else if (second[j] == '0')
            z++;
          j++;
        }
        while (z) {
          cout << 0;
          z--;
        }
        while (o) {
          cout << 1;
          o--;
        }
        i = j;
      } else if (second[i] == '2') {
        int j = i;
        int t = 0, o = 0;
        while (j < n && second[j] != '0') {
          if (second[j] == '2')
            t++;
          else if (second[j] == '1')
            o++;
          j++;
        }
        while (o) {
          cout << 1;
          o--;
        }
        while (t) {
          cout << 2;
          t--;
        }
        i = j;
      }
    }
  }
  return 0;
}
