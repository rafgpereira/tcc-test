#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  vector<string> ss;
  string temp = "";
  int n = s.length();
  for (int i = 0; i < n; i++) {
    if (s[i] == '2') {
      sort(temp.begin(), temp.end());
      reverse(temp.begin(), temp.end());
      ss.push_back(temp);
      temp = "";
    } else
      temp += s[i];
  }
  if (temp != "") {
    sort(temp.begin(), temp.end());
    reverse(temp.begin(), temp.end());
    ss.push_back(temp);
    temp = "";
  }
  string f = "";
  for (int i = 0; i + 1 < ss.size(); i++) f += ss[i] + '2';
  f += ss.back();
  if (s[n - 1] == '2') f += '2';
  int j = 0;
  for (int i = 0; i < n; i++) {
    if (s[i] == '2') {
      j = max(j, i + 1);
      while (j < n and s[j] == '2') j++;
      if (j < n and s[j] == '1') {
        s[i] = '1';
        s[j] = '2';
      }
    }
  }
  int l = 0;
  string fin = "";
  for (int i = 0; i < n; i++) {
    if (s[i] == '2' and l < n) {
      string t = s.substr(l, i - l);
      sort(t.begin(), t.end());
      fin += t + '2';
      l = i + 1;
    }
  }
  if (l < n) {
    string t = s.substr(l, n - l);
    sort(t.begin(), t.end());
    fin += t;
  }
  cout << fin << endl;
}
