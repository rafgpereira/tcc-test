#include <bits/stdc++.h>
using namespace std;
class A {
 public:
  void solve() {
    int n, m;
    cin >> n >> m;
    vector<int> c(n), a(m);
    for (int i = 0; i < n; i++) cin >> c[i];
    for (int i = 0; i < m; i++) cin >> a[i];
    int res = 0;
    for (int i = 0, j = 0; i < n && j < m; i++) {
      if (a[j] >= c[i]) {
        res++;
        j++;
      }
    }
    cout << res << endl;
  }
};
class B {
 public:
  void solve() {
    string s;
    cin >> s;
    int n = s.size();
    map<char, int> cnt;
    string res;
    for (int i = 0; i < n; i++) {
      cnt[s[i]]++;
      if (cnt['0'] > 0 && cnt['2'] > 0) {
        for (int j = 0; j <= 2; j++) {
          if (j + '0' == s[i]) continue;
          res.append(cnt[j + '0'], j + '0');
          cnt[j + '0'] = 0;
        }
      }
    }
    for (char i = '0'; i <= '2'; i++) {
      res.append(cnt[i], i);
    }
    cout << res << endl;
  }
};
class C {
 public:
  void solve() {}
};
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  B ans;
  ans.solve();
  return 0;
}
