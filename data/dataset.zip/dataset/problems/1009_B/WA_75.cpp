#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  long long q(1);
  while (q--) {
    string s;
    cin >> s;
    long long n = s.length();
    for (int i = n - 1; i > 0; i--) {
      if (s[i - 1] == '2' and s[i] == '1') {
        swap(s[i - 1], s[i]);
      }
    }
    for (int i = n - 1; i > 0; i--) {
      if (s[i - 1] == '2' and s[i] == '1') {
        swap(s[i - 1], s[i]);
      }
    }
    for (int i = n - 1; i > 0; i--) {
      if (s[i - 1] == '1' and s[i] == '0') {
        swap(s[i - 1], s[i]);
      }
    }
    for (int i = n - 1; i > 0; i--) {
      if (s[i - 1] == '1' and s[i] == '0') {
        swap(s[i - 1], s[i]);
      }
    }
    cout << s << endl;
  }
}
