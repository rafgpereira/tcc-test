#include <bits/stdc++.h>
using namespace std;
const double pi = acos(-1);
const int N = (int)1e6 + 7, mod = 1000000007, M = 2e9;
string s, ans;
int c[3];
void proc() {
  for (int i = 0; i < 3; i++) {
    while (c[i]) {
      ans += '0' + i;
      c[i]--;
    }
  }
}
int main() {
  cin >> s;
  for (char i : s) {
    c[i - '0']++;
    if (c[0] && c[2]) {
      c[i - '0']--;
      proc();
      c[i - '0']++;
    }
  }
  proc();
  cout << ans;
  return 0;
}
