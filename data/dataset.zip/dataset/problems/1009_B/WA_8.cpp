#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  vector<string> ss;
  string temp = "";
  int n = s.length(), l = 0;
  string f = "";
  for (int i = 0; i < n; i++) {
    if (s[i] == '2') {
      string t = s.substr(l, i - l);
      sort(t.begin(), t.end());
      reverse(t.begin(), t.end());
      f += t + '2';
      l = i + 1;
    }
  }
  if (l < n) {
    string t = s.substr(l, n - l);
    sort(t.begin(), t.end());
    reverse(t.begin(), t.end());
    f += t;
  }
  int j = 0;
  for (int i = 0; i < n; i++) {
    if (f[i] == '2') {
      j = max(j, i + 1);
      while (j < n and f[j] == '2') j++;
      if (j < n and f[j] == '1') {
        f[i] = '1';
        f[j] = '2';
      }
    }
  }
  l = 0;
  string fin = "";
  s = f;
  for (int i = 0; i < n; i++) {
    if (s[i] == '2' and l < n) {
      string t = s.substr(l, i - l);
      sort(t.begin(), t.end());
      fin += t + '2';
      l = i + 1;
    }
  }
  if (l < n) {
    string t = s.substr(l, n - l);
    sort(t.begin(), t.end());
    fin += t;
  }
  cout << fin << endl;
}
