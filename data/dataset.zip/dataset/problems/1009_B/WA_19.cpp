#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  int cnt = 0;
  int len = s.size();
  for (int i = 0; i < len; i++) {
    if (s[i] == '1') {
      cnt++;
    }
  }
  for (int i = 0; i < len; i++) {
    if (s[i] == '0') {
      printf("0");
    }
    if (s[i] == '2') {
      while (cnt-- > 0) {
        printf("1");
      }
      printf("2");
    }
  }
  printf("\n");
}
