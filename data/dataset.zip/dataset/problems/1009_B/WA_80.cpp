#include <bits/stdc++.h>
using namespace std;
void func() {
  string s;
  cin >> s;
  long long n = s.length(), j = n;
  long long x = 0;
  long long two[n];
  two[x++] = 0;
  for (long long i = 0; i < n; ++i) {
    if (s[i] == '2') {
      two[x++] = i;
    }
  }
  two[x++] = n;
  for (long long i = 0; i < x - 1; ++i) {
    if (i == 0) {
      sort(s.begin() + two[i], s.begin() + two[i + 1]);
    } else {
      sort(s.begin() + two[i], s.begin() + two[i + 1], greater<char>());
    }
  }
  long long m = two[1];
  while (s[m + 1] == '1' && m < n - 1) {
    swap(s[m], s[m + 1]);
    ++m;
  }
  for (long long i = 2; i < x - 1; ++i) {
    long long j = two[i] + 1;
    while (s[j] == '1' && s[j - 1] == '2' && j > 0) {
      swap(s[j - 1], s[j]);
      --j;
    }
  }
  cout << s << "\n";
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  long long t = 1;
  while (t--) {
    func();
  }
}
