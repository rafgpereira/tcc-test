#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(false);
  string s;
  cin >> s;
  for (int i = 0; i < s.size(); i++) {
    if ((s[i] == '1' && s[i + 1] == '0') || (s[i] == '2' && s[i + 1] == '1')) {
      int j = i;
      while ((s[j] == '1' && s[j + 1] == '0') ||
             (s[j] == '2' && s[j + 1] == '1')) {
        swap(s[j], s[j + 1]);
        j--;
      }
    }
  }
  for (int i = 0; i < s.size(); i++) {
    cout << s[i];
  }
}
