#include <bits/stdc++.h>
using namespace std;
string s, t;
int main() {
  while (cin >> s) {
    int k = 0, l = s.length();
    t = "";
    for (int i = 0; i < s.length(); i++) {
      if (s[i] == '1')
        k++;
      else
        t += s[i];
    }
    int j = 0;
    while (t[j] != '2' && j < t.length()) j++;
    if (j < t.length() && k) {
      for (int i = 0; i < j; i++) {
        s[i] = t[i];
      }
      for (int i = j; i < j + k; i++) {
        s[i] = '1';
      }
      for (int i = j + k; i < l; i++) {
        s[i] = t[i - k];
      }
    }
    cout << s << endl;
  }
  return 0;
}
