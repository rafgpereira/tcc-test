#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 1;
int n, a[N];
string s;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie();
  cin >> s;
  n = s.size();
  for (int i = 1; i <= n; i++) a[i] = s[i - 1] - '0';
  int it = 1, cur = -1;
  for (int i = 1; i <= n; i++) {
    if (cur == -1 && a[i] != 1) cur = a[i];
    if (a[i] == 1 || a[i] == cur) continue;
    sort(a + it, a + i);
    cur = a[i];
    it = i;
  }
  sort(a + it, a + n + 1);
  for (int i = 1; i <= n; i++) cout << a[i];
  cout << endl;
}
