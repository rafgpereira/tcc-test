#include <bits/stdc++.h>
using namespace std;
template <class T>
bool mmin(T &a, T b) {
  return (a > b ? (a = b, true) : false);
};
template <class T>
bool mmax(T &a, T b) {
  return (a < b ? (a = b, true) : false);
};
int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  string s1;
  cin >> s1;
  long long ini = 0;
  char k = s1[0], v = 1;
  bool val = false;
  for (long long i = 0; i < (long long)s1.size(); i++) {
    if (val and (s1[i] == k or s1[i] == v)) continue;
    if (k != s1[i] and !val and abs(k - s1[i]) == 1) {
      val = true;
      v = k;
      k = s1[i];
    } else if (k != s1[i] and val) {
      val = false;
      sort(s1.begin() + ini, s1.begin() + i);
      k = s1[i];
      ini = i;
    }
  }
  if (val) sort(s1.begin() + ini, s1.end());
  cout << s1 << '\n';
  return 0;
}
