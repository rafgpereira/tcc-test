#include <bits/stdc++.h>
using namespace std;
int main() {
  queue<char> zero, one, two, answer;
  string s;
  cin >> s;
  for (int i = 0; i < s.length(); i++) {
    char c;
    c = s[i];
    if (c == '0') {
      while (two.size() != 0) {
        zero.push('2');
        two.pop();
      }
      zero.push('0');
    } else if (c == '1') {
      one.push('1');
    } else {
      two.push('2');
    }
  }
  while (one.size() != 0) {
    zero.push('1');
    one.pop();
  }
  while (two.size() != 0) {
    zero.push('2');
    two.pop();
  }
  while (zero.size() != 0) {
    answer.push(zero.front());
    zero.pop();
  }
  while (answer.size() != 0) {
    cout << answer.front();
    answer.pop();
  }
  return 0;
}
