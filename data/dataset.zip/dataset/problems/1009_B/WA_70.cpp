#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 10;
char s[maxn];
void work() {
  scanf("%s", s);
  int len = strlen(s);
  for (int i = len - 1; i >= 1; i--) {
    if (s[i] == '0') {
      if (s[i - 1] == '1') {
        s[i - 1] = '0';
        s[i] = '1';
      }
    } else if (s[i] == '1') {
      if (s[i - 1] == '2') {
        s[i - 1] = '1';
        s[i] = '2';
      }
    }
  }
  printf("%s\n", s);
}
int main() {
  work();
  return 0;
}
