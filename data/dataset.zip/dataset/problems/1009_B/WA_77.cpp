#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  int n = s.size();
  bool is0 = 0;
  bool is1 = 0;
  bool is2 = 0;
  for (int i = 0; i < n; i++)
    if (s[i] == '0')
      is0 = 1;
    else if (s[i] == '1')
      is1 = 1;
    else
      is2 = 1;
  if (!is0 || !is2) {
    sort(s.begin(), s.end());
    cout << s << endl;
    return 0;
  }
  if (!is1) {
    cout << s << endl;
    return 0;
  }
  for (int i = 0; i < n - 1; i++)
    if ((s[i] == '1' && s[i + 1] == '0') || (s[i] == '2' && s[i + 1] == '1'))
      swap(s[i], s[i + 1]);
  cout << s << endl;
  return 0;
}
