#include <bits/stdc++.h>
using namespace std;
const long long int MAX = 9187201950435737471;
const double pi = acos(-1);
const int N = 250009;
const long long mod = 1000000007;
const int M = 2147483647;
const int lg = 101;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  int t = 1;
  while (t--) {
    string s;
    cin >> s;
    int n = (int)s.size();
    ;
    int it = 0;
    for (int i = 0; i < n; i++)
      if (s[i] != '0') {
        it = i;
        break;
      }
    for (int i = it; i < n; i++) {
      if (s[i] == '0') {
        sort(s.begin() + it, s.begin() + i);
        it = i + 1;
      }
      if (i == n - 1 && it != n) sort(s.begin() + it, s.begin() + n);
    }
    it = 0;
    for (int i = 0; i < n; i++)
      if (s[i] != '2') {
        it = i;
        break;
      }
    for (int i = it; i < n; i++) {
      if (s[i] == '2') {
        sort(s.begin() + it, s.begin() + i);
        it = i + 1;
      }
      if (i == n - 1 && it != n) {
        sort(s.begin() + it, s.begin() + n);
      }
    }
    cout << s << "\n";
  }
  return 0;
}
