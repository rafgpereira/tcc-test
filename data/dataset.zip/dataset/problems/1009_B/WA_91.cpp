#include <bits/stdc++.h>
using namespace std;
int main() {
  long long i = 0, j = 0, k = 0, l = 0, m, n, s = 0, x = 0, y = 0, d;
  string st, an = "", bn = "", cn = "";
  cin >> st;
  for (i = 0; i < st.length();) {
    if (st[i] == '0') {
      an += '0';
      i++;
    } else if (st[i] == '1') {
      j = i + 1;
      x = 0;
      y = 1;
      while (j < st.length() && (st[j] == '0' || st[j] == '1')) {
        if (st[j] == '0')
          x++;
        else
          y++;
        j++;
      }
      for (k = 0; k < x; k++) an += '0';
      for (k = 0; k < y; k++) an += '1';
      i = j;
    } else if (st[i] == '2') {
      j = i + 1;
      x = 0;
      y = 1;
      while (j < st.length() && (st[j] == '2' || st[j] == '1')) {
        if (st[j] == '1')
          x++;
        else
          y++;
        j++;
      }
      for (k = 0; k < x; k++) an += '1';
      for (k = 0; k < y; k++) an += '2';
      i = j;
    }
  }
  for (i = 0; i < st.length();) {
    if (st[i] == '1') {
      bn += '1';
      i++;
    } else if (st[i] == '0') {
      j = i + 1;
      x = 0;
      y = 1;
      while (j < st.length() && (st[j] == '0' || st[j] == '1')) {
        if (st[j] == '0')
          y++;
        else
          x++;
        j++;
      }
      for (k = 0; k < x; k++) bn += '1';
      for (k = 0; k < y; k++) bn += '0';
      i = j;
    } else if (st[i] == '2') {
      j = i + 1;
      x = 0;
      y = 1;
      while (j < st.length() && (st[j] == '2' || st[j] == '1')) {
        if (st[j] == '1')
          x++;
        else
          y++;
        j++;
      }
      for (k = 0; k < x; k++) bn += '1';
      for (k = 0; k < y; k++) bn += '2';
      i = j;
    }
  }
  for (i = 0; i < st.length();) {
    if (bn[i] == '0') {
      cn += '0';
      i++;
    } else if (bn[i] == '1') {
      j = i + 1;
      x = 0;
      y = 1;
      while (j < bn.length() && (bn[j] == '0' || bn[j] == '1')) {
        if (bn[j] == '0')
          x++;
        else
          y++;
        j++;
      }
      for (k = 0; k < x; k++) cn += '0';
      for (k = 0; k < y; k++) cn += '1';
      i = j;
    } else if (bn[i] == '2') {
      j = i + 1;
      x = 0;
      y = 1;
      while (j < st.length() && (bn[j] == '2' || bn[j] == '1')) {
        if (bn[j] == '1')
          x++;
        else
          y++;
        j++;
      }
      for (k = 0; k < x; k++) cn += '1';
      for (k = 0; k < y; k++) cn += '2';
      i = j;
    }
  }
  cout << min(an, min(bn, cn));
}
