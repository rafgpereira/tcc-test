#include <bits/stdc++.h>
using namespace std;
ofstream fo("test.out");
ifstream fi("test.inp");
const long long MOD = 1e9 + 7;
const long long base = 269;
long long n, m, temp, k, rs, choose = 1e9;
vector<int> a, b;
string s;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  cin >> s;
  n = s.length();
  for (int i = 1; i < n; i++) {
    if (s[i] == '0' && s[i - 1] == '1') s[i] = '1', s[i - 1] = '0', i -= 2;
    if (s[i] == '1' && s[i - 1] == '2') s[i] = '2', s[i - 1] = '1', i -= 2;
    if (i >= 2) {
      if (s[i] == '1' && s[i - 1] == '0' && s[i - 2] == '2')
        s[i] = '2', s[i - 1] = '1', s[i - 2] = '0';
    }
  }
  cout << s;
  return 0;
}
