#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  for (int i = 0; i < s.length(); i++) {
    if (s[i] == '1' && s[i + 1] == '0') {
      swap(s[i], s[i + 1]);
      if (s[i - 1] == '1') {
        int j = i;
        while (s[j - 1] > s[j]) {
          swap(s[j - 1], s[j]);
          j--;
        }
      }
    } else if (s[i] == '2' && s[i + 1] == '1') {
      swap(s[i], s[i + 1]);
      if (s[i - 1] == '2') {
        int k = i;
        while (s[k - 1] > s[k]) {
          swap(s[k - 1], s[k]);
          k--;
        }
      }
    }
  }
  cout << s << endl;
}
