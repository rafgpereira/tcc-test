#include <bits/stdc++.h>
using namespace std;
void swap(char &c1, char &c2) {
  char c3 = c1;
  c1 = c2;
  c2 = c3;
}
int partition(string &s, int start, int end) {
  int p_idx = start;
  swap(s[(start + end) / 2], s[end]);
  for (int i = start; i < end; ++i) {
    if (s[i] <= s[end]) {
      swap(s[i], s[p_idx++]);
    }
  }
  swap(s[end], s[p_idx]);
  return (p_idx);
}
void sort(string &s, int start, int end) {
  if (start < end) {
    int p_idx = partition(s, start, end);
    sort(s, start, p_idx - 1);
    sort(s, p_idx + 1, end);
  }
}
string solve(string s) {
  map<char, int> M;
  for (int i = 0; i < s.size(); ++i) {
    M[s[i]] += 1;
  }
  switch (M.size()) {
    case 1:
      return (s);
    case 2: {
      string x = "";
      for (map<char, int>::iterator i = M.begin(); i != M.end(); ++i) {
        x += i->first;
      }
      if (x[1] - x[0] == 1) {
        sort(s, 0, s.size() - 1);
        return (s);
      }
    }
    case 3: {
      int i = 0, mx_idx = s.size() - 1;
      while (i < mx_idx) {
        if (s[i] > s[i + 1] && fabs(s[i] - s[i + 1]) == 1) {
          swap(s[i], s[i + 1]);
          ++i;
        } else
          ++i;
      }
      return (s);
    }
  }
}
int main() {
  string s;
  cin >> s;
  cout << solve(s);
  return (0);
}
