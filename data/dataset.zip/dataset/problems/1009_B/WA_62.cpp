#include <bits/stdc++.h>
using namespace std;
const long long N = 1e5 + 5;
const long long M = 1e6 + 5;
const long long mod = 1e9 + 7;
long long a[N], c[N];
signed main() {}
