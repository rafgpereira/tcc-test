#include <bits/stdc++.h>
using namespace std;
char s[100002];
int main() {
  cin >> s;
  int n = strlen(s);
  if (1 == n) {
    cout << s;
    return 0;
  }
  int c = 0;
  for (int i = 0; i < n - 1;) {
    if ('1' == s[i] && '0' == s[1 + i] ||
        '2' == s[i] && ('1' == s[1 + i] ||
                        i < n - 2 && '0' == s[i + 1] && '1' == s[2 + i])) {
      char t = s[i];
      s[i] = s[1 + i];
      s[1 + i] = t;
      if (i) --i;
    } else
      ++i;
  }
  cout << s;
  return 0;
}
