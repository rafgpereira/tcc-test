#include <bits/stdc++.h>
using namespace std;
int vis[100005];
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  string s;
  cin >> s;
  string str1 = "", str2 = "", ans = "";
  int n = s.length();
  int i;
  for (i = 0; i < n; i++) {
    if (s[i] == '2') break;
    ans += s[i];
  }
  int j = i;
  int k = i;
  for (; i < n; i++) {
    if (s[i] == '1') {
      ans += s[i];
      vis[i] = 1;
    }
  }
  i = 0;
  for (; i < ans.length(); i++) {
    if (ans[i] == '1') {
      j = i;
      while (i < ans.length()) {
        if (ans[i] == '0') {
          vis[i] = 1;
          str1 += ans[i];
        }
        i++;
      }
      break;
    } else {
      str1 += ans[i];
    }
  }
  while (j < ans.length()) {
    if (!vis[j]) {
      str1 += ans[j];
    }
    j++;
  }
  for (; k < n; k++) {
    if (!vis[k]) str2 += s[k];
  }
  str1 += str2;
  cout << str1 << endl;
  return 0;
}
