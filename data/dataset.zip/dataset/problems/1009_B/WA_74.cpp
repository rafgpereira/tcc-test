#include <bits/stdc++.h>
using namespace std;
long long gcd(long long a, long long b) {
  if (a == 0) return b;
  return gcd(b % a, a);
}
long long modexp(long long x, long long y, long long p) {
  long long res = 1;
  x = x % p;
  while (y > 0) {
    if (y & 1) res = (res * x) % p;
    y = y >> 1;
    x = (x * x) % p;
  }
  return res;
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  string s;
  cin >> s;
  char s1[s.length()];
  long long x = 0, f = 0;
  long long n = s.length();
  long long i1;
  for (long long i = 0, _n = (s.length()); i < _n; i++) {
    long long one = 0, two = 0, ze = 0;
    if (s[i] == '1' || s[i] == '0') {
      while (i < n && (s[i] == '1' || s[i] == '0')) {
        if (s[i] == '1') {
          one++;
        } else if (s[i] == '0') {
          ze++;
        }
        i++;
      }
    }
    if (two == 0) {
      while (ze--) {
        s1[x] = '0';
        x++;
      }
      while (one--) {
        s1[x] = '1';
        x++;
      }
    }
    i1 = i;
    i--;
    break;
  }
  long long one = 0, two = 0, ze = 0;
  for (; i1 < n; i1++) {
    if (s[i1] == '0') {
      ze++;
    } else if (s[i1] == '1')
      one++;
    else
      two++;
  }
  while (one--) {
    s1[x] = '1';
    x++;
  }
  while (two--) {
    s1[x] = '2';
    x++;
  }
  while (ze--) {
    s1[x] = '0';
    x++;
  }
  for (long long i = 0, _n = (n); i < _n; i++) {
    cout << s1[i];
  }
  return 0;
}
