#include <bits/stdc++.h>
using namespace std;
int n;
char s[100001];
int main() {
  scanf("%s", &s);
  n = strlen(s);
  for (int i = 0; i <= n - 1; i++) {
    if (s[i] == '1') {
      int k = i;
      for (int j = i + 1; j <= n - 1; j++) {
        if (s[j] == '0') {
          k = j;
          break;
        }
        if (s[j] == '2') break;
      }
      char tmp = s[i];
      s[i] = s[k];
      s[k] = tmp;
      if (k != i) i--;
    }
    if (s[i] == '2') {
      int k = i;
      for (int j = i + 1; j <= n - 1; j++) {
        if (s[j] == '0') break;
        if (s[j] == '1') {
          k = j;
          break;
        }
      }
      char tmp = s[i];
      s[i] = s[k];
      s[k] = tmp;
      if (k != i) i--;
    }
  }
  printf("%s", s);
  return 0;
}
