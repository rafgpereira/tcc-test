#include <bits/stdc++.h>
using namespace std;
const long double pi = 2 * acos(0.0);
const long long MOD = 1e18 + 7;
int32_t main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  long long t;
  t = 1;
  while (t--) {
    string s;
    cin >> s;
    long long n = s.length();
    long long i = 0;
    string ans = "";
    string sub = "";
    for (long long i = 0; i < n; i++) {
      if (s[i] == '1') {
        ans += s[i];
      } else
        sub += s[i];
    }
    if (ans == s) {
      cout << ans;
    } else {
      string ans1 = "";
      bool check = false;
      for (long long i = 0; i < sub.length(); i++) {
        if (sub[i] == '0') {
          ans1 += sub[i];
        } else if (check) {
          ans1 += sub[i];
        } else {
          ans1 += ans;
          ans1 += sub[i];
          check = true;
        }
      }
      cout << ans1;
    }
  }
  return 0;
}
