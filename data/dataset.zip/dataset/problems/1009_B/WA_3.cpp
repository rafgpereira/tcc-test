#include <bits/stdc++.h>
using namespace std;
char mainchar[100000 + 10];
int cnt_0, cnt_1, cnt_2, now = 0;
int v;
void ansout(int end) {
  for (int i = now; i <= end; i++) {
    if (mainchar[i] == '0')
      cnt_0++;
    else if (mainchar[i] == '1')
      cnt_1++;
    else
      cnt_2++;
  }
  for (int i = 1; i <= cnt_0; i++) cout << "0";
  for (int i = 1; i <= cnt_1; i++) cout << "1";
  for (int i = 1; i <= cnt_2; i++) cout << "2";
  cnt_0 = 0, cnt_2 = 0, cnt_1 = 0;
  now = end + 1;
  v = 0;
}
int main() {
  scanf("%s", mainchar);
  int len = strlen(mainchar);
  mainchar[len] = '0';
  for (int i = 0; i < len; i++) {
    if (mainchar[i] == '0' && v == 1) ansout(i - 1);
    if (mainchar[i] == '2') v = 1;
  }
  ansout(len - 1);
  cout << endl;
  return 0;
}
