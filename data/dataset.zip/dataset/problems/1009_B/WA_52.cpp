#include <bits/stdc++.h>
using namespace std;
const long long MOD = 1000000007;
template <typename T>
istream& operator>>(istream& i, vector<T>& v) {
  for (auto& e : v) i >> e;
  return i;
}
template <typename T>
ostream& operator<<(ostream& i, vector<T>& v) {
  for (auto& e : v) i << e << " ";
  return i;
}
template <typename T1, typename T2>
istream& operator>>(istream& i, vector<pair<T1, T2>>& v) {
  for (auto& e : v) i >> e.first >> e.second;
  return i;
}
template <typename T1, typename T2>
ostream& operator<<(ostream& i, vector<pair<T1, T2>>& v) {
  for (auto& e : v) i << e.first << " " << e.second << endl;
  return i;
}
void _start() {
  cin.sync_with_stdio(false);
  cout.sync_with_stdio(false);
  cin.tie(0);
}
template <typename T>
void _end(T out) {
  cout << out;
  exit(0);
}
int main() {
  _start();
  string s;
  cin >> s;
  vector<int> sf1(s.size());
  vector<int> done(s.size());
  for (int i = s.size() - 1; i >= 0; i--) {
    sf1[i] = i == s.size() - 1 ? s[i] == '1' : (s[i] == '1') + sf1[i + 1];
    if (s[i] == '2') {
      swap(s[i], s[i + sf1[i]]);
      done[i + sf1[i]] = 1;
      for (int j = i + sf1[i] + 1; j < s.size() && s[j] != '2'; j++) {
        s[j] = '0';
        done[j] = 1;
      }
    }
  }
  int i = 0;
  for (; s[i] != '2' && i < s.size(); i++)
    ;
  if (i < s.size() && s[i] == '2') {
    int c = sf1[i];
    while (c--) {
      s[--i] = '1';
    }
  }
  sf1 = vector<int>(s.size());
  for (int i = s.size() - 1; i >= 0; i--) {
    sf1[i] = i == s.size() - 1 ? s[i] == '0' : (s[i] == '0') + sf1[i + 1];
    if (s[i] == '2') sf1[i] = 0;
    if (s[i] == '1') {
      swap(s[i], s[i + sf1[i]]);
    }
  }
  _end(s);
}
