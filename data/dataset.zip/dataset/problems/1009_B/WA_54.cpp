#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
  string s;
  cin >> s;
  int n = (int)s.size();
  while (true) {
    bool ok = false;
    for (int i = 0; i < n - 1; i++) {
      if (s[i] == '1' && s[i + 1] == '0' || s[i] == '2' && s[i + 1] == '1')
        swap(s[i], s[i + 1]), ok = true;
    }
    if (!ok) break;
  }
  cout << s;
  return 0;
}
