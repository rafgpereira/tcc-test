#include <bits/stdc++.h>
using namespace std;
int main() {
  string str, ans;
  cin >> str;
  int n = 0;
  for (int i = 0; str[i] != '\0'; i++)
    if (str[i] == '2') n++;
  int count0 = 0, count1 = 0, count2 = 0, flag = 0;
  for (int i = 0; str[i] != '\0'; i++) {
    if (str[i] == '2') {
      for (int j = 0; j < count0; j++) {
        ans += "0";
      }
      count0 = 0;
      flag = 1;
      count2++;
    }
    if (str[i] == '0') {
      if (flag == 1) {
        for (int j = 0; j < count1; j++) {
          ans += "1";
        }
        count1 = 0;
        for (int j = 0; j < count2; j++) {
          ans += "2";
        }
        count2 = 0;
      }
      flag = 0;
      count0++;
    }
    if (str[i] == '1') count1++;
  }
  while (count0 != 0) {
    ans += "0";
    count0--;
  }
  while (count1 != 0) {
    ans += "1";
    count1--;
  }
  while (count2 != 0) {
    ans += "2";
    count2--;
  }
  cout << ans;
}
