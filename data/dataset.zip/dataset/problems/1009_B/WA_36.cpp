#include <bits/stdc++.h>
using namespace std;
void print(char *a, int n, int count) {
  while (count--) {
    cout << "1";
  }
  for (int i = n; a[i] != '\0'; i++) {
    if (a[i] != '1') {
      cout << a[i];
    }
  }
}
int main(int argc, char const *argv[]) {
  char *a = new char[100000];
  cin >> a;
  int count1 = 0;
  for (int i = 0; a[i] != '\0'; i++) {
    if (a[i] == '1') {
      count1++;
    }
  }
  for (int i = 0; a[i] != '\0'; i++) {
    if (a[i] == '0') {
      cout << a[i];
    } else if (a[i] == '2') {
      print(a, i, count1);
      return 0;
    }
  }
  return 0;
}
