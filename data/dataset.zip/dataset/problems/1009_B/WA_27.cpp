#include <bits/stdc++.h>
using namespace std;
const int inf = (1ll << 31) - 1;
const long long INF = (1ull << 63) - 1;
template <typename T>
void read(T &x) {
  x = 0;
  bool f = 1;
  char ch;
  do {
    ch = getchar();
    if (ch == '-') f = 0;
  } while (ch > '9' || ch < '0');
  do {
    x = x * 10 + ch - '0';
    ch = getchar();
  } while (ch >= '0' && ch <= '9');
  x = f ? x : -x;
}
template <typename T>
void write(T x) {
  if (x < 0) x = ~x + 1, putchar('-');
  if (x > 9) write(x / 10);
  putchar(x % 10 + '0');
}
template <typename T>
void Ckmax(T &x, T y) {
  if (x == -1) x = y;
  x = x > y ? x : y;
}
template <typename T>
void Ckmin(T &x, T y) {
  if (x == -1) x = y;
  x = x < y ? x : y;
}
template <typename T>
void Swap(T &x, T &y) {
  x ^= y ^= x ^= y;
}
template <typename T>
T Abs(T x) {
  return x > 0 ? x : -x;
}
template <typename T>
void Add(T &x, T v, T mod) {
  x += v;
  x = x >= mod ? x - mod : x;
}
template <typename T>
void Del(T &x, T v, T mod) {
  x -= v;
  x = x < 0 ? x + mod : x;
}
const int N = 1e5 + 7;
char ch[N];
int n, sum[4][N];
bool flag;
vector<int> ans;
int main() {
  cin >> ch;
  sum[ch[0] - '0'][0]++;
  n = strlen(ch);
  for (int i = 1; i < n; i++) {
    for (int j = 0; j <= 2; j++) sum[j][i] = sum[j][i - 1];
    sum[ch[i] - '0'][i] = sum[ch[i] - '0'][i] + 1;
  }
  for (int i = 0; i < n; i++) {
    if (ch[i] == '2') {
      for (int j = 0; j < sum[0][i]; j++) ans.push_back(0);
      for (int j = 0; j < sum[1][n - 1]; j++) ans.push_back(1);
      for (int j = i; j < n; j++) {
        if (ch[j] == '2') ans.push_back(2);
        if (ch[j] == '0') ans.push_back(0);
      }
      flag = false;
      break;
    }
  }
  if (flag) {
    for (int i = 1; i < sum[0][n - 1]; i++) printf("0");
    for (int i = 1; i < sum[1][n - 1]; i++) printf("1");
    puts("");
  } else {
    for (int i = 0; i < ans.size(); i++) printf("%d", ans[i]);
    puts("");
  }
  return 0;
}
