#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  int one = 0;
  for (int i = 0; i < s.length(); i++) {
    if (s[i] == '1') one++;
  }
  for (int i = 0; i < s.length(); i++) {
    if (s[i] == '0') printf("0");
    if (s[i] == '2') {
      while (one) {
        one--;
        printf("1");
      }
      printf("2");
    }
  }
  printf("\n");
  return 0;
}
