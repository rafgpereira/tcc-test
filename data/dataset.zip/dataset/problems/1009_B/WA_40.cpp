#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  string s;
  cin >> s;
  int n = s.length();
  string ans = "";
  int cnt1 = 0;
  for (int i = 0; i < n; i++) {
    if (s[i] - '0' == 1)
      cnt1++;
    else
      ans += s[i];
  }
  int m = ans.length();
  bool flag = true;
  for (int i = 0; i < m; i++) {
    if (ans[i] - '0' == 0)
      cout << '0';
    else {
      if (flag) {
        flag = false;
        while (cnt1-- > 0) cout << '1';
      }
      cout << '2';
    }
  }
  return 0;
}
