#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  while (1) {
    int i = 0;
    for (i = 0; i < s.length(); i++) {
      if (s[i] == '1' && s[i + 1] == '0') {
        char c;
        c = s[i];
        s[i] = s[i + 1];
        s[i + 1] = c;
      }
      if (s[i] == '2' && s[i + 1] == '1') {
        char c;
        c = s[i];
        s[i] = s[i + 1];
        s[i + 1] = c;
      }
    }
    string sub = "10";
    string sub1 = "21";
    if (i == s.length()) {
      if (s.find(sub1) == -1 && s.find(sub) == -1) {
        break;
      } else
        continue;
    }
  }
  cout << s;
  return 0;
}
