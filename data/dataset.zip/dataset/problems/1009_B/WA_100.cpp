#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  string s;
  cin >> s;
  int n = s.length();
  int pos = 0;
  int k = s[pos] - '0';
  for (int i = 1; i < n; i++) {
    int cur = s[i] - '0';
    if ((k == 2 && cur == 0) || cur == k) continue;
    if (cur < k) {
      swap(s[pos], s[i]);
      pos++;
    } else {
      pos = i;
      k = s[i] - '0';
    }
  }
  cout << s;
  return 0;
}
