#include <bits/stdc++.h>
using namespace std;
void swap(char &c1, char &c2) {
  char c3 = c1;
  c1 = c2;
  c2 = c3;
}
void solve(string &s, int start) {
  int i = start, mx_idx = s.size() - 1;
  while (i < mx_idx) {
    if (s[i] > s[i + 1] && fabs(s[i] - s[i + 1]) == 1) {
      swap(s[i], s[i + 1]);
      ++i;
    } else
      ++i;
  }
}
int need_parsing(string &s) {
  int mx_idx = s.size() - 1;
  for (int i = 0; i < mx_idx; ++i) {
    if (s[i] > s[i + 1] && fabs(s[i] - s[i + 1]) == 1) return (i);
  }
  return (-1);
}
int main() {
  string s;
  cin >> s;
  int start = -1;
  while ((start = need_parsing(s)) != -1) {
    solve(s, start);
  }
  cout << s << endl;
  return (0);
}
