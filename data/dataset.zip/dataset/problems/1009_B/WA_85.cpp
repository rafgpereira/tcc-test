#include <bits/stdc++.h>
using namespace std;
int main() {
  char str[100010];
  int len, i, j, a[100010], b = 0, c = 0;
  scanf("%s", &str);
  len = strlen(str);
  a[c] = 0;
  for (i = 0; i < len; i++) {
    if (str[i] != '2') {
      if (str[i] == '0') {
        a[c]++;
      } else if (str[i] == '1') {
        b++;
      }
    } else {
      c++;
      a[c] = 0;
    }
  }
  for (i = 0; i < c; i++) {
    for (j = 0; j < a[i]; j++) {
      printf("0");
    }
    if (i == 0) {
      for (j = 0; j < b; j++) {
        printf("1");
      }
    }
    printf("2");
  }
  for (j = 0; j < a[c]; j++) {
    printf("0");
  }
  return 0;
}
