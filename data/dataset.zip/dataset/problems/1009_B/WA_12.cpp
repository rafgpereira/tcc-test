#include <bits/stdc++.h>
using namespace std;
using ll = long long;
int c0, c1, c2;
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  string s, z;
  cin >> s;
  int l = 0, c[3] = {};
  for (int i = 0; i < s.size(); ++i) {
    c[s[i] - '0']++;
    if (c[0] && c[2]) {
      sort(s.begin() + l, s.begin() + i);
      l = i;
      i--;
      memset(c, 0, sizeof c);
    }
  }
  sort(s.begin() + l, s.end());
  cout << s;
}
