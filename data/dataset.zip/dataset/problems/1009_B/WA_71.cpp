#include <bits/stdc++.h>
using namespace std;
void IO() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  ;
}
int32_t main() {
  IO();
  long long int t = 1;
  while (t--) {
    string s;
    cin >> s;
    long long int n = s.size();
    string temp = "";
    string ans = "";
    long long int i = 0;
    long long int zero = 0, two = 0;
    while (i < n) {
      if (zero == 1 && s[i] == '2') {
        sort(temp.begin(), temp.end());
        ans += temp;
        temp = s[i];
        zero = 0;
        two = 1;
      } else if (two == 1 && s[i] == '0') {
        sort(temp.begin(), temp.end());
        ans += temp;
        temp = s[i];
        zero = 1;
        two = 0;
      } else {
        temp += s[i];
        if (s[i] == '2')
          two = 1;
        else if (s[i] == '0')
          zero = 1;
      }
      i++;
    }
    if (temp.size() > 0) {
      sort(temp.begin(), temp.end());
      ans += temp;
    }
    cout << ans << "\n";
  }
}
