#include <bits/stdc++.h>
using namespace std;
struct comp {
  bool operator()(int a, int b) { return a > b; }
};
int main() {
  int n, numOf1 = 0;
  char data[100005];
  scanf("%s", data);
  n = (int)strlen(data);
  for (int i = 0; i <= n - 1; i++)
    if (data[i] == '1') numOf1++;
  for (int i = 0; i <= n - 1; i++) {
    if (data[i] != '1') {
      if (data[i] == '2') {
        for (int j = 1; j <= numOf1; j++) printf("1");
        numOf1 = 0;
      }
      printf("%c", data[i]);
    }
  }
  printf("\n");
  return 0;
}
