#include <bits/stdc++.h>
using namespace std;
void go(int x, int &y) {
  while (y) {
    cout << x;
    y--;
  }
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int i, len, zero, two, one, temp;
  bool flag = false;
  string s;
  cin >> s;
  len = s.length();
  i = one = two = zero = 0;
  while (i < len) {
    if (s[i] == '2') {
      if (!flag) {
        go(0, zero);
        go(1, one);
        flag = true;
      }
      two++;
      i++;
      while (i < len and (s[i] != '2' or !zero)) {
        if (s[i] == '2')
          ++two;
        else if (s[i] == '1')
          ++one;
        else
          ++zero;
        ++i;
      }
      go(1, one);
      go(2, two);
      go(0, zero);
    } else if (s[i] == '0')
      ++zero, ++i;
    else
      ++one, ++i;
  }
  go(0, zero);
  go(1, one);
  assert(one == 0 and two == 0 and zero == 0);
  return 0;
}
