#include <bits/stdc++.h>
using namespace std;
int N;
string A;
int res[100000];
int main() {
  cin >> A;
  N = A.size();
  int x = 0;
  while (x < N) {
    int y = x;
    while (x < N && A[x] != '2') {
      res[x] = (int)(A[x] - '0');
      x++;
    }
    sort(res + y, res + x);
    y = x;
    while (x < N && A[x] != '0') {
      res[x] = (int)(A[x] - '0');
      x++;
    }
    sort(res + y, res + x);
  }
  for (int i = 0; i < N; i++) cout << res[i];
  cout << endl;
  return 0;
}
