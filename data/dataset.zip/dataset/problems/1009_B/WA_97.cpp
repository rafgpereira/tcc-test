#include <bits/stdc++.h>
using namespace std;
int main(void) {
  long long i, j, b, temp;
  char s[1000001];
  cin >> s;
  for (i = 0; i < strlen(s); i++) {
    b = 0;
    for (j = 0; j < strlen(s) - 1; j++) {
      if (s[j] - s[j + 1] == 1) {
        temp = s[j];
        s[j] = s[j + 1];
        s[j + 1] = temp;
        b = 1;
      }
    }
    if (b == 0) break;
  }
  cout << s;
  return 0;
}
