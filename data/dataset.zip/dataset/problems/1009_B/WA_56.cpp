#include <bits/stdc++.h>
using namespace std;
const int maxn = 100010;
char s[maxn];
int main() {
  while (~scanf("%s", s)) {
    int n = strlen(s), cnt = 0, t = -1;
    for (int i = 0; i < n; i++) {
      if (s[i] - '0' == 1) ++cnt;
      if (t == -1 && s[i] - '0' == 2) t = i;
    }
    for (int i = 0; i < t; i++) {
      if (s[i] - '0' != 1) printf("%c", s[i]);
    }
    for (int i = 0; i < cnt; i++) printf("%c", '1');
    for (int i = t; i < n; i++)
      if (s[i] - '0' != 1) printf("%c", s[i]);
    puts("");
  }
}
