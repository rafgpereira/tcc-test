#include <bits/stdc++.h>
using namespace std;
vector<int> noprimes(1000001);
void seive(vector<int> &primes, int n) {
  vector<bool> ntprimes(n + 1, false);
  ntprimes[0] = ntprimes[1] = true;
  for (int i = 2; i * i <= n; i++) {
    if (!ntprimes[i]) {
      for (int j = i * i; j <= n; j += i) {
        ntprimes[j] = true;
      }
    }
  }
  int x = 0;
  for (int i = 2; i <= n; i++) {
    if (!ntprimes[i]) {
      primes.push_back(i);
      x++;
      noprimes[i] = x;
    } else
      noprimes[i] = x;
  }
}
long long pow(long long x, long long n) {
  long long res = 1;
  while (n) {
    if (n % 2 == 0) {
      n = n / 2;
      x = x * x;
    } else {
      res *= x;
      n--;
    }
  }
  return res;
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  string s;
  cin >> s;
  string ans;
  int flag = 1;
  int cnt1 = 0;
  int cnt0 = 0;
  int cnt2 = 0;
  int index = s.size();
  for (int i = 0; i < s.size(); i++) {
    if (index == s.size() && s[i] == '2') {
      index = i;
    }
    if (s[i] == '2')
      cnt2++;
    else if (s[i] == '1')
      cnt1++;
    else
      cnt0++;
  }
  int cnt = 0;
  int count = 0;
  for (int i = 0; i < index; i++) {
    if (s[i] == '0') {
      ans = '0' + ans;
      count++;
    } else {
      ans = ans + '1';
      cnt++;
    }
  }
  cnt1 -= cnt;
  cnt0 -= count;
  for (int i = 0; i < cnt1; i++) ans += '1';
  for (int i = 0; i < cnt2; i++) ans += '2';
  for (int i = 0; i < cnt0; i++) ans += '0';
  cout << ans;
  return 0;
}
