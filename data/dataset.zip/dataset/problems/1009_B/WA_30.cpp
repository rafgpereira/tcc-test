#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 5;
const int mod = 1e9 + 7;
char s[maxn];
struct node {
  int num1, num2;
  int flag;
};
vector<node> a;
char ans[maxn];
int main() {
  while (~scanf("%s", s)) {
    a.clear();
    int len = strlen(s);
    char tmp = '1';
    int num0 = 0, num1 = 0, num2 = 0;
    for (int i = 0; i < len; i++) {
      if (tmp == '1') tmp = s[i];
      if (s[i] == '0') num0++;
      if (s[i] == '1') num1++;
      if (s[i] == '2') num2++;
      if (tmp == '0' && s[i + 1] == '2') {
        node x;
        x.num1 = num0;
        x.num2 = num1;
        x.flag = 0;
        a.push_back(x);
        num0 = 0;
        num1 = 0;
        num2 = 0;
        tmp = '2';
      } else if (tmp == '2' && s[i + 1] == '0') {
        node x;
        x.num1 = num1;
        x.num2 = num2;
        x.flag = 1;
        a.push_back(x);
        num0 = 0;
        num1 = 0;
        num2 = 0;
        tmp = '0';
      } else if (i == len - 1) {
        if (tmp == '0') {
          node x;
          x.num1 = num0;
          x.num2 = num1;
          x.flag = 0;
          a.push_back(x);
        } else if (tmp == '2') {
          node x;
          x.num1 = num1;
          x.num2 = num2;
          x.flag = 1;
          a.push_back(x);
        } else {
          node x;
          x.num1 = num0;
          x.num2 = num1;
          x.flag = 0;
          a.push_back(x);
        }
      }
    }
    int cnt = 0;
    for (int i = 0; i < a.size(); i++) {
      if (a[i].flag == 0) {
        for (int j = 0; j < a[i].num1; j++) {
          ans[cnt++] = '0';
        }
        for (int j = 0; j < a[i].num2; j++) {
          ans[cnt++] = '1';
        }
      } else {
        for (int j = 0; j < a[i].num1; j++) {
          ans[cnt++] = '1';
        }
        for (int j = 0; j < a[i].num2; j++) {
          ans[cnt++] = '2';
        }
      }
    }
    for (int i = 0; i < cnt; i++) {
      printf("%c", ans[i]);
    }
    printf("\n");
  }
  return 0;
}
