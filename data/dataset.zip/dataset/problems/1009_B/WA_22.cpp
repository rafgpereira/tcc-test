#include <bits/stdc++.h>
using namespace std;
int32_t main() {
  string s;
  cin >> s;
  for (int i = 0; i < s.size() - 1; ++i) {
    if ((s[i] == '1' && s[i + 1] == '0') || (s[i] == '2' && s[i + 1] == '1')) {
      swap(s[i], s[i + 1]);
    }
  }
  for (int i = s.size() - 1; i > 1; --i) {
    if ((s[i] == '0' && s[i - 1] == '1') || (s[i] == '1' && s[i - 1] == '2')) {
      swap(s[i], s[i - 1]);
    }
  }
  for (int i = 0; i < s.size(); ++i) {
    if (s[i] == '0') {
      int k = i;
      while (k > 0 && s[k - 1] == '1') {
        swap(s[k], s[k - 1]);
        --k;
      }
    }
  }
  for (int i = s.size() - 1; i > 0; --i) {
    if (s[i] == '2') {
      int k = i;
      while (k < s.size() && s[k + 1] == '1') {
        swap(s[k], s[k + 1]);
        ++k;
      }
    }
  }
  for (int i = 0; i < s.size() - 1; ++i) {
    if ((s[i] == '1' && s[i + 1] == '0') || (s[i] == '2' && s[i + 1] == '1')) {
      swap(s[i], s[i + 1]);
    }
  }
  for (int i = s.size() - 1; i > 1; --i) {
    if ((s[i] == '0' && s[i - 1] == '1') || (s[i] == '1' && s[i - 1] == '2')) {
      swap(s[i], s[i - 1]);
    }
  }
  cout << s;
  return 0;
}
