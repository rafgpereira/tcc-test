#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  string arr;
  cin >> arr;
  int n = arr.length();
  int i = 0, j = 0;
  while (j < n && i < n) {
    if (arr[i] == '0') {
      while (j < n && arr[j] == '0') j++;
      i = j;
    }
    if (arr[i] == '1') {
      while (j < n && arr[j] == '1') {
        j++;
      }
      if (arr[j] == '2')
        i = j;
      else if (arr[j] == '0') {
        swap(arr[i], arr[j]);
        i++;
        j++;
      }
    }
    if (arr[i] == '2') {
      while (j < n && arr[j] == '2') j++;
      if (arr[j] == '1') {
        swap(arr[i], arr[j]);
        i++;
        j++;
      } else
        i = j;
    }
  }
  cout << arr;
}
