#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  while (cin >> s) {
    int n = s.size();
    int f = 1;
    while (f) {
      f = 0;
      for (int i = 0; i < n - 1; i += 1) {
        if (s[i] == '1' && s[i + 1] == '0') {
          f = 1;
          s[i] = '0';
          s[i + 1] = '1';
        }
        if (s[i] == '2' && s[i + 1] == '1') {
          f = 1;
          s[i] = '1';
          s[i + 1] = '2';
        }
      }
    }
    cout << s << endl;
  }
  return 0;
}
