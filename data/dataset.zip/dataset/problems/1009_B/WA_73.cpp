#include <bits/stdc++.h>
using namespace std;
long long n, sz, cnt[10] = {0}, x, fl = 0;
string s;
int main() {
  cin >> s;
  sz = s.size();
  for (long long i = 0; i <= sz - 1; i++) {
    if (s[i] == '0') {
      fl = 1;
      break;
    } else if (s[i] == '1')
      cnt[1]++;
    else
      cnt[2]++;
  }
  if (fl == 0) {
    for (long long i = 0; i <= sz - 1; i++) {
      if (cnt[1] == 0) {
        x = i;
        break;
      }
      cout << 1;
      cnt[1]--;
    }
    for (long long i = x; i <= sz - 1; i++) {
      if (cnt[2] == 0) break;
      cout << 2;
      cnt[2]--;
    }
    cout << endl;
    return 0;
  }
  cnt[0] = 0, cnt[1] = 0;
  for (long long i = sz - 1; i >= 0; i--) {
    if (s[i] == '0')
      cnt[0]++;
    else if (s[i] == '1')
      cnt[1]++;
    else {
      long long j;
      for (j = i; j < sz; j++) {
        if (cnt[1] == 0) break;
        s[j] = '1';
        cnt[1]--;
      }
      s[j] = '2';
      for (j = j + 1; j < sz; j++) {
        if (cnt[0] == 0) break;
        s[j] = '0';
        cnt[0]--;
      }
      cnt[0] = 0;
      cnt[1] = 0;
    }
  }
  if (cnt[0] > 0) {
    for (long long i = 0; i <= sz - 1; i++) {
      if (cnt[0] == 0) {
        x = i;
        break;
      }
      s[i] = '0';
      cnt[0]--;
    }
    for (long long i = x; i <= sz - 1; i++) {
      if (cnt[1] == 0) break;
      s[i] = '1';
      cnt[1]--;
    }
  }
  cout << s << endl;
  return 0;
}
