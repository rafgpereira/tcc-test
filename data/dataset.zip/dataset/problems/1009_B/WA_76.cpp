#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  string s;
  cin >> s;
  bool b = true;
  while (b) {
    b = false;
    for (int i = 0; i < s.size(); i++) {
      if (s[i] == '1' && s[i + 1] == '0') {
        swap(s[i + 1], s[i]);
        b = true;
      }
      if (s[i] == '2' && s[i + 1] == '1') {
        swap(s[i + 1], s[i]);
        b = true;
      }
    }
  }
  cout << s;
  return 0;
}
