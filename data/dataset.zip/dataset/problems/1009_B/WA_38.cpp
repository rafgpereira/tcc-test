#include <bits/stdc++.h>
using namespace std;
int main() {
  string str;
  cin >> str;
  int n = str.size();
  int one = 0;
  int zero = 0;
  int prev = -1;
  string ans;
  for (int i = 0; i < n; i++) {
    if (str[i] == '1')
      one++;
    else if (str[i] == '0')
      zero++;
    else if (str[i] == '2') {
      if (prev == -1) {
        for (int j = 0; j < zero; j++) ans += '0';
        for (int j = 0; j < one; j++) ans += '1';
        one = 0;
        zero = 0;
      } else {
        for (int j = 0; j < one; j++) ans += '1';
        ans += '2';
        for (int j = 0; j < zero; j++) ans += '0';
        one = 0;
        zero = 0;
      }
      prev = i;
    }
  }
  if (prev == -1) {
    for (int j = 0; j < zero; j++) ans += '0';
    for (int j = 0; j < one; j++) ans += '1';
  } else {
    for (int j = 0; j < one; j++) ans += '1';
    ans += '2';
    for (int j = 0; j < zero; j++) ans += '0';
  }
  for (int k = 0; k <= 100; k++) {
    for (int i = ans.size() - 1; i >= 0; i--) {
      if (ans[i] == '2') {
        int j = i + 1;
        while (ans[j] == '1') j++;
        ans[i] = '1';
        ans[j - 1] = '2';
      }
    }
  }
  cout << ans << endl;
  return 0;
}
