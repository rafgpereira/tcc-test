#include <bits/stdc++.h>
int main() {
  std::string str;
  std::getline(std::cin, str);
  std::vector<int> twoPos;
  for (int i = 0; i < str.length(); i++) {
    if (str[i] == '2') twoPos.push_back(i);
  }
  std::string res;
  twoPos.push_back(str.length());
  int c0 = 0, c1 = 0;
  for (int i = 0; i < twoPos[0]; i++) {
    if (str[i] == '0')
      c0++;
    else
      c1++;
  }
  for (int i = 0; i < c0; i++) res += '0';
  for (int i = 0; i < c1; i++) res += '1';
  int c2 = 0;
  for (int i = 0; i < twoPos.size() - 1; i++) {
    int c0 = 0;
    c1 = 0;
    for (int j = twoPos[i]; j < twoPos[i + 1]; j++) {
      if (str[j] == '0') c0++;
      if (str[j] == '1') c1++;
    }
    if (c0 == 0) {
      if (twoPos[i + 1] != str.length()) twoPos[i + 1] = twoPos[i];
    }
    c2++;
    if (c0 != 0 || twoPos[i + 1] == str.length()) {
      for (int i = 0; i < c1; i++) res += '1';
      for (int i = 0; i < c2; i++) res += '2';
      for (int i = 0; i < c0; i++) res += '0';
      c2 = 0;
    }
  }
  std::cout << res;
}
