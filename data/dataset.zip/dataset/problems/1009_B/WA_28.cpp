#include <bits/stdc++.h>
int main() {
  int a, b, c, d, m, n, i, j, t, r;
  char s[100010], p;
  for (i = 0; s[i - 1] != '\n'; i++) {
    scanf("%c", &s[i]);
    if (i > 0) {
      for (j = i; j > 0; j--) {
        if (s[j] == '1' && s[j - 1] == '2') {
          p = s[j];
          s[j] = s[j - 1];
          s[j - 1] = p;
          continue;
        } else if (s[j] == '0' && s[j - 1] == '1') {
          p = s[j];
          s[j] = s[j - 1];
          s[j - 1] = p;
          continue;
        }
        break;
      }
    }
  }
  printf("%s", s);
  return 0;
}
