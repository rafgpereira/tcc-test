#include <bits/stdc++.h>
using namespace std;
template <typename T>
class Sieve {
 public:
  vector<T> primes;
  vector<bool> is_prime;
  Sieve(int MAX = 1000000) {
    is_prime.resize(MAX + 1, true);
    is_prime[0] = is_prime[1] = false;
    for (long long int i = 2; i * i <= MAX; i++)
      if (is_prime[i])
        for (long long int j = i * i; j <= MAX; j += i) is_prime[j] = false;
    for (long long int i = 2; i <= MAX; i++)
      if (is_prime[i]) primes.push_back(i);
  }
};
template <typename T>
vector<vector<T>> matmul(const vector<vector<T>>& a,
                         const vector<vector<T>>& b) {
  int n = a.size(), m = b[0].size(), k = b.size();
  vector<vector<T>> c(n, vector<T>(m));
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      for (int l = 0; l < k; l++) c[i][j] += (a[i][k] * b[k][j]);
    }
  }
  return c;
}
template <typename T>
T extended_euclid(T a, T b, vector<T>& X) {
  if (b == 0) {
    X = {1, 0};
    return a;
  } else {
    T g = extended_euclid(b, a % b, X);
    vector<vector<T>> G = {{0LL, 1LL}, {1LL, -(a / b)}};
    X = matmul<T>(G, X);
    return g;
  }
}
template <typename T>
bool isPrime(T n) {
  if (n <= 1)
    return false;
  else if (n == 2 || n == 3)
    return true;
  else if (n % 2 == 0 || n % 3 == 0)
    return false;
  T x = 5;
  T p = 2;
  while (x * x <= n) {
    if (n % x == 0) return true;
    x += p;
    p = 6 - p;
  }
  return true;
}
template <typename T>
T binpow(T x, T n, T mod = 1000000007) {
  T ans = 1;
  x = x % mod;
  while (n >= 1) {
    if (n & 1) ans = (ans * x) % mod;
    x = (x * x) % mod;
    n >>= 1;
  }
  return ans;
}
template <typename T>
T gcd(T a, T b) {
  if (b == 0)
    return a;
  else
    return gcd(b, a % b);
}
class DisjointSets {
 public:
  int n;
  vector<int> parent;
  vector<int> sz;
  vector<pair<int, int>> loc;
  int rem;
  DisjointSets(int n) {
    this->n = n;
    parent.resize(n + 1);
    sz.resize(n + 1, 1);
    loc.resize(n + 1);
    for (int i = 1; i <= n; i++) parent[i] = i;
    rem = n;
  }
  int find(int i) {
    if (i != parent[i]) parent[i] = find(parent[i]);
    return parent[i];
  }
  void UnionBySize(int i, int j) {
    i = find(i);
    j = find(j);
    if (i == j) return;
    if (sz[i] < sz[j]) swap(i, j);
    parent[j] = i;
    sz[i] += sz[j];
    rem--;
  }
  void solve(int s) {
    vector<pair<long long int, pair<int, int>>> edgeList;
    for (int i = 1; i <= n; i++) {
      for (int j = i + 1; j <= n; j++) {
        long long int dist = powl(loc[i].first - loc[j].first, 2) +
                             powl(loc[i].second - loc[j].second, 2);
        edgeList.push_back({dist, {i, j}});
      }
    }
    sort(edgeList.begin(), edgeList.end());
    double ans = 0.0;
    for (int i = 0; i < edgeList.size(); i++) {
      int u = edgeList[i].second.first;
      int v = edgeList[i].second.second;
      if (find(u) != find(v)) {
        ans = sqrt(edgeList[i].first);
        UnionBySize(u, v);
      }
      if (rem == s) break;
    }
    cout << fixed << setprecision(2) << ans << "\n";
  }
};
class Graph {
 public:
  int n;
  vector<pair<long long int, pair<int, int>>> edges;
  Graph(int n) { this->n = n; }
  void add_edge(int u, int v, long long int w) { edges.push_back({w, {u, v}}); }
  void solve() {}
};
class SegmentTree {
 public:
  vector<int> t;
  int n, H;
  void init(int n) {
    this->n = n;
    t.resize(2 * n);
    this->H = sizeof(int) * 8 - __builtin_clz(n);
  }
  void build() {
    for (int i = n - 1; i > 0; i--) t[i] = min(t[i << 1], t[(i << 1) | 1]);
  }
  void update(int pos, int val) {
    for (t[pos += n] += val; pos > 1; pos >>= 1)
      t[pos >> 1] = t[pos] + t[pos ^ 1];
  }
  int query(int l, int r) {
    int res = 1e9;
    for (l += n, r += n; l < r; l >>= 1, r >>= 1) {
      if (l & 1) res = min(t[l++], res);
      if (r & 1) res = min(t[--r], res);
    }
    return res;
  }
};
bool isSubsequenceString(string x, string y) {
  int i = 0, j = 0;
  while (i < x.length() && j < y.length()) x[i] == y[j] ? i++, j++ : i++;
  return (j == y.length());
}
long long int max(long long int a, long long int b, long long int c) {
  return max(a, max(b, c));
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  string s;
  cin >> s;
  int n = s.length();
  string ans = "", one = "";
  for (int i = 0; i < n; i++) {
    if (s[i] == '1') one += s[i];
  }
  for (int i = 0; i < n; i++) {
    if (s[i] == '0')
      ans += s[i];
    else if (s[i] == '2') {
      ans += one;
      one = "";
      ans += s[i];
    }
  }
  cout << ans << "\n";
}
