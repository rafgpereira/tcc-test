#include <bits/stdc++.h>
using namespace std;
const long long N = 1e5 + 5;
const long long mod = 1e9 + 7;
const long long INF = 1e9;
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  {
    long long i, j, n, cnt = 0;
    string s, ans;
    cin >> s;
    n = s.size();
    for (long long i = 0; i < n; i++) {
      if (s[i] == '1') ans += '1';
    }
    for (long long i = 0; i < n; i++) {
      if (s[i] != '1') ans += s[i];
    }
    int f = 0;
    for (long long i = 0; i < ans.size(); i++) {
      if (s[i] == '2') {
        f = 1;
        sort(ans.begin(), ans.begin() + i);
        break;
      }
    }
    if (!f) sort((ans).begin(), (ans).end());
    cout << ans << endl;
  }
  return 0;
}
