#include <bits/stdc++.h>
using namespace std;
int main() {
  char aa[1000000];
  scanf("%s", aa);
  int l = strlen(aa);
  queue<int> a1, a2, a0;
  int a = 0, b = 0, c = 0;
  for (int i = 0; i < l; i++) {
    if ((aa[i] == '2') || (i == l - 1)) {
      if (aa[i] == '0') a++;
      a0.push(a);
      a = 0;
    }
    if (aa[i] == '0')
      a++;
    else if (aa[i] == '1')
      b++;
    else
      c++;
  }
  int p = a0.front();
  for (int i = 0; i < p; i++) {
    printf("0");
  }
  while (b--) {
    printf("1");
  }
  a0.pop();
  for (int k = 0; k < c; k++) {
    printf("2");
    p = a0.front();
    for (int x = 0; x < p; x++) {
      printf("0");
    }
  }
  return 0;
}
