#include <bits/stdc++.h>
using namespace std;
const int mxn = 4 * 1e5 + 10;
const long long inf = 1e15;
vector<int> v;
bool vis[mxn];
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  string s;
  cin >> s;
  int fi = -1;
  for (int i = 0; i < s.size(); i++) {
    if (s[i] == '2') {
      v.push_back(i);
    }
  }
  if (v.size() == 0) {
    sort(s.begin(), s.end());
    cout << s << endl;
  }
  int prev = 0;
  for (int i = 0; i < v.size(); i++) {
    for (int k = prev; k < v[i]; k++) {
      if (s[k] == '0') cout << s[k];
    }
    if (!vis[v[i]])
      for (int j = v[i] + 1; j < s.size(); j++) {
        if (s[j] == '1' || s[j] == '2') {
          vis[j] = true;
        } else {
          for (int k = prev; k < j; k++) {
            if (s[k] == '1') cout << s[k];
          }
          for (int k = prev; k < j; k++) {
            if (s[k] == '2') cout << s[k];
          }
          prev = j;
          break;
        }
      }
  }
  for (int k = prev; k < s.size(); k++) {
    if (s[k] == '2') cout << s[k];
  }
  for (int k = prev; k < s.size(); k++) {
    if (s[k] == '0') cout << s[k];
  }
  for (int k = prev; k < s.size(); k++) {
    if (s[k] == '1') cout << s[k];
  }
  cout << endl;
  return 0;
}
