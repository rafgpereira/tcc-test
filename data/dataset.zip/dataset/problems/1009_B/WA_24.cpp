#include <bits/stdc++.h>
namespace uchiha {
using namespace std;
template <class T>
using v = vector<T>;
template <class T>
using vv = vector<v<T>>;
template <class T>
using pri = priority_queue<T>;
template <class T>
using rpi = priority_queue<T, v<T>, greater<T>>;
using vc = v<char>;
using vs = v<string>;
using vd = v<long double>;
using vvi = v<vector<int>>;
using vvb = v<vector<bool>>;
using vvd = v<vd>;
template <class T>
inline void rd(T& a) {
  cin >> a;
}
template <class T>
inline void rd(v<T>& a) {
  T x;
  for (int i = (int)0; i < (int)a.size(); i++) {
    cin >> x;
    a[i] = x;
  }
}
template <class T>
inline void rd(vv<T>& a) {
  for (int i = (int)0; i < (int)a.size(); i++) {
    rd(a[i]);
  }
}
template <class T, class U>
inline void rd(pair<T, U>& p) {
  cin >> p.first >> p.second;
}
template <class T, class... Args>
inline void rd(T& a, Args&... args) {
  cin >> a;
  rd(args...);
}
template <class T>
inline void print(T a) {
  cout << (a) << endl;
}
template <class T>
inline void print(v<T> a) {
  for (auto x : a) cout << (x) << ' ';
  cout << endl;
}
template <class T>
inline void print(vv<T> a) {
  for (auto x : a) print(x);
}
template <class T>
inline void print(set<T> a) {
  for (auto it = a.begin(); it != a.end(); it++) cout << (*it) << ' ';
  cout << endl;
}
template <class T, class U>
inline void print(pair<T, U>& p) {
  cout << p.first << ' ' << p.second << endl;
}
template <class T, class... Args>
inline void print(T& a, Args&... args) {
  cout << a << ' ';
  print(args...);
}
inline int mintwo(int n) { return __builtin_ctzll(n); }
inline int maxtwo(int n) { return (int)log2(n); }
inline int onebits(int n) { return __builtin_popcountll(n); }
inline int ceil(int a, int b) { return (a + b - 1) / b; }
inline void mangekyo();
inline void subl() {}
long double _c = clock();
using i32 = int32_t;
template <class T>
inline T sum(v<T> a) {
  T s = 0;
  for (auto x : a) s += x;
  return s;
}
template <class T>
inline T min(v<T> a) {
  return *min_element((a).begin(), (a).end());
}
template <class T>
inline T max(v<T> a) {
  return *max_element((a).begin(), (a).end());
}
template <class T, class U>
inline long double pdiv(T a, U b) {
  return (1.0 * (a)) / (1.0 * (b));
}
template <class T>
inline void chxor(T& a, T b) {
  a = a ^ b;
}
template <class T, class U>
inline void chmax(T& a, U b) {
  if (a < b) a = b;
}
template <class T, class U>
inline void chmin(T& a, U b) {
  if (a > b) a = b;
}
template <class T, class U>
inline T max(T a, U b) {
  return a > b ? a : b;
}
template <class T, class U>
inline T min(T a, U b) {
  return a < b ? a : b;
}
template <class T>
v<T> pre_sum(v<T> a) {
  for (int i = (int)1; i < (int)a.size(); i++) a[i] += a[i - 1];
  return a;
}
template <class T>
v<T> suf_sum(v<T> a) {
  for (int i = (int)a.size() - 1 - 1; i > (int)0 - 1; i--) a[i] += a[i + 1];
  return a;
}
template <class T, class U>
T POW(T x, T y, U m) {
  T a = 1;
  while (y) {
    if (y & 1) a = (a * x) % m;
    x = (x * x) % m;
    y >>= 1;
  }
  return a;
}
inline bool tle() {
  bool b = (((clock() - _c) / CLOCKS_PER_SEC) > 3);
  if (b) cerr << "TLE";
  return b;
}
inline void yes() { print("YES"); }
inline void no() { print("NO"); }
}  // namespace uchiha
using namespace uchiha;
const long long mod = 1e9 + 7;
void fun() {
  string s;
  rd(s);
  long long n = s.size();
  vector<bool> cool = {0, 0, 0};
  long long prv = 0;
  for (long long i = (long long)0; i < (long long)n; i++) {
    cool[s[i] - '0'] = 1;
    if (cool[0] && cool[2]) {
      if (!cool[1]) {
        prv = i;
        continue;
      }
      sort(s.begin() + prv, s.begin() + i);
      prv = i;
      cool.assign(3, 0);
      cool[s[i] - '0'] = 1;
    }
  }
  if (cool[0] ^ cool[2]) {
    sort(s.begin() + prv, s.end());
  }
  cout << s;
}
i32 main() {
  mangekyo();
  fun();
  cerr << "Time: " << ((clock() - _c) / CLOCKS_PER_SEC);
  ;
  return 0;
}
void uchiha::mangekyo() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  ;
  srand(time(NULL));
  subl();
}
