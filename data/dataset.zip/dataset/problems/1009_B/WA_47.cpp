			//////////////////////
        	//******************//
			//**  OM THUMMAR  **//
			//**  DA-IICT     **//
			//**  201901070   **//
			//**  I'D=Aom2608 **//
			//******************//
			/////////////////////

#include <bits/stdc++.h>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
using namespace std;

#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define endl "\n"
#define Max(x,y,z) max(x,max(y,z))
#define Min(x,y,z) min(x,min(y,z))
#define fr(i,s,e) for(i=s;i<e;i++)
#define rf(i,s,e) for(i=s-1;i>=e;i--)
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define mod 1000000007
typedef long long ll;
typedef unsigned int uint;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<long long, long long> pll;
typedef vector<int> vi;
typedef vector<long long> vll;
typedef vector<pair<long long,long long> > vpll;


#define PI 3.141592653589793
#define MOD 1000000007



int main()
{
	IOS;
	string s;
	cin>>s;
	ll n=s.length();
	string t="",r="";
	for(ll i=0;i<n;i++)
	{
		if(s[i]=='1')
		t+="1";
		else
		r+=s[i];
	}
	cout<<t<<r<<endl;
}



