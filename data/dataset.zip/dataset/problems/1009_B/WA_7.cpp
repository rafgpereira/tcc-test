#include <bits/stdc++.h>
using namespace std;
int main() {
  string a;
  int con = 0;
  cin >> a;
  int len = a.size();
  int i, j, k = 0;
  for (i = len - 1; i >= 0; i--) {
    if (a[i] == '0' && a[i + 1] == '2' || a[i] == '2' && a[i + 1] == '0') {
      a[i] = '*';
      a[i + 1] = '*';
      con++;
    }
  }
  std::sort(a.begin(), a.end());
  for (i = 0; i < len; i++) {
    if (a[i] != '*') {
      cout << a[i];
    }
  }
  for (j = 1; j <= con; j++) {
    cout << '0' << '2';
  }
  printf("\n");
  return 0;
}
