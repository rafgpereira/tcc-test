#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  int len = s.size();
  for (int i = 1; i < len; i++) {
    if (s[i] == '1' && s[i - 1] == '2') {
      swap(s[i], s[i - 1]);
      int j = i - 1;
      while (1) {
        if (s[j] == '1' && s[j - 1] == '2') {
          swap(s[j - 1], s[j]);
          j--;
        } else {
          break;
        }
      }
    }
  }
  for (int i = 1; i < len; i++) {
    if (s[i] == '0' && s[i - 1] == '1') {
      swap(s[i], s[i - 1]);
      int j = i - 1;
      while (1) {
        if (s[j] == '0' && s[j - 1] == '1') {
          swap(s[j - 1], s[j]);
          j--;
        } else {
          break;
        }
      }
    }
  }
  cout << s << endl;
}
