#include <bits/stdc++.h>
using namespace std;
bool comp(char a, char b) {
  if (a == '0' && b == '1') {
    return true;
  } else if (a == '1' && b == '2') {
    return true;
  } else if (a == '0' && b == '2') {
    return false;
  }
}
int main() {
  string s;
  cin >> s;
  sort(s.begin(), s.end(), comp);
  cout << s << endl;
  return 0;
}
