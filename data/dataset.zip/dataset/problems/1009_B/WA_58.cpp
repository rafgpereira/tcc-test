#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1000005;
char nextchar() {
  static char buf[100000], *p1 = buf, *p2 = buf;
  return (p1 == p2) &&
                 (p2 = (p1 = buf) + fread(buf, 1, 100000, stdin), p1 == p2)
             ? EOF
             : *p1++;
}
template <typename T>
void read(T& num) {
  static double f, x;
  static char ch;
  static bool sign;
  static long long z;
  f = 1.0 / 10;
  z = x = ch = num = sign = 0;
  while ((ch < '0') || (ch > '9')) {
    sign |= (ch == '-');
    ch = nextchar();
  }
  while ((ch >= '0') && (ch <= '9')) {
    z = z * 10 + (ch - '0');
    ch = nextchar();
  }
  if (ch == '.') {
    ch = nextchar();
    while ((ch >= '0') && (ch <= '9')) {
      x += (ch ^ 48) * f;
      f /= 10;
      ch = nextchar();
    }
  }
  num = sign ? -z - x : z + x;
}
void print(int x) {
  if (x < 0) putchar('-');
  if (x / 10) print(x / 10 > 0 ? x / 10 : -(x / 10));
  putchar((x > 0 ? x % 10 : (10 - x % 10) % 10) + '0');
}
char a[MAXN], b[MAXN];
int main() {
  scanf("%s", a + 1);
  int len = strlen(a + 1);
  int len1 = 0;
  int cnt = 0;
  for (int i = 1; i <= len; i++) {
    if ((a[i] == '0') || (a[i] == '2'))
      b[++len1] = a[i];
    else
      cnt++;
  }
  bool flag = true;
  for (int i = 1; i <= len1; i++) {
    if (flag && (b[i] == '2')) {
      for (int i = 1; i <= cnt; i++) {
        putchar('1');
      }
      flag = false;
    }
    putchar(b[i]);
  }
  return 0;
}
