#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 7;
char s[maxn];
int n, c[maxn];
int main(int argc, char const *argv[]) {
  cin >> s;
  n = strlen(s);
  string ans;
  int ok = 0;
  int now = 0;
  int l = 0;
  int a[3];
  for (int i = 0; i <= 2; i++) a[i] = 0;
  for (int i = 0; i <= n - 1; i++) {
    if (ok == 0 && s[i] == '2') {
      ok = 1;
      a[2]++;
    } else if (ok == 1) {
      if (s[i] == '2') {
        c[++now] += l;
        l = 0;
      } else if (s[i] == '1')
        a[1]++;
      else if (s[i] == '0')
        l++;
    } else
      a[s[i] - '0']++;
  }
  if (a[0] > 0 || a[1] > 0 || a[2] > 0) {
    while (a[0] > 0) {
      ans += '0';
      a[0]--;
    }
    while (a[1] > 0) {
      ans += '1';
      a[1]--;
    }
    while (a[2] > 0) {
      ans += '2';
      a[2]--;
    }
  }
  for (int i = 1; i <= now; i++) {
    while (c[now] > 0) {
      ans += '0';
      c[now]--;
    }
    ans += '2';
  }
  while (l--) {
    ans += '0';
  }
  cout << ans << endl;
  return 0;
}
