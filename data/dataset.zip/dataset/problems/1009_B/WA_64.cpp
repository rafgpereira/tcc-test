#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, i, j = 0, k = 0, i1 = 0;
  string str, str1;
  cin >> str;
  n = str.size();
  for (i = 0; i < n; i++) {
    if (str[i] == '1') {
      j++;
    }
  }
  for (i = 0; i < n; i++) {
    if (k == 0) {
      if (str[i] == '0') {
        str1 += '0';
      }
      if (str[i] == '2') {
        while (j-- > 0) {
          str1 += '1';
        }
        str1 += '2';
        k = 1;
      }
    } else {
      if (str[i] != '1') {
        str1 += str[i];
      }
    }
  }
  str1 += '\0';
  cout << str1 << endl;
  return 0;
}
