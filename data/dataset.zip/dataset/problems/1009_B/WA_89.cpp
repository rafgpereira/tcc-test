#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(0);
  string s;
  cin >> s;
  long long k = 0, n = s.length();
  while (1) {
    long long d = 0;
    for (long long i = 0; i < n - 1; i++) {
      if (s[i + 1] != s[i]) {
        long long p = i + 1;
        while (s[p] < s[p - 1] && p > 0 && s[p - 1] - s[p] == 1) {
          swap(s[p], s[p - 1]);
          p--;
          d++;
        }
      }
    }
    if (d == 0) break;
    k++;
  }
  cout << s;
}
