#include <bits/stdc++.h>
using namespace std;
const int size = 1e5 + 5;
char a[size];
inline void swap(char *a, char *b) {
  char c;
  c = *a;
  *a = *b;
  *b = c;
}
int main() {
  int t, i;
  scanf("%s", a);
  if (a[1] == NULL) {
    printf("%s\n", a);
    return 0;
  }
  for (i = 1; a[i]; i++) {
    t = i - 1;
    if (a[i] < a[t] && abs(a[i] - a[t]) != 2) {
      while (a[i] < a[t - 1] && abs(a[i] - a[t - 1]) != 2 && t - 1 > 0) t--;
      swap(a[i], a[t]);
    }
  }
  printf("%s\n", a);
  return 0;
}
