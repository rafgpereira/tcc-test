#include <bits/stdc++.h>
using namespace std;
string ss;
int main() {
  cin >> ss;
  int ans = 0;
  string hh = "";
  for (int i = 0; i < ss.length(); i++) {
    if (ss[i] == '1')
      ans++;
    else
      hh.push_back(ss[i]);
  }
  for (int i = 0; i < hh.length(); i++) {
    if (hh[i] == '2') {
      for (int j = 1; j <= ans; j++) printf("1");
      ans = 0;
    }
    printf("%c", hh[i]);
  }
  printf("\n");
  return 0;
}
