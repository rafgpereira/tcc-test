#include <bits/stdc++.h>
using namespace std;
char arr[100001];
int main() {
  int zer = 0, one = 0, t = 0;
  scanf("%s", arr);
  int len = strlen(arr);
  for (int i = 0; i < len; i++) {
    if (arr[i] == '2' && (!t)) t = i + 1;
    if (arr[i] == '1') one++;
    if ((!t) && arr[i] == '0') zer++;
  }
  for (int i = 0; i < zer; i++) printf("0");
  for (int i = 0; i < one; i++) printf("1");
  for (int i = t - 1; i < len; i++) {
    if (arr[i] != '1') printf("%c", arr[i]);
  }
  return 0;
}
