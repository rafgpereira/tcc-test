#include <bits/stdc++.h>
using namespace std;
string s;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  cin >> s;
  int n = s.length();
  bool any = true;
  while (any) {
    any = false;
    for (int i = 0; i < n - 1; ++i) {
      if (s[i] > s[i + 1]) {
        if (s[i] == '1' && s[i + 1] == '0') {
          swap(s[i], s[i + 1]);
          any = true;
        }
        if (s[i] == '2' && s[i + 1] == '1') {
          swap(s[i], s[i + 1]);
          any = true;
        }
      }
    }
  }
  any = true;
  while (any) {
    any = false;
    for (int i = n - 1; i > 0; --i) {
      if (s[i] < s[i - 1]) {
        if (s[i] == '0' && s[i - 1] == '1') {
          swap(s[i], s[i + 1]);
          any = true;
        }
        if (s[i] == '1' && s[i - 1] == '2') {
          swap(s[i], s[i + 1]);
          any = true;
        }
      }
    }
  }
  cout << s << endl;
  return 0;
}
