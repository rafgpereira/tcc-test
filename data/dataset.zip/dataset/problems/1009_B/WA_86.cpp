#include <bits/stdc++.h>
using namespace std;
int main() {
  string s;
  cin >> s;
  long long int cnt = 0;
  long long int i = 0;
  while (i < s.length()) {
    long long int start = i;
    long long int end = i;
    while (end < s.length() && (s[end] != '2')) {
      ++end;
    }
    i = end + 1;
    end--;
    sort(s.begin() + start, s.begin() + end + 1);
    reverse(s.begin() + start, s.begin() + end + 1);
  }
  i = 0;
  while (i < s.length()) {
    long long int start = i;
    long long int end = i;
    while (end < s.length() && (s[end] != '0' || cnt == 0)) {
      if (s[end] == '2') ++cnt;
      ++end;
    }
    cnt = 0;
    i = end + 1;
    end--;
    sort(s.begin() + start, s.begin() + end + 1);
  }
  cout << s;
  return 0;
}
