#include <bits/stdc++.h>
int main(void) {
  char s[100000], temp;
  int i, j;
  scanf("%s", s);
  j = strlen(s);
  while (j--) {
    int count = 0;
    for (i = 0; i < strlen(s) - 1; i++) {
      if ((s[i] == '1' && s[i + 1] == '0') ||
          (s[i] == '2' && s[i + 1] == '1')) {
        temp = s[i];
        s[i] = s[i + 1];
        s[i + 1] = temp;
        count++;
        i++;
      }
    }
    if (count == 0) break;
  }
  printf("%s", s);
  return 0;
}
