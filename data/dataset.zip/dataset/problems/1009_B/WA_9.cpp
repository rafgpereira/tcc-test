#include <bits/stdc++.h>
using namespace std;
void f() {
  cout << -1;
  exit(0);
}
int main() {
  cin.tie(0);
  cout.tie(0);
  ios_base::sync_with_stdio(false);
  string s;
  cin >> s;
  for (int i = 0; i < s.size(); i++) {
    if (s[i] == '1') {
      for (int j = i - 1; j >= 0; j--) {
        if (s[j] == '2') {
          swap(s[j], s[j + 1]);
        } else {
          break;
        }
      }
    }
  }
  for (int i = 0; i < s.size(); i++) {
    if (s[i] == '0') {
      for (int j = i - 1; j >= 0; j--) {
        if (s[j] == '1') {
          swap(s[j], s[j + 1]);
        } else {
          break;
        }
      }
    }
  }
  cout << s;
}
