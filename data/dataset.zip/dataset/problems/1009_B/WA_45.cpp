#include <bits/stdc++.h>
using namespace std;
char s[100003];
vector<char> ch[100003];
multimap<char, int> map1;
multimap<char, int>::iterator pm1, pm2;
int main() {
  cin >> s;
  int len = strlen(s);
  for (int i = 0; i < len; i++) {
    ch[i].push_back(s[i]);
    map1.insert(make_pair(s[i], i));
  }
  pm1 = map1.find('2');
  int num0 = 0, num1 = 0, num2 = 0, qian0 = 0, hou0 = 0, qian1 = 0, hou1 = 0;
  if (pm1 == map1.end()) {
    num1 = map1.count('1');
    num0 = map1.count('0');
    for (int i = 1; i <= num0; i++) {
      cout << '0';
    }
    for (int i = 1; i <= num1; i++) {
      cout << '1';
    }
    return 0;
  }
  num2 = map1.count('2');
  for (int i = 0; i < pm1->second; i++) {
    if (s[i] == '0') {
      qian0++;
    }
    if (s[i] == '1') {
      qian1++;
    }
  }
  pm1 = map1.find('2');
  for (int i = pm1->second + 1; i < len; i++) {
    if (s[i] == '1') {
      hou1++;
    }
    if (s[i] == '0') {
      hou0++;
    }
  }
  for (int i = 1; i <= qian0; i++) cout << '0';
  for (int i = 1; i <= qian1 + hou1; i++) cout << '1';
  for (int i = 1; i <= num2; i++) cout << '2';
  for (int i = 1; i <= hou0; i++) cout << '0';
  return 0;
}
