#include <bits/stdc++.h>
using namespace std;
const int mod = 1e9 + 7;
int main() {
  int n;
  cin >> n;
  int mxh = INT_MAX;
  int w, b;
  for (int i = 0; i < n; i++) {
    cin >> w >> b;
    if (min(w, b) > mxh) {
      cout << "NO" << endl;
      return 0;
    }
    mxh = max(w, b);
  }
  cout << "YES" << endl;
  return 0;
}
