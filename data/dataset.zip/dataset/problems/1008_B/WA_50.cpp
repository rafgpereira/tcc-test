#include <bits/stdc++.h>
using namespace std;
int dp[100005][2];
int main() {
  int n;
  scanf("%d", &n);
  int w[100005], h[100005];
  for (int i = 0; i < n; i++) {
    scanf("%d%d", &w[i], &h[i]);
  }
  dp[0][0] = 1;
  dp[0][1] = 1;
  for (int i = 1; i < n; i++) {
    if (w[i] <= w[i - 1] && dp[i - 1][0]) {
      dp[i][0] = 1;
    } else if (w[i] <= h[i - 1] && dp[i - 1][1]) {
      dp[i][0] = 1;
    } else if (h[i] <= w[i - 1] && dp[i - 1][0]) {
      dp[i][1] = 1;
    } else if (h[i] <= h[i - 1] && dp[i - 1][1]) {
      dp[i][1] = 1;
    }
  }
  if (dp[n - 1][0] || dp[n - 1][1]) {
    printf("YES\n");
  } else {
    printf("NO\n");
  }
  return 0;
}
