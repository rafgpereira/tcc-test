#include <bits/stdc++.h>
using namespace std;
int main() {
  int t, a, b, a1, b1, i, c = 0;
  cin >> t;
  cin >> a >> b;
  for (i = 0; i < t - 1; i++) {
    cin >> a1 >> b1;
    if (a1 <= b) c++;
    b = a1;
  }
  if (c == t - 1)
    cout << "YES"
         << "\n";
  else
    cout << "NO"
         << "\n";
  return 0;
}
