#include <bits/stdc++.h>
using namespace std;
int main() {
  int t, flag = 0, a = 0;
  cin >> t;
  int h, w;
  cin >> w >> h;
  t -= 1;
  a = h;
  while (t--) {
    cin >> w >> h;
    if (a > max(w, h))
      a = max(w, h);
    else if (a >= min(w, h))
      a = min(w, h);
    else
      flag = 1;
  }
  if (flag)
    cout << "no\n";
  else
    cout << "yes\n";
}
