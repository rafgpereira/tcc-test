#include <bits/stdc++.h>
using namespace std;
int main() {
  long long i, j, k, n, m, x = 0, y, z, t, d, aa, bb, c;
  cin >> t;
  vector<pair<long long, long long>> v;
  for (i = 0; i < t; i++) {
    cin >> aa >> bb;
    v.push_back({aa, bb});
  }
  for (i = 0; i < t - 1; i++) {
    if (v[i].second < v[i + 1].second) {
      swap(v[i + 1].second, v[i + 1].first);
    }
  }
  for (i = 0; i < t - 1; i++) {
    if (v[i].second < v[i + 1].second) {
      cout << "NO" << endl;
      return 0;
    }
  }
  cout << "YES" << endl;
}
