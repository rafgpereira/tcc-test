#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n, w, h, i, j;
  vector<long long> v, v1;
  scanf("%lld", &n);
  for (int i = 0; i < n; i++) {
    scanf("%lld%lld", &w, &h);
    v.push_back(w);
    v1.push_back(h);
  }
  for (int i = 0; i < n; i++) {
    if (v1[i] < v1[i + 1]) {
      if (v[i + 1] <= v1[i]) {
        swap(v[i + 1], v1[i + 1]);
      } else if (v[i] >= v1[i + 1]) {
        swap(v[i], v1[i]);
      }
    }
  }
  for (i = 1; i < n; i++) {
    if (v1[i] > v1[i - 1]) {
      cout << "NO" << endl;
      return 0;
    }
  }
  cout << "YES" << endl;
}
