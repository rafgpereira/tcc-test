#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  vector<pair<int, int>> v(n);
  for (int i = 0; i < n; ++i) {
    cin >> v[i].first >> v[i].second;
    if (v[i].first > v[i].second) swap(v[i].first, v[i].second);
  }
  bool a;
  if (v[0].second >= v[1].second)
    a = 1;
  else if (v[0].second >= v[1].first)
    a = 0;
  else
    return cout << "NO", 0;
  for (int i = 1; i < n - 1; ++i) {
    if (a) {
      if (v[i].second >= v[i + 1].second)
        ;
      else if (v[i].second >= v[i + 1].first)
        a = 0;
      else
        return cout << "NO", 0;
    } else {
      if (v[i].first >= v[i + 1].second)
        ;
      else if (v[i].first >= v[i + 1].first)
        a = 0;
      else
        return cout << "NO", 0;
    }
  }
  cout << "YES";
}
