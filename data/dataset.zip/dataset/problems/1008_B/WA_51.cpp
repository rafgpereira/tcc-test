#include <bits/stdc++.h>
using namespace std;
int main() {
  long n;
  cin >> n;
  pair<long long, long long>* rectangles = new pair<long long, long long>[n];
  for (long i = 0; i < n; i++)
    cin >> rectangles[i].first >> rectangles[i].second;
  long long r11, r12, r21, r22;
  bool rotated;
  if (rectangles[0].first > rectangles[0].second)
    rotated = true;
  else
    rotated = false;
  for (long i = 0; i < n; i++) {
    if (i == 0) continue;
    r11 = rectangles[i - 1].first;
    r12 = rectangles[i - 1].second;
    r21 = rectangles[i].first;
    r22 = rectangles[i].second;
    if (!rotated) {
      if (r22 > r12) {
        if (r21 <= r12) {
          rotated = true;
          continue;
        } else {
          cout << "NO" << endl;
          delete[] rectangles;
          return 0;
        }
      } else {
        if (r21 <= r12)
          rotated = r21 > r22;
        else
          rotated = false;
      }
    }
    if (rotated) {
      if (r22 > r11) {
        if (r21 <= r11) {
          rotated = true;
          continue;
        } else {
          cout << "NO" << endl;
          delete[] rectangles;
          return 0;
        }
      } else {
        if (r21 <= r11)
          rotated = r21 > r22;
        else
          rotated = false;
      }
    }
  }
  cout << "YES" << endl;
  delete[] rectangles;
  return 0;
}
