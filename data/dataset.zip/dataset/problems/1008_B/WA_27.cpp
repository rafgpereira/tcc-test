#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, i, j, k, l, cur = 0;
  cin >> n;
  vector<pair<int, int> > v;
  for (i = 0; i < n; i++) {
    cin >> j >> k;
    v.push_back(make_pair(j, k));
  }
  cur = v[0].second;
  int f = 1;
  for (i = 1; i < n; i++) {
    if (v[i].first > cur) {
      if (v[i].second > cur) {
        f = 0;
        break;
      } else
        cur = v[i].second;
    }
  }
  if (f == 0)
    cout << "NO\n";
  else
    cout << "YES\n";
  return 0;
}
