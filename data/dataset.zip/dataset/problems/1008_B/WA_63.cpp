#include <bits/stdc++.h>
using namespace std;
long long kol;
int main() {
  long long n, w, h, back;
  cin >> n >> w >> h;
  back = max(w, h);
  for (int i = 2; i <= n; i++) {
    long long w, h;
    cin >> w >> h;
    if (w <= back && h <= back) {
      kol--;
      back = max(max(w, h), min(w, h));
    }
    if (w <= back && h > back || w > h && h <= back) {
      if (w <= back)
        back = w;
      else
        back = h;
      kol--;
    }
    kol++;
  }
  if (kol == 0)
    cout << "YES";
  else
    cout << "NO";
  return 0;
}
