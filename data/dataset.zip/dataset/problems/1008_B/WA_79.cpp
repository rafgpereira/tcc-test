#include <bits/stdc++.h>
using namespace std;
void fast() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
}
vector<long long int> primes;
void sieve(long long int n) {
  vector<bool> prime(n + 1, true);
  for (long long int p = 2; p * p <= n; p++) {
    if (prime[p] == true) {
      for (long long int i = p * 2; i <= n; i += p) prime[i] = false;
    }
  }
  for (int p = 2; p <= n; p++)
    if (prime[p]) primes.push_back(p);
}
long long int modexpo(long long int a, long long int b) {
  if (b == 0) return 1;
  if (b == 1) return a;
  long long int temp = modexpo(a, b / 2);
  if (b % 2) return (temp % 1000000007 * temp % 1000000007 * a) % 1000000007;
  return (temp % 1000000007 * temp % 1000000007) % 1000000007;
}
long long int gcd(long long int x, long long int y) {
  if (y == 0) return x;
  return gcd(y, x % y);
}
long long int lcm(long long int a, long long int b) {
  return (a * b) / gcd(a, b);
}
long long int logx(long long int base, long long int num) {
  int cnt = 0;
  while (num != 1) {
    num /= base;
    ++cnt;
  }
  return cnt;
}
vector<long long int> vin(long long int n) {
  vector<long long int> a(n);
  for (long long int i = 0; i < n; i++) cin >> a[i];
  return a;
}
void out(vector<long long int> a) {
  for (int i = 0; i < (long long int)a.size(); i++) {
    cout << a[i] << ' ';
  }
  cout << '\n';
}
void in(long long int *a, long long int n) {
  for (long long int i = 0; i < n; i++) cin >> a[i];
}
void out(long long int *a, long long int n) {
  for (long long int i = 0; i < n; i++) {
    cout << a[i] << " ";
  }
}
void out1(vector<long long int> v) {
  for (long long int i = 0; i < (long long int)v.size(); i++) {
    cout << v[i] << " ";
  }
  cout << '\n';
}
int solve();
int main() {
  fast();
  clock_t start = clock();
  long long int t = 1;
  while (t--) {
    solve();
  }
}
int solve() {
  long long int n;
  cin >> n;
  vector<pair<long long int, long long int> > v;
  for (long long int i = 0; i < n; i++) {
    long long int x, y;
    cin >> x >> y;
    v.push_back(make_pair(x, y));
  }
  long long int c = 1, f = 0;
  for (long long int i = 0; i < (long long int)v.size() - 1; i++) {
    long long int h = v[i].second;
    long long int w = v[i].first;
    if (h < v[i + 1].first && h < v[i + 1].second && w < v[i + 1].first &&
        v[i + 1].second > w) {
      f = 1;
      break;
    } else
      c++;
  }
  if (!f)
    cout << "YES\n";
  else
    cout << "NO\n";
  return 0;
}
