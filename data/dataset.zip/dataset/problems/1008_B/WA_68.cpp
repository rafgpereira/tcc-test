#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  int a[n];
  int b[n];
  for (int i = 0; i < n; i++) cin >> a[i] >> b[i];
  for (int i = 0; i < n - 1; i++) {
    if (a[i] < b[i + 1]) {
      if (a[i] < a[i + 1]) {
        if (b[i] < b[i + 1]) {
          if (b[i] < a[i + 1]) {
            cout << "NO";
            return 0;
          }
        }
      }
    }
  }
  cout << "YES";
}
