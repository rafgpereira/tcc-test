#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  long long int w[n];
  long long int h[n];
  for (int i = 0; i < n; i++) {
    cin >> w[i];
    cin >> h[i];
  }
  int broj = max(w[0], h[0]);
  int brojac = min(w[0], h[0]);
  for (int i = 1; i < n; i++) {
    if ((min(w[i], h[i]) <= broj or max(w[i], h[i]) <= broj) or
        (min(w[i], h[i]) < brojac and max(w[i], h[i]) < brojac)) {
      broj = max(w[i], h[i]);
      brojac = min(w[0], h[0]);
    } else {
      cout << "NO";
      return 0;
    }
  }
  cout << "YES";
}
