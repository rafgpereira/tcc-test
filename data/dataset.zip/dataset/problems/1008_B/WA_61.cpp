#include <bits/stdc++.h>
using namespace std;
int main(void) {
  int a[100000], b[100000];
  int n, mid;
  scanf("%d", &n);
  for (int i = 1; i <= n; ++i) {
    scanf("%d %d", &a[i], &b[i]);
  }
  if (a[0] > b[0]) {
    mid = a[0];
    a[0] = b[0];
    b[0] = mid;
  }
  int i, max = 0, min = 0, p = 0;
  for (i = 1; i <= n; i++) {
    if (a[i] >= b[i]) {
      max = a[i];
      min = b[i];
    }
    if (max <= b[i - 1]) {
      b[i] = max;
      a[i] = min;
    } else if (max >= b[i - 1] && min <= b[i - 1]) {
      b[i] = min;
      a[i] = max;
    } else if (min > b[i - 1]) {
      cout << "NO";
      p = 1;
      break;
    }
    max = 0, min = 0;
  }
  if (p == 0) cout << "YES";
}
