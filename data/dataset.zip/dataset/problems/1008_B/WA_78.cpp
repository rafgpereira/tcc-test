#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  long long int max = 0;
  long long int w, h;
  cin >> w >> h;
  if (w > h) swap(w, h);
  max = h;
  n--;
  while (n--) {
    cin >> w >> h;
    if (h > max && w > max) {
      cout << "NO";
      return 0;
    }
    if (w <= max && w > h) swap(w, h);
    max = h;
  }
  cout << "YES";
  return 0;
}
