#include <bits/stdc++.h>
using namespace std;
const int maxn = 3e5 + 30;
long long inf = 1e18;
int n, cnt[maxn], m;
int maxi[maxn], mini[maxn];
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cin >> n;
  for (int i = 0; i < n; i++) {
    int x, y;
    cin >> x >> y;
    mini[i] = min(x, y);
    maxi[i] = max(x, y);
  }
  for (int i = 0; i < n - 1; i++) {
    if (maxi[i] < mini[i + 1]) {
      cout << "NO";
      return 0;
    }
  }
  cout << "YES";
}
