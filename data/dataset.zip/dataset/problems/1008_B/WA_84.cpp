#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  long long n, w, h;
  vector<pair<long long, long long>> vec;
  cin >> n;
  for (long long i = 0; i < n; i++) {
    cin >> w >> h;
    vec.push_back(make_pair(w, h));
  }
  for (long long i = 0; i < n - 1; i++) {
    if (vec[i].first < vec[i + 1].first && vec[i].first < vec[i + 1].second &&
        vec[i].second < vec[i + 1].first && vec[i].second < vec[i + 1].second) {
      cout << "NO";
      return 0;
    }
  }
  cout << "YES";
  return 0;
}
