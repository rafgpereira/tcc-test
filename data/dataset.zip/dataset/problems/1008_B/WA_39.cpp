#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n;
  cin >> n;
  long long int w[n], h[n];
  long long int i;
  int x;
  for (i = 0; i < n; i++) {
    cin >> w[i] >> h[i];
  }
  int a, b, c, d;
  for (i = 0; i < n; i++) {
    if (i < n) {
      a = w[i];
      c = h[i];
    }
    if (i < n - 1) {
      b = w[i + 1];
      d = h[i + 1];
    }
    if (b > a && b > c && d > a && d > c) {
      x = 0;
      break;
    } else {
      x = 1;
      continue;
    }
  }
  if (x == 0) {
    cout << "NO" << endl;
  } else if (x == 1) {
    cout << "YES" << endl;
  }
  return 0;
}
