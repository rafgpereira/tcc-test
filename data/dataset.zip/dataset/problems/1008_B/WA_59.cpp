#include <bits/stdc++.h>
using namespace std;
bool check(char c) {
  if (c == 'a' || c == 'e' || c == 'o' || c == 'i' || c == 'u') return true;
  return false;
}
int main() {
  int max;
  int n;
  cin >> n;
  int t, t1;
  cin >> t;
  cin >> t1;
  if (t > t1)
    max = t;
  else
    max = t1;
  if (n == 1) {
    cout << "YES";
    return 0;
  }
  for (int i = 1; i < n; ++i) {
    cin >> t;
    cin >> t1;
    int xet = 0;
    if (t > t1) xet = t;
    if (xet > max) {
      if (t1 > max) {
        cout << "NO";
        return 0;
      }
      max = t1;
    } else {
      if (t > max) {
        cout << "NO";
        return 0;
      }
      max = t;
    }
  }
  cout << "YES";
  return 0;
}
