#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  int w[n], h[n], t;
  for (int i = 0; i < n; i++) {
    cin >> w[i] >> h[i];
  }
  for (int i = 0; i < n - 1; i++) {
    if (h[i] < h[i + 1] && h[i] < w[i + 1]) {
      cout << "NO";
      return 0;
    } else if (h[i] < h[i + 1]) {
      t = h[i + 1];
      h[i + 1] = w[i + 1];
      w[i + 1] = t;
    } else if (h[i] >= h[i + 1] && h[i] >= w[i + 1]) {
      h[i + 1] = max(h[i + 1], w[i + 1]);
    }
  }
  cout << "YES";
  return 0;
}
