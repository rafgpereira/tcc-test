#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n, a[200005], b[200005], i, flag = 0, temp;
  cin >> n;
  for (i = 0; i < n; i++) {
    cin >> b[i] >> a[i];
    if (i > 0) {
      if (a[i] > a[i - 1] && a[i] <= b[i - 1] &&
          (i == 1 || a[i - 2] >= b[i - 1])) {
        temp = a[i - 1];
        a[i - 1] = b[i - 1];
        b[i - 1] = temp;
      } else if (a[i] > a[i - 1] && b[i] <= a[i - 1]) {
        temp = a[i];
        a[i] = b[i];
        b[i] = temp;
      } else if (a[i] > a[i - 1])
        flag = 1;
    }
  }
  if (flag == 1)
    cout << "NO";
  else
    cout << "YES";
  return 0;
}
