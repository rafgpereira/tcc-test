#include <bits/stdc++.h>
using namespace std;
int main() {
  int i, j, n, a, b, asc = 0, des = 1000000001, flag1 = 1, flag2 = 1;
  cin >> n;
  while (n--) {
    cin >> a >> b;
    if (flag1 == 0 && flag2 == 0) continue;
    if (min(a, b) >= asc) {
      asc = min(a, b);
    } else
      flag1 = 0;
    if (max(a, b) <= des) {
      des = max(a, b);
    } else
      flag2 = 0;
  }
  if (flag1 == 0 && flag2 == 0)
    cout << "YES\n";
  else
    cout << "NO\n";
  return 0;
}
