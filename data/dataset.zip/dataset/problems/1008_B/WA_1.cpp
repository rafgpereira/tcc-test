#include <bits/stdc++.h>
int main() {
  unsigned int n, i, j, flag = 0;
  unsigned long int r[100000][2];
  scanf("%u ", &n);
  for (i = 0; i < n; i++) {
    for (j = 0; j < 2; j++) {
      scanf("%u", &r[i][j]);
    }
  }
  for (i = 0; i < n; i++) {
    if (r[i][1] < r[i + 1][1]) {
      if (r[i][0] < r[i + 1][1]) {
        int temp = r[i][0];
        r[i][0] = r[i][1];
        r[i][1] = temp;
      } else {
        flag = 1;
        break;
      }
    }
  }
  if (flag)
    printf("YES");
  else
    printf("NO");
  return 0;
}
