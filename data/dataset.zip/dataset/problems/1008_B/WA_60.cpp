#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  int a[n], h[n];
  vector<int> v;
  v.push_back(0);
  for (int i = 0; i < n; i++) {
    cin >> a[i] >> h[i];
  }
  for (int i = 0; i < n; i++) {
    if (a[i] >= a[i + 1] || a[i] >= h[i + 1]) {
      v.push_back(a[i]);
    } else if (h[i] >= a[i + 1] || h[i] >= h[i + 1]) {
      v.push_back(h[i]);
    }
  }
  int k = 0;
  v.push_back(min(a[n - 1], h[n - 1]));
  for (int i = 0; i < v.size(); i++) {
    cout << v[i] << " ";
    if (v[i] <= v[i - 1]) {
      k++;
    }
  }
  if (k >= n) {
    cout << "YES";
  } else {
    cout << "NO";
  }
  return 0;
}
