#include <bits/stdc++.h>
using namespace std;
int main() {
  long long c = 0, i = 0, j = 0, n = 0;
  cin >> n;
  int a[n], b[n];
  for (i = 0; i < n; i++) {
    cin >> a[i] >> b[i];
  }
  for (i = 1; i < n; i++) {
    if (a[i] <= a[i - 1] || a[i] <= b[i - 1]) {
      b[i] = a[i];
      continue;
    }
    if (b[i] <= a[i - 1] || b[i] <= b[i - 1]) {
      a[i] = b[i];
      continue;
    }
    cout << "NO";
    return 0;
  }
  cout << "YES";
}
