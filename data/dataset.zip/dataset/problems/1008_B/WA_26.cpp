#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  int a, b, c, d;
  int flag = 0;
  cin >> a >> b;
  int t = max(a, b);
  b = t;
  for (int i = 1; i < n; i++) {
    cin >> c >> d;
    t = min(c, d);
    if (t > b) {
      flag = 1;
    }
    b = t;
  }
  if (flag)
    cout << "NO";
  else
    cout << "YES";
}
