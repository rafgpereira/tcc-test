#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  long long int w[n];
  long long int h[n];
  for (int i = 0; i < n; i++) {
    cin >> w[i];
    cin >> h[i];
  }
  int broj = max(w[0], h[0]);
  for (int i = 1; i < n; i++) {
    if (i != 0 and min(w[i], h[i]) > broj) {
      cout << "NO";
      return 0;
    } else {
      broj = min(w[i], h[i]);
    }
  }
  cout << "YES";
}
