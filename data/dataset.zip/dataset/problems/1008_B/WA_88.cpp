#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, i, cur, a, b, flag = 0;
  cin >> n >> a >> b;
  cur = max(a, b);
  for (i = 1; i < n; i++) {
    cin >> a >> b;
    if (min(a, b) > cur) {
      flag = 1;
      cout << "NO";
      break;
    }
    cur = max(a, b);
  }
  if (flag == 0) cout << "YES";
  return 0;
}
