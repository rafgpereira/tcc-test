#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n;
  cin >> n;
  long long a, b;
  cin >> a >> b;
  long long prev = max(a, b);
  for (int i = 1; i < n; i++) {
    cin >> a >> b;
    if (prev < a && prev < b) {
      cout << "NO\n";
      return 0;
    }
    if (a > b) {
      if (prev > a) {
        prev = a;
      } else {
        prev = b;
      }
    } else {
      if (prev > b) {
        prev = b;
      } else {
        prev = a;
      }
    }
  }
  cout << "YES\n";
}
