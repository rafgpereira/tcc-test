#include <bits/stdc++.h>
using namespace std;
struct rect {
  int w;
  int h;
};
int main() {
  int n;
  cin >> n;
  rect N[n];
  int w, h;
  for (register int i = 0; i < n; ++i) {
    cin >> w >> h;
    N[i].w = w;
    N[i].h = h;
  }
  int mx_idx = n - 1;
  bool res = true;
  for (register int i = 0; i < mx_idx; ++i) {
    if ((N[i].w < N[i + 1].w && N[i].w < N[i + 1].h) &&
        (N[i].h < N[i + 1].h && N[i].h < N[i + 1].w)) {
      res = false;
      break;
    }
  }
  res ? cout << "YES" : cout << "NO";
  return (0);
}
