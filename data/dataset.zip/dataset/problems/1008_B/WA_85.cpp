// be năm ❤xodă❤
// written by Ali Heydari

#include <bits/stdc++.h>

using namespace std;

#ifdef ONLINE_JUDGE
#define Z "%I64d"
#define N "%I64u"
#else
#define Z "%lld"
#define N "%llu"
#endif
#define R "%.19LG"
#define endl "\r\n"
typedef int64_t integer;
typedef uint64_t naturaln;
typedef long double realn;

const int maxN = 100'000;
array <array <integer, maxN>, 2> h;
array <integer, maxN> dp;

int main() {
	//freopen("input.txt", "r", stdin);
	//freopen("output.txt", "w", stdout);
	//ios::sync_with_stdio(false);
	//cin.tie(nullptr);
	integer n;
	scanf(Z, &n);
	scanf(Z, &h[0][0]);
	scanf(Z, &h[1][0]);
	dp[0] = 0;
	if (h[1][0] > h[0][0]) {
		dp[0] = 1;
	}
	for (integer i = 1; i < n; i ++) {
		scanf(Z, &h[0][i]);
		scanf(Z, &h[1][i]);
		if (h[0][i] > h[dp[i - 1]][i - 1] and h[1][i] > h[dp[i - 1]][i - 1]) {
			printf("NO");
			return 0;
		}
		if (h[1][i] > h[0][i] and h[1][i] <= h[dp[i - 1]][i - 1]) {
			dp[i] = 1;
		}
		else {
			dp[i] = 0;
		}
	}
	printf("YES");
	return 0;
}