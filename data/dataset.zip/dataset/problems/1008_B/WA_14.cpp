#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, left[100001], right[100001], ats = 1;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> left[i] >> right[i];
  }
  for (int i = 1; i < n; i++) {
    if ((right[i - 1] < right[i]) && (left[i - 1] < right[i]) &&
        (right[i - 1] < left[i]) && (left[i - 1] < left[i])) {
      ats = -1;
      break;
    } else {
      if ((right[i - 1] >= left[i]) || (left[i - 1] >= left[i])) {
        right[i] = left[i];
      }
      if ((left[i - 1] <= right[i]) && (left[i - 1] <= left[i])) {
        right[i - 1] = left[i - 1];
      }
    }
  }
  if (ats != 1) {
    cout << "NO";
  } else {
    cout << "YES";
  }
  return 0;
}
