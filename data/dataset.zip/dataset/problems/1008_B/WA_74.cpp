#include <bits/stdc++.h>
using namespace std;
int main() {
  int a[200001];
  int b[200001];
  int c = 0, n, q, p;
  cin >> n;
  for (int i = 1; i <= 2 * n; i++) {
    if (i % 2 == 1)
      cin >> a[i];
    else
      cin >> b[i - 1];
  }
  q = max(a[1], b[1]);
  for (int i = 1; i <= 2 * n; i += 2) {
    p = max(a[i + 2], b[i + 2]);
    if (q >= p)
      c++;
    else {
      p = min(a[i + 2], b[i + 2]);
      if (q >= p) {
        c++;
        q = min(a[i + 2], b[i + 2]);
      } else {
        cout << "NO";
        break;
      }
    }
  }
  if (c == n) cout << "YES";
  return 0;
}
