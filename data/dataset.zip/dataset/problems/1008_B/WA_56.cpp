#include <bits/stdc++.h>
using namespace std;
int32_t main() {
  long long n;
  cin >> n;
  long long last = INT_MAX, flag = 1;
  for (long long i = 0; i < n; i++) {
    long long x, y;
    cin >> x >> y;
    long long Max = max(x, y), Min = min(x, y);
    if (Min > last) flag = 0;
    last = (Max < last) ? Max : Min;
  }
  if (flag)
    cout << "YES";
  else
    cout << "NO";
  return 0;
}
