#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int a[100010], b[100010], i, j, k, k1, n, s[100010], c, d;
  while (~scanf("%lld", &n)) {
    memset(s, 0, sizeof(s));
    for (i = 0; i < n; i++) scanf("%lld%lld", &a[i], &b[i]);
    for (i = 0; i < n; i++) {
      if (i == 0)
        s[i] = max(a[i], b[i]);
      else {
        k = max(a[i], b[i]);
        k1 = min(a[i], b[i]);
        if (k <= s[i - 1])
          s[i] = k;
        else if (k1 <= s[i - 1])
          s[i] = k1;
        else
          break;
      }
    }
    if (i < n)
      printf("NO\n");
    else {
      c = s[1] - s[0];
      for (i = 2; i < n; i++) {
        d = s[i] - s[i - 1];
        if (d != c) break;
      }
      if (i < n || n == 1)
        printf("YES\n");
      else
        printf("NO\n");
    }
  }
  return 0;
}
