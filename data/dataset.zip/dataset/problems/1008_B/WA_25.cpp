#include <bits/stdc++.h>
using namespace std;
const int N = 2e5 + 2;
vector<pair<int, int>> v;
int n;
bool solve(int n) {
  for (int i = 1; i < (int)(n); ++i) {
    if (n >= v[i].first) {
      n = v[i].first;
    } else if (n >= v[i].second) {
      n = v[i].second;
    } else
      return false;
  }
  return true;
}
int main() {
  int n;
  scanf("%d", &n);
  for (int i = 0; i < (int)(n); ++i) {
    int a, b;
    scanf("%d%d", &a, &b);
    v.push_back({min(a, b), max(b, a)});
  }
  if (solve(v[0].first) || solve(v[0].second)) {
    puts("YES");
  } else {
    puts("NO");
  }
  return 0;
}
