#include <bits/stdc++.h>
int main() {
  int i, j, n, h, n_h, found = 0;
  scanf("%i", &n);
  struct object {
    int a_l[2];
  };
  struct object obj[n];
  for (i = 0; i < n; ++i) {
    for (j = 0; j < 2; ++j) {
      scanf("%i", &obj[i].a_l[j]);
    }
  }
  if (n == 1) {
    printf("YES");
    return 0;
  }
  if (obj[0].a_l[0] >= obj[0].a_l[1]) {
    h = obj[0].a_l[0];
  } else {
    h = obj[0].a_l[1];
  }
  for (i = 0; i < n - 1; ++i) {
    if (obj[i + 1].a_l[0] <= obj[i + 1].a_l[1]) {
      n_h = obj[i + 1].a_l[0];
    } else {
      n_h = obj[i + 1].a_l[1];
    }
    if (h >= n_h) {
      if ((obj[i + 1].a_l[0] - h) >= (obj[i + 1].a_l[1] - h)) {
        h = obj[i + 1].a_l[0];
      } else {
        h = obj[i + 1].a_l[1];
      }
      found = 1;
    } else {
      found = 0;
      break;
    }
  }
  if (found) {
    printf("YES");
  } else {
    printf("NO");
  }
  return 0;
}
