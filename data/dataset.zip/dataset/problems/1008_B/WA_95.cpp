#include <bits/stdc++.h>
using namespace std;
vector<pair<long long, long long> > V;
int main() {
  ios_base::sync_with_stdio(false);
  int n;
  long long a, b;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> a >> b;
    if (b > a)
      V.push_back(pair<long long, long long>(a, b));
    else
      V.push_back(pair<long long, long long>(b, a));
  }
  bool ans = true;
  long long h1, h2, w1, w2;
  for (int i = 1; i < V.size(); i++) {
    h1 = V[i - 1].second;
    h2 = V[i].second;
    w2 = V[i].first;
    w1 = V[i - 1].first;
    if (h2 <= h1)
      continue;
    else if (w2 <= h1) {
      long long tmp = V[i].first;
      V[i].first = V[i - 1].first;
      V[i - 1].first = tmp;
    } else {
      ans = false;
      break;
    }
  }
  if (ans)
    cout << "YES\n";
  else
    cout << "NO\n";
}
