#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n;
  cin >> n;
  vector<long long> a, b, h;
  for (long long i = 0; i < n; i++) {
    long long x, y;
    cin >> x >> y;
    a.push_back(x);
    b.push_back(y);
  }
  if (n == 1) {
    cout << "YES" << endl;
    return 0;
  }
  long long mx = max(a[0], b[0]);
  h.push_back(mx);
  for (long long i = 1; i < n; i++) {
    int mn = min(a[i], b[i]);
    mx = max(a[i], b[i]);
    if (mx > h[i - 1]) {
      if (mn > h[i - 1]) {
        cout << "NO" << endl;
        return 0;
      }
      h.push_back(mn);
    }
  }
  cout << "YES" << endl;
  return 0;
}
