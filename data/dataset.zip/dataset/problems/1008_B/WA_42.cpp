#include <bits/stdc++.h>
using namespace std;
const long double PI = atan(1.0) * 4.0;
const long long int MOD = 1e9 + 7;
const long long int INF = 1e18;
const long double EPS = 0.0000001;
int main() {
  ios_base::sync_with_stdio(false), cin.tie(NULL);
  int n, a, b, x;
  cin >> n;
  vector<pair<int, int> > v;
  for (int i = 0; i < n; i++) {
    cin >> a >> b;
    v.push_back(make_pair(a, b));
  }
  if (v[0].first < v[0].second) swap(v[0].first, v[0].second);
  int g = 0;
  for (int i = 1; i < n; i++) {
    x = max(v[i].first, v[i].second);
    if (x <= v[i - 1].first) {
      if (x == v[i].second) {
        swap(v[i].first, v[i].second);
      }
    } else {
      x = min(v[i].first, v[i].second);
      if (x > v[i - 1].first) {
        cout << "NO"
             << "\n";
        g = 1;
      }
    }
  }
  if (g == 0)
    cout << "YES"
         << "\n";
  return 0;
}
