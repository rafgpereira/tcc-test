#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n;
  cin >> n;
  long long a[n], b[n];
  for (int i = 0; i < n; i++) {
    cin >> a[i] >> b[i];
  }
  int s = 0;
  int f = 1;
  if (b[0] < b[1]) {
    if (a[0] > b[1]) {
      b[0] = a[0];
      s++;
    }
  }
  for (int i = 0; i < n - 1; i++) {
    if (b[i] >= b[i + 1]) {
      continue;
    } else if (a[i + 1] <= b[i]) {
      b[i + 1] = a[i + 1];
      s++;
    } else if (b[i + 1] > b[i] && a[i + 1] > b[i]) {
      f = 0;
      break;
    }
  }
  if (f == 1) {
    cout << "Yes";
  } else {
    cout << "No";
  }
}
