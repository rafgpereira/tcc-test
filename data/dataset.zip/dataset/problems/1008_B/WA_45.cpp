#include <bits/stdc++.h>
using namespace std;
long long n, arr[100007], arr1[100007], max1, max2;
int main() {
  cin >> n;
  for (int i = 0; i < n; i++) cin >> arr[i] >> arr1[i];
  for (int i = 0; i < n - 1; i++) {
    max1 = (arr[i] > arr1[i] ? arr[i] : arr1[i]);
    max2 = (arr[i + 1] > arr1[i + 1] ? arr[i + 1] : arr1[i + 1]);
    if (max1 >= max2) {
      continue;
    } else {
      cout << "NO";
      return 0;
    }
  }
  cout << "YES";
}
