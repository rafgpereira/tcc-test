#include <bits/stdc++.h>
using namespace std;
template <typename T>
inline string toString(T a) {
  ostringstream os("");
  os << a;
  return os.str();
}
template <typename T>
inline long long toLong(T a) {
  long long res;
  istringstream os(a);
  os >> res;
  return res;
}
template <typename T>
inline T S(T a) {
  return a * a;
}
template <typename T>
inline T gcd(T a, T b) {
  if (b == 0)
    return a;
  else
    return gcd(b, a % b);
}
template <typename T>
inline unsigned long long bigmod(T a, T b, T m) {
  if (b == 0)
    return 1;
  else if (b % 2 == 0)
    return S(bigmod(a, b / 2, m)) % m;
  else
    return (a % m * bigmod(a, b - 1, m)) % m;
}
template <typename T>
inline vector<string> parse(T str) {
  vector<string> res;
  string s;
  istringstream os(str);
  while (os >> s) res.push_back(s);
  return res;
}
template <typename T>
inline unsigned long long dist(T A, T B) {
  unsigned long long res =
      (A.x - B.x) * (A.x - B.x) + (A.y - B.y) * (A.y - B.y);
  return res;
}
template <typename T>
inline double cosAngle(T a, T b, T c) {
  double res = a * a + b * b - c * c;
  res = res / (2 * a * b);
  res = acos(res);
  return res;
}
template <typename T>
inline T power(T base, int po) {
  T res = 1;
  if (base == 0) return 0;
  for (int i = (0); i < (po); i++) res *= base;
  return res;
}
template <typename T>
inline bool isOn(T mask, T pos) {
  return mask & (1 << pos);
}
template <typename T>
inline int Off(T mask, T pos) {
  return mask ^ (1 << pos);
}
template <typename T>
inline int On(T mask, T pos) {
  return mask | (1 << pos);
}
int num, arr1[100007], arr2[100007], arr[100007], flg = 0, a = 0, b = 0;
int main() {
  cin >> num;
  memset(arr, 0, num);
  for (int i = (0); i < (num); i++) {
    cin >> arr1[i] >> arr2[i];
    if (i > 0 && arr1[i] > arr1[i - 1]) {
      a = 0, b = 0;
      if (arr[i - 1] != 1) {
        if (arr2[i - 1] >= arr1[i]) {
          if ((i >= 2 && (arr1[i - 2] >= arr2[i - 1])) || (i >= 1)) {
            swap(arr1[i - 1], arr2[i - 1]);
            arr[i - 1] = 1;
            a = 1;
          }
        }
      }
      if (arr1[i - 1] >= arr2[i] && a != 1) {
        swap(arr1[i], arr2[i]);
        arr[i] = 1;
        b = 1;
      }
      if (a == 0 && b == 0) {
        flg = 1;
      }
    }
  }
  if (flg == 1) {
    cout << "NO\n";
  } else {
    cout << "YES\n";
  }
}
