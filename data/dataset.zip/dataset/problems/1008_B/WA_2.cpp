#include <bits/stdc++.h>
using namespace std;
int n, a[100001], b[100001], i, j;
int main() {
  cin >> n;
  for (i = 1; i <= n; i++) {
    cin >> a[i] >> b[i];
  }
  if (a[1] < b[1]) j = a[1], a[1] = b[1], b[1] = j;
  for (i = 2; i <= n; i++) {
    if (a[i] > a[i - 1])
      if (b[i] > a[i - 1]) {
        cout << "NO";
        return 0;
      }
    if (b[i] <= a[i - 1]) j = b[i], b[i] = a[i], a[i] = j;
  }
  cout << "YES";
  return 0;
}
