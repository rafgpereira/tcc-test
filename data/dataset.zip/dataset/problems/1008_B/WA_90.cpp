#include <bits/stdc++.h>
using namespace std;
struct a {
  long long w;
  long long h;
};
a j[100009];
int main() {
  int n;
  int i;
  cin >> n;
  for (int i = 0; i < n; i++) cin >> j[i].w >> j[i].h;
  if (j[0].w > j[0].h) swap(j[0].w, j[0].h);
  for (i = 1; i < n; i++) {
    if (j[i].h > j[i - 1].h) swap(j[i].w, j[i].h);
    if (j[i].h > j[i - 1].h) break;
  }
  if (i < n)
    cout << "NO";
  else
    cout << "YES";
  return 0;
}
