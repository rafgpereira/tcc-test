#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, h, w, ph, pw;
  cin >> n;
  cin >> pw >> ph;
  bool f = true;
  for (int i = 0; i < n - 1; ++i) {
    cin >> w >> h;
    if (ph >= h || ph >= w) {
      ph = h;
      pw = w;
      continue;
    }
    if (pw >= h || pw >= w) {
      ph = w;
      pw = h;
      continue;
    } else
      f = false;
  }
  if (f)
    cout << "yes";
  else
    cout << "no";
  return 0;
}
