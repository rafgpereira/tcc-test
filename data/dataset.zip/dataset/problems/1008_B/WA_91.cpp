#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, i, p = 0;
  long x, y, a, b;
  cin >> n;
  vector<long> s[n];
  for (i = 0; i < n; i++) {
    cin >> x >> y;
    s[i].push_back(x);
    s[i].push_back(y);
  }
  for (i = 0; i < n - 1; i++) {
    a = max(s[i].front(), s[i].back());
    b = min(s[i + 1].front(), s[i + 1].back());
    if (a >= b) p++;
  }
  if (p == n - 1)
    cout << "YES";
  else
    cout << "NO";
}
