#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n, i, f1 = 0;
  cin >> n;
  long long int a[n], b[n];
  for (i = 0; i < n; i++) cin >> a[i] >> b[i];
  for (i = 1; i < n; i++) {
    if (b[i] > b[i - 1]) {
      b[i] = a[i];
      if (b[i] > b[i - 1]) f1++;
    }
  }
  if (f1 > 0)
    cout << "NO";
  else
    cout << "YES";
  return 0;
}
