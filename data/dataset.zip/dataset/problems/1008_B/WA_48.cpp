#include                <bits/stdc++.h>
#include                <float.h>
#include                <string>
#include                <sstream>
#include                <stdio.h>
#include                <ext/pb_ds/tree_policy.hpp>
#include                <ext/pb_ds/assoc_container.hpp>
#define fast()          ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll              long long
#define pii             pair<ll,ll>
#define pb              push_back
#define all(a)          a.begin(),a.end()
#define pf              printf
#define Pi              2*acos(0.0)
#define bitcnt(x)       __builtin_popcountll(x)
#define pb              push_back
#define F               first
#define mpp             make_pair
#define S               second
#define ms(a,b)         memset(a, b, sizeof(a))
#define inf             1e18L
#define MAX             100005
#define MOD             1000000007
#define MAXL            log2(100000)
#define valid(nx,ny,row,col) nx>=0 && nx<=row-1 && ny>=0 && ny<=col-1
///==Scanning====///
#define S(a) scanf("%d",&a)
#define P(a) printf("%d",a)
#define SL(a) scanf("%lld",&a)
#define S2(a,b) scanf("%d%d",&a,&b)
#define S3(a,b,c) scanf("%d%d%d",&a,&b,&c)
#define SL2(a,b) scanf("%lld%lld",&a,&b)
#define SL3(a,b,c) scanf("%lld%lld%lld",&a,&b,&c)

///==Arr,Vec Functions==///
#define all(v) v.begin(),v.end()
#define CLR(a) memset(a,0,sizeof(a))
#define SET(a) memset(a,-1,sizeof(a))
#define CPY(a,b) memcpy(a,b,sizeof(a))
#define Max(a) (*maxx_element(all(a)))
#define Min(a) (*min_element(all(a)))
#define fv(i,v)  for(int i=0;i<(int)v.size();i++)
#define fr(i,a,n) for(int i=a;i<=n;i++)
#define rf(i,n,a) for(int i=n;i>=a;i--)
ll gcd(ll a,ll b) {return b==0?a:gcd(b,a%b);}
ll bmod(ll a,ll b,ll m){if(b==0)return 1;ll x=bmod(a,b/2,m);x=(x*x)%m;if(b%2==1)x=(x*a)%m;return x;}
ll powr(ll n,ll m){ll ans=1;for(ll i=1;i<=m;i++) ans*=n;return ans;}
bool prime(ll n){for(ll i=2;i*i<=n;i++){if(n%i==0) return false;}return true;}
int Setbit(ll N,ll pos){return N=N | (1<<pos);}
int resetbit(ll N,ll pos){return N= N & ~(1<<pos);}
bool checkbit(ll N,ll pos){return (bool)(N & (1<<pos));}
void countDivisor(ll num) {
    for (ll i=1;i*i<=num;i++){
        if(num%i==0){
        ///dvsr[num].pb(i);
        ///if(i!=num/i) dvsr[num].pb(num/i);
        }
    }
}
///void extendedEuclid(int A, int B) {if(B == 0) {d = A;x = 1;y = 0;}else {extendedEuclid(B, A%B);int temp = x;x = y;y = temp - (A/B)*y;}}
///int modInverse(int A, int M){extendedEuclid(A,M);return (x%M+M)%M;}
ll fx[4]={0,+0,-1,+1};
ll fy[4]={1,-1,+0,+0};
using namespace std;
using namespace __gnu_pbds;
///template <typename T>  using oset =tree<T, null_type, less<T>,rb_tree_tag, tree_order_statistics_node_update>;
ll flag=0;
int main()
{
    //fast();
    ll n;SL(n);
    ll w,h;
    ll prev=inf;
    for(ll i=0;i<n;i++){
        SL2(w,h);
        if(h>prev&&w>prev){
            flag=1;break;
        }
        else{
            prev=max(w,h);
    }
    }
    if(flag==0) printf("YES");
    else printf("NO");

}
