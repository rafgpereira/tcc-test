#include <bits/stdc++.h>
using namespace std;
int main() {
  long long test;
  cin >> test;
  vector<pair<long long, long long> > number;
  for (int i = 0; i < test; i++) {
    int a, b;
    cin >> a >> b;
    number.push_back(make_pair(a, b));
  }
  bool check = true;
  for (long long i = 0; i < test - 1; i++) {
    if (number[i].second < number[i].first) {
      swap(number[i].first, number[i].second);
    }
    if (number[i + 1].second > number[i].second) {
      if (number[i + 1].first > number[i].second) {
        cout << "NO" << endl;
        check = false;
        return 0;
      }
    }
  }
  if (check == true) {
    cout << "YES" << endl;
  }
  return 0;
}
