#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  long long n;
  cin >> n;
  vector<pair<long long, long long> > squares(n);
  for (long long i = 0; i < n; ++i) {
    cin >> squares[i].first;
    cin >> squares[i].second;
  }
  if (n == 1)
    cout << "YES";
  else {
    bool ans = true;
    for (long long i = 1; i < n; i++) {
      long long maximum = max(squares[i - 1].first, squares[i - 1].second);
      long long minimum = min(squares[i].first, squares[i].second);
      long long third =
          minimum == squares[i].first ? squares[i].second : squares[i].first;
      if (minimum > maximum)
        ans = false;
      else if (i != n - 1 && minimum <= maximum &&
               minimum < min(squares[i + 1].first, squares[i + 1].second) &&
               third < min(squares[i + 1].first, squares[i + 1].second)) {
        ans = false;
      } else if (i != n - 1 && minimum <= maximum &&
                 minimum < min(squares[i + 1].first, squares[i + 1].second) &&
                 third >= min(squares[i + 1].first, squares[i + 1].second) &&
                 third > maximum) {
        ans = false;
      }
    }
    if (ans)
      cout << "YES";
    else
      cout << "NO";
  }
}
