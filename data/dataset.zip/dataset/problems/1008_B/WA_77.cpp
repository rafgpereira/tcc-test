#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 100;
const long long mod = 998244353;
const int inf = 4e4 + 5;
const double pi = acos(-1.0);
const double eps = 1e-6;
int h[maxn], w[maxn];
int main() {
  int n;
  scanf("%d", &n);
  for (int i = 1; i <= n; i++) scanf("%d%d", w + i, h + i);
  bool ans = true;
  for (int i = 2; i <= n; i++) {
    if (h[i] > h[i - 1]) {
      swap(h[i], w[i]);
      if (h[i] > h[i - 1]) {
        ans = false;
        break;
      }
    }
  }
  if (ans)
    printf("YES\n");
  else
    printf("NO\n");
  return 0;
}
