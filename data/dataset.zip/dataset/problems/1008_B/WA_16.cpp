#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(nullptr);
  cout.tie(nullptr);
  int64_t n, cur = 0;
  cin >> n;
  vector<pair<int64_t, int64_t>> a(n);
  for (int i = 0; i < n; ++i) {
    cin >> a[i].first >> a[i].second;
  }
  for (int i = 1; i < n; ++i) {
    if (a[i].first > a[i - 1].first && a[i].first > a[i - 1].second &&
        a[i].second > a[i - 1].first && a[i].second > a[i - 1].second) {
      cout << "NO";
      return 0;
    }
  }
  cout << "YES";
  return 0;
}
