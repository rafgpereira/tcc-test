#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n, w[100010], h[100010];
  cin >> n;
  for (int i = 0; i < n; ++i) cin >> w[i] >> h[i];
  h[0] = max(h[0], w[0]);
  for (int i = 0; i < n - 1; ++i) {
    h[i + 1] = min(w[i + 1], h[i + 1]);
    if (h[i] < h[i + 1]) return cout << "NO" << endl, 0;
  }
  return cout << "YES" << endl, 0;
}
