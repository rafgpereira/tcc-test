#include <bits/stdc++.h>
using namespace std;
int main(void) {
  int n, w, h;
  int w1 = -1;
  int h1 = -1;
  int max1 = -1;
  int ok = 1;
  cin >> n;
  cin >> w >> h;
  max1 = max(max1, w);
  max1 = max(max1, h);
  for (int i = 1; i <= n; i++) {
    cin >> w >> h;
    if (max1 >= w) {
      w1 = w;
      max1 = max(max1, w1);
    }
    if (max1 >= h) {
      h1 = h;
      max1 = max(max1, h1);
    }
    if (h1 == -1 && w1 == -1) {
      ok = 0;
      break;
    }
    h1 = -1;
    w1 = -1;
  }
  if (ok)
    std::cout << "YES" << std::endl;
  else
    std::cout << "NO" << std::endl;
}
