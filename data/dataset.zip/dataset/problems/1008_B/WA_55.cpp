#include <bits/stdc++.h>
using namespace std;
struct node {
  int x;
  int y;
} a[100005];
int main() {
  int n;
  cin >> n;
  for (int i = 0; i < n; i++) {
    cin >> a[i].x >> a[i].y;
    if (a[i].x > a[i].y) swap(a[i].x, a[i].y);
  }
  int flag = 0;
  if (n == 1)
    cout << "NO" << endl;
  else {
    for (int i = 0; i < n - 1; i++) {
      if (a[i].y >= a[i + 1].x) {
        flag = 1;
        cout << "YES" << endl;
        break;
      }
    }
    if (!flag) cout << "NO" << endl;
  }
  return 0;
}
