#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, i;
  bool flag = 0;
  cin >> n;
  long long w[n], h[n];
  for (i = 0; i < n; ++i) {
    cin >> w[i] >> h[i];
  }
  for (i = 0; i < n - 1; ++i) {
    if (h[i] >= h[i + 1] || h[i] >= w[i + 1] || w[i] >= h[i + 1] ||
        w[i] >= w[i + 1]) {
      flag = 1;
    } else {
      flag = 0;
      break;
    }
  }
  if (flag)
    cout << "YES";
  else
    cout << "NO";
  return 0;
}
