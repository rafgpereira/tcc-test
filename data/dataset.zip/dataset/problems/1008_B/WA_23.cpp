#include <bits/stdc++.h>
using namespace std;
int main() {
  int N;
  cin >> N;
  int length[N], width[N];
  int max, min;
  for (int i(0); i < N; i++) {
    cin >> width[i];
    cin >> length[i];
  }
  int final[N];
  for (int i(0); i < N; i++) {
    if (i == 0) {
      final[i] = (length[i] >= width[i]) ? length[i] : width[i];
    } else {
      max = (length[i] >= width[i]) ? length[i] : width[i];
      min = (length[i] < width[i]) ? length[i] : width[i];
      if (max <= final[i - 1]) {
        final[i] = max;
      } else {
        if (min <= final[i - 1]) {
          final[i] = min;
        } else {
          cout << "NO";
          break;
        }
      }
      if (i == N - 1) {
        cout << "YES";
      }
    }
  }
  return 0;
}
