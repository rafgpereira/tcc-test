#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  int w[n], h[n], a[n];
  for (int i = 0; i < n; i++) {
    cin >> w[i] >> h[i];
  }
  for (int i = 0; i < n - 1; i++) {
    if (w[i] >= w[i + 1] || h[i] >= h[i + 1] || h[i] >= w[i + 1] ||
        w[i] >= h[i + 1])
      continue;
    else {
      cout << "NO";
      return (0);
    }
  }
  cout << "YES";
}
