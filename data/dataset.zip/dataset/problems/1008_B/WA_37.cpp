#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 7;
int n, w[N], h[N];
int main() {
  scanf("%d ", &n);
  for (int i = 1; i <= n; i++) {
    scanf("%d %d ", &w[i], &h[i]);
    if (h[i] <= h[i - 1] || h[i] <= w[i - 1] || w[i] <= h[i - 1] ||
        w[i] <= w[i - 1]) {
      cout << "YES";
      return 0;
    }
  }
  cout << "NO";
  return 0;
}
