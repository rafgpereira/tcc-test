#include <bits/stdc++.h>
using namespace std;
int main() {
  long long a, p = 1;
  cin >> a;
  long long x[2 * a], y[2 * a];
  for (long long i = 0; i < a; ++i) cin >> x[i] >> y[i];
  for (long long i = 0; i < a - 1; ++i) {
    if (x[i] < x[i + 1] && x[i] < y[i + 1] && y[i] < x[i + 1] &&
        y[i] < y[i + 1]) {
      cout << "NO";
      return 0;
    }
  }
  cout << "YES";
}
