#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  vector<int> v(n);
  int mh = 0;
  int w, h;
  cin >> w >> h;
  mh = max(w, h);
  for (int i = 0; i < n - 1; i++) {
    cin >> w >> h;
    if (max(w, h) > mh) {
      cout << "NO"
           << "\n";
      return 0;
    }
    mh = max(w, h);
  }
  cout << "YES"
       << "\n";
  return 0;
}
