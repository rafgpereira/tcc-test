/************************** HEADER FILES *******************************************/

#define TESTCASE codechef  /* <<<<<<<-REMOVE -<<<<<<<<<<<<<<<*/

#include<bits/stdc++.h>
#include <cmath>
#include <climits>
#include <queue>
#include <vector>
#include <map>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stack>
#include <algorithm>
#include <cstring>
#include <cassert>
using namespace std;
/**************************** MACRO ***********************************************/
#define mod 1000000007
#define sd(n) scanf("%d",&n);
#define sl(n) scanf("%ld",&n);
#define sll(n) scanf("%lld",&n);
#define ll long long
#define pd(n) printf("%d\n",n);
#define pl(n) printf("%ld\n",n);
#define pll(n) printf("%lld\n",n);
#define ios ios_base::sync_with_stdio(false);cin.tie(NULL);
#define read freopen("in.txt","r",stdin);
#define use ll i,j;
#define sc1(a,n) for(i=0;i<n;i++)sll(a[i]);
#define sc2 (a,m,n) for(i=0;i<m;i++){for(j=0;j<n;j++){sll(a[i][j];}}

#define ERR
#ifdef ERR
#define deb(...) __f(#__VA_ARGS__, __VA_ARGS__)
template <typename Arg1>
void __f(const char* name, Arg1&& arg1)
{
	cerr << name << " : " << arg1 << std::endl;
}
template <typename Arg1, typename... Args>
void __f(const char* names, Arg1&& arg1, Args&&... args)
{
	const char* comma = strchr(names + 1, ',');cerr.write(names, comma - names) << " : " << arg1<<" | ";__f(comma+1, args...);
}
#else
#define deb(...)
#endif
#define f first
#define s second
/**************************** START HERE ***********************************************/
bool check(vector<pair<ll,ll>>v,ll sa,ll se,int visit[])
{
  use;
  if(sa<0||se>=v.size())
    return true;
  for(i=sa;i<=se;i++)
  {
    if(v[i-1].s<v[i].s)
    {
      if(v[i-1].s<v[i].f)
      {
        if(visit[i-1]==2)
          return false;
        if(v[i-1].f>=v[i].f)
        {
          swap(v[i-1].f,v[i-1].s);
          visit[i-1]++;
          if(!check(v,1,i,visit))
            return false;
        }
        else if(v[i-1].f>=v[i].s)
        {
          swap(v[i-1].f,v[i-1].s);
          visit[i-1]++;
          if(!check(v,1,i,visit))
            return false;
        }
        else
          {
          return false;
          }
      }
      else if(v[i-1].s>=v[i].f)
      {
        swap(v[i].f,v[i].s);
      }
      else
        {
        return false;
        }
    }
  }
  return true;
}
int main()
{
  //ios;
  use;
  #ifdef TESTCASE
 // read;
  #endif // TESTCASE
  long long n,a,b;
  sll(n);
  vector<pair<ll,ll>>v;
  int visit[n]={};
  memset(visit,false,sizeof(visit));
  for(i=0;i<n;i++)
  {
    cin>>a>>b;
    v.emplace_back(make_pair(a,b));
  }
  if(check(v,1,n-1,visit))
    cout<<"YES"<<endl;
    else
      cout<<"NO"<<endl;
}
