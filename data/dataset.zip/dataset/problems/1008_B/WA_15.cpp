#include <bits/stdc++.h>
int main() {
  int n, x, y;
  scanf("%d", &n);
  bool fx = true, fy = true;
  int prevX = -1, prevY = -1;
  for (int i = 0; i < n; ++i) {
    scanf("%d%d", &x, &y);
    if (i == 0) {
      fx = fy = true;
    } else {
      fx = (x <= prevX && fx) || (x <= prevY && fy);
      fy = (y <= prevX && fx) || (y <= prevY && fy);
    }
    prevX = x;
    prevY = y;
  }
  if (fx || fy) {
    puts("YES");
  } else {
    puts("NO");
  }
  return 0;
}
