#include<bits/stdc++.h>
using namespace std;
unsigned long long int z,x,n,ans=999999999999;
main ()
{
    cin >> n;
    for(int i= 1 ;i <= n ;++i)
    {
        cin >> z >> x;
        if(ans>=max(z,x))
        {
            ans=max(z,x);
        }
            else if(ans>=min(z,x))
        {
            ans=max(z,x);
        }
        else
        {
            cout <<"NO";
            return 0;
        }
    }
    cout << "YES";
}
