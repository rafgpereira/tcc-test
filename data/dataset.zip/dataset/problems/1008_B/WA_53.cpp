#include <bits/stdc++.h>
using namespace std;
int a[100010], b[100010];
int main() {
  int n;
  scanf("%d", &n);
  for (int i = 1; i <= n; i++) scanf("%d %d", &a[i], &b[i]);
  int pre = 2e9;
  for (int i = 1; i <= n; i++) {
    if (a[i] > b[i]) swap(a[i], b[i]);
    if (a[i] > pre) {
      puts("NO");
      return 0;
    }
    if (b[i] < pre)
      pre = b[i];
    else
      pre = a[i];
  }
  puts("YES");
  return 0;
}
