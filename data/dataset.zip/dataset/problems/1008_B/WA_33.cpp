#include <bits/stdc++.h>
using namespace std;
const long double PI = atan(1.0) * 4.0;
const long long int MOD = 1e9 + 7;
const long long int INF = 1e18;
const long double EPS = 0.0000001;
int main() {
  ios_base::sync_with_stdio(false), cin.tie(NULL);
  long long int n, w, h;
  cin >> n;
  vector<pair<int, int> > v;
  for (int i = 0; i < n; i++) {
    cin >> w >> h;
    v.push_back(make_pair(w, h));
  }
  for (int i = n - 1; i >= 1; i--) {
    if (v[i].first <= v[i - 1].first || v[i].second <= v[i - 1].first ||
        v[i].second <= v[i - 1].second || v[i].first <= v[i - 1].second) {
      continue;
    } else {
      cout << "NO"
           << "\n";
      return 0;
    }
  }
  cout << "YES"
       << "\n";
  return 0;
}
