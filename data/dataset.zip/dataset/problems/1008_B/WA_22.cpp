#include <bits/stdc++.h>
using namespace std;
long long w[1000050], h[1000050];
int main() {
  int n;
  cin >> n;
  for (int i = 0; i < n; i++) {
    scanf("%I64d %I64d", &w[i], &h[i]);
  }
  long long high = max(w[0], h[0]);
  for (int i = 1; i < n; i++) {
    if (w[i] > high && h[i] > high) {
      cout << "NO" << endl;
      return 0;
    } else if (w[i] < high && h[i] < high) {
      high = max(w[i], h[i]);
    } else {
      high = min(w[i], h[i]);
    }
  }
  cout << "YES" << endl;
}
