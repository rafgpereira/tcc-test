#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 20;
int n;
pair<int, int> a[maxn];
int main() {
  cin >> n;
  for (int i = 0; i < n; i++) cin >> a[i].first >> a[i].second;
  if (a[0].first < a[0].second) swap(a[0].first, a[0].second);
  for (int i = 1; i < n; i++) {
    if (a[i].first > a[i - 1].first && a[i].second > a[i - 1].first) {
      cout << "NO";
      return 0;
    }
    if (a[i].first > a[i - 1].first) a[i].first = a[i].second;
  }
  cout << "YES";
  return 0;
}
