#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n;
  cin >> n;
  long long a, b, Maxt;
  bool check = false;
  cin >> a >> b;
  Maxt = max(a, b);
  for (long long i = 1; i < n; i++) {
    cin >> a >> b;
    if (Maxt < a && Maxt < b) check = true;
    Maxt = max(a, b);
  }
  if (check == true)
    cout << "NO";
  else
    cout << "YES";
  return 0;
}
