#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, ok = 1, i;
  long long x, y, a, b;
  cin >> n;
  cin >> a >> b;
  int maxi = max(a, b);
  for (i = 1; i < n; i++) {
    cin >> x >> y;
    if (x < y) {
      int temp = x;
      x = y;
      y = temp;
    }
    if (y > maxi) ok = 0;
  }
  if (ok)
    cout << "YES";
  else
    cout << "NO";
  return 0;
}
