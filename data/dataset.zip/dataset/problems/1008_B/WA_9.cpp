#include <bits/stdc++.h>
using namespace std;
int n, h[100001], w[100001];
bool trap;
int main() {
  cin >> n;
  for (int i = 1; i <= n; i++) {
    cin >> w[i] >> h[i];
  }
  if (h[1] < w[1]) swap(h[1], w[1]);
  for (int i = 2; i <= n; i++) {
    if (h[i] > h[i - 1] && h[i - 1] >= w[i]) {
      swap(h[i], w[i]);
    }
  }
  for (int i = 2; i <= n; i++) {
    if (h[i] > h[i - 1]) {
      trap = true;
      break;
    }
  }
  trap == true ? cout << "NO" : cout << "YES";
}
