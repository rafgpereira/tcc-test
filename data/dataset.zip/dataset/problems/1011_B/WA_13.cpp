#include <bits/stdc++.h>
using namespace std;
const int MAXN = 5.5e5;
const int MOD = (int)(1e9) + 7;
int freq[110];
int C[110];
int main() {
  ios_base::sync_with_stdio(false);
  int n, m;
  cin >> n >> m;
  vector<int> A(m);
  set<pair<int, int> > have;
  for (int i = 0; i < m; i++) {
    cin >> A[i];
    freq[A[i]]++;
  }
  for (int i = 0; i < m; i++) have.emplace(freq[A[i]], A[i]);
  for (int i = 0; i < n; i++) {
    if (have.empty()) {
      cout << 0 << '\n';
      exit(0);
    }
    auto p = *have.rbegin();
    have.erase(p);
    p.first--;
    C[p.second]++;
    if (p.first > 0) {
      have.insert(p);
    }
  }
  int ans = (int)(1e9);
  for (int i = 0; i < m; i++) {
    if (C[A[i]] > 0) {
      ans = min(ans, freq[A[i]] / C[A[i]]);
    }
  }
  cout << ans << '\n';
  return 0;
}
