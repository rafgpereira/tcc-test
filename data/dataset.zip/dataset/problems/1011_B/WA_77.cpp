#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  int n, m, k, x, y;
  cin >> n >> m;
  int a[m];
  map<int, int> M;
  map<int, int>::iterator it;
  for (k = 0; k < m; k++) {
    cin >> a[k];
    M[a[k]]++;
  }
  if (n > m) {
    cout << "0";
  } else {
    multiset<int> s;
    for (it = M.begin(); it != M.end(); it++) {
      s.insert(it->second);
      if (s.size() == n) break;
    }
    int p = 0;
    multiset<int>::iterator i;
    multiset<int>::iterator j;
    if (s.size() < n && s.size() != 1) {
      while (s.size() != n) {
        i = s.begin();
        s.erase(i);
        s.insert(1);
        s.insert((*i) - 1);
      }
    }
    if (s.size() == 1) {
      i = s.begin();
      cout << (*i) / n;
    } else {
      while (p == 0) {
        i = s.begin();
        j = s.end();
        --j;
        x = *i;
        y = *j;
        if ((y - x - 1) > x) {
          s.erase(i);
          s.erase(j);
          s.insert(x + 1);
          s.insert(y - x - 1);
        } else
          p = 1;
      }
      i = s.begin();
      cout << (*i);
    }
  }
  return 0;
}
