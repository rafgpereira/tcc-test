#include <bits/stdc++.h>
#include <ext/rope>

#define  pb   push_back
#define  int  long long
#define  endl "\n"
#define  MX   100005

#define  W(t)            while(t--)
#define  all(v)          v.begin(),v.end()
#define  gcd(a,b)        __gcd(a,b)
#define  lcm(a,b)        (a*b)/gcd(a,b)
#define  rep(i,a,b)      for(int i = a; i <= b; i++)

using namespace std;
using namespace __gnu_cxx;

int freq[205];
int n, m;
vector<int> v;

bool cmp(int x, int y)
{
   return freq[x] > freq[y];
}
void solve()
{
   int ans  = 0;
   cin >> n >> m;
   int a[m];

   rep(i, 0, m - 1) {
      cin >> a[i];
      if (!freq[a[i]])
         v.pb(a[i]);
      freq[a[i]]++;
   }
   sort(all(v), cmp);
   rep(i, 0, v.size() - 1) {

      int sum = freq[v[i]];
      int mn_fq = freq[v[i]];
      ans = max(ans, (int)freq[v[i]] / n);
      freq[v[i]]--;

      rep(j, i + 1, v.size() - 1) {
         mn_fq = min(mn_fq, freq[v[j]]);
         if ((j + 1) < n) {
            sum += freq[v[j]];
            ans = max(ans, min(mn_fq, (int)(sum / n)));
         }
         else {
            sum += freq[v[j]];
            ans = max(ans, min(mn_fq, (int)(sum / n)));;
            break;
         }
      }
   }

   cout << ans;
   return;
}
signed main()
{
   ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0);

   solve();

   return 0;
}