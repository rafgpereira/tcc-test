#include <bits/stdc++.h>
using namespace std;
const int maxen = 1000;
int main() {
  int n, m;
  cin >> n >> m;
  int v[maxen]{};
  int ans = m / n;
  int a = 0;
  int res = 0;
  for (int i = 0; i < m; i++) {
    cin >> a;
    v[a]++;
  }
  if (ans == 0) {
    cout << 0;
    return 0;
  }
  while (5 == 5) {
    for (int i = 0; i < 107; i++) {
      if (v[i] != 0) {
        res += (v[i] / ans);
      }
    }
    if (res >= n) {
      cout << ans;
      return 0;
    } else {
      ans--;
    }
  }
}
