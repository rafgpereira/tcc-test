#include <bits/stdc++.h>
using namespace std;
int main() {
  int n;
  cin >> n;
  int m;
  cin >> m;
  vector<int> a(101);
  for (int i = 0; i < m; i++) {
    int x;
    cin >> x;
    a[x]++;
  }
  sort(a.rbegin(), a.rend());
  int cnt = 0;
  for (int i = 1; i <= 100; i++) {
    int k = n;
    for (int j = 0; j < a.size(); j++) {
      if (a[j] == 0) {
        break;
      }
      k -= a[j] / i;
    }
    if (k > 0) {
      cout << i - 1 << "\n";
      break;
    }
  }
}
