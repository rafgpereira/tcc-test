#include <bits/stdc++.h>
using namespace std;
bool check(vector<int>& v, int k, int n, int m) {
  int count = 0;
  for (int i = 0; i < m; i++) {
    count += v[i] / k;
    if (count >= n) {
      return true;
    }
  }
  return false;
}
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  int t;
  t = 1;
  while (t--) {
    int n, m;
    cin >> n >> m;
    int a[m];
    if (n == 1 && m == 1 && a[0] == 1) {
      cout << 1;
      return 0;
    }
    for (int i = 0; i < m; i++) {
      cin >> a[i];
    }
    map<int, int> freq;
    for (int i = 0; i < m; i++) {
      freq[a[i]]++;
    }
    vector<int> v;
    for (auto it = freq.begin(); it != freq.end(); it++) {
      v.push_back(it->second);
    }
    int start = 1;
    int end = *max_element(v.begin(), v.end());
    int ans = 1;
    int x = v.size();
    if (m == 1 && a[0] == 1) {
      cout << 0;
      return 0;
    }
    while (start <= end) {
      int mid = start + (end - start) / 2;
      if (check(v, mid, n, x)) {
        ans = mid;
        start = mid + 1;
      } else {
        end = mid - 1;
      }
    }
    cout << ans;
  }
  return 0;
}
