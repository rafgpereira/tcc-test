#include <bits/stdc++.h>
const int N = 1e5 + 5;
const int mod = 1e9 + 7;
const int INT = 0x3f3f3f3f;
using namespace std;
int n, m;
string s, t;
int a[111];
int b[111];
int cnt;
int ans;
bool check(int mid) {
  int num = 0;
  for (int i = cnt - 1; i >= 0; i--) {
    num += b[i] / mid;
    if (num >= n) return true;
  }
  return false;
}
int main() {
  ios::sync_with_stdio(false);
  cin >> n >> m;
  for (int i = 0; i < m; i++) scanf("%d", &a[i]);
  if (m < n)
    puts("0");
  else {
    sort(a, a + m);
    int num = 1;
    for (int i = 0; i < m; i++) {
      if (a[i] == a[i + 1]) {
        num++;
      } else {
        b[cnt] = num;
        cnt++;
        num = 1;
      }
    }
    sort(b, b + cnt);
    int l = 1, r = b[cnt - 1];
    while (l <= r) {
      int mid = (l + r) / 2;
      if (check(mid)) {
        l = mid + 1;
      } else
        r = mid - 1;
    }
    cout << l - 1 << endl;
  }
  return 0;
}
