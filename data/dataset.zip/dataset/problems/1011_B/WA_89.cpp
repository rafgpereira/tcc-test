#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  while (~scanf("%d%d", &n, &m)) {
    int a[105];
    int coun[105] = {0};
    for (int i = 0; i < m; i++) {
      scanf("%d", &a[i]);
      coun[a[i]]++;
    }
    if (m < n) {
      printf("0\n");
      continue;
    }
    sort(coun + 1, coun + 101, greater<int>());
    int maxx, minn;
    while (1) {
      sort(coun + 1, coun + n, greater<int>());
      maxx = coun[1];
      minn = coun[n];
      int s = 0;
      for (int i = n; i > 0; i--) {
        if (coun[i] == coun[i - 1])
          s++;
        else {
          s++;
          break;
        }
      }
      s++;
      if (minn * s >= maxx) break;
      coun[0] = maxx - (maxx / s * s);
      for (int i = n; i >= n - s; i--) coun[i] = maxx / s;
    }
    printf("%d\n", minn);
  }
  return 0;
}
