#include <bits/stdc++.h>
using namespace std;
int arr[500], fq[500];
vector<int> vec;
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(NULL);
  int n, m, tot = 0;
  cin >> n >> m;
  for (int i = 0; i < m; i++) {
    cin >> arr[i];
    fq[arr[i]]++;
  }
  int cnt = 0, ans = 0;
  for (int i = 1; i < 100; i++) {
    if (fq[i] != 0) vec.push_back(fq[i]);
  }
  sort(vec.begin(), vec.end());
  int temp = 0;
  ans = 0;
  for (int i = 1; i <= 100; i++) {
    temp = 0;
    for (int j = vec.size() - 1; j >= 0; j--) {
      temp += vec[j] / i;
    }
    if (temp >= n) {
      ans = i;
    } else
      break;
  }
  cout << ans << endl;
}
