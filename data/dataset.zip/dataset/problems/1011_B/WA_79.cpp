#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  int a[100] = {0};
  for (int i = 0; i < m; i++) {
    int num;
    cin >> num;
    a[num]++;
  }
  sort(a, a + 100, greater<int>());
  int ans = 0;
  int n2 = n;
  for (int i = 1; i <= 50; i++) {
    int temp[m];
    for (int i = 0; i < m; i++) {
      temp[i] = a[i];
    }
    n = n2;
    int ind = 0;
    int flag = 0;
    while (true) {
      n = n - (temp[ind] / i);
      if (n <= 0) {
        ans = i;
        break;
      }
      if (n > 0) {
        ind++;
      }
      if (temp[ind] == 0) {
        flag = 1;
        break;
      }
    }
    if (flag == 1) {
      break;
    }
  }
  cout << ans;
  return 0;
}
