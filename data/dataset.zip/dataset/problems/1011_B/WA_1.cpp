#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 7;
int main() {
  int n, m;
  cin >> n >> m;
  int d = 0, cnt[101] = {0}, a[m];
  for (int i = 0; i < m; i++) {
    cin >> a[i];
    cnt[a[i]]++;
  }
  sort(cnt, cnt + 101);
  for (int i = 0; i < 101; i++) {
    if (cnt[i] == 0)
      continue;
    else {
      int tmp = 0;
      for (int j = i; j < 101; j++) {
        tmp += cnt[j] / cnt[i];
        if (tmp >= n) d = cnt[i];
      }
    }
  }
  cout << d;
  return 0;
}
