#include <bits/stdc++.h>
using namespace std;
int a[110];
bool cmp(int a, int b) { return a > b; }
int main() {
  int n, m;
  cin >> n >> m;
  memset(a, 0, sizeof(a));
  for (int i = 0; i < m; i++) {
    int tem;
    cin >> tem;
    a[tem]++;
  }
  sort(a, a + 100, cmp);
  int flag = 0;
  for (int i = 1; a[0] / i > 0; i++) {
    int tem = i;
    int day = (a[0] / i);
    for (int j = 1; j < 100; j++) {
      tem += a[j] / (a[0] / i);
    }
    if (tem >= n) {
      flag = 1;
      cout << a[0] / i << endl;
      break;
    }
  }
  if (flag == 0) cout << 0 << endl;
  return 0;
}
