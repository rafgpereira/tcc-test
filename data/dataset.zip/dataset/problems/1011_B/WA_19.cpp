#include <bits/stdc++.h>
const double pi = 4.0 * atan(1.0);
const int inf = 0x3f3f3f3f;
const int maxn = 100005;
const int maxm = 100000;
const int mod = 998244353;
using namespace std;
int n, m, tol, T;
int a[maxn] = {0};
int cnt[maxn] = {0};
int main() {
  scanf("%d%d", &m, &n);
  for (int i = 1; i <= n; i++) {
    scanf("%d", &a[i]);
    cnt[a[i]]++;
  }
  if (m > n) {
    printf("0\n");
    return 0;
  }
  sort(a + 1, a + 1 + n);
  int nn = unique(a + 1, a + 1 + n) - (a + 1);
  int left = 0;
  int right = n / m;
  int res = 0;
  while (left <= right) {
    int mid = (left + right) >> 1;
    if (mid == 0) break;
    int ans = 0;
    for (int i = 1; i <= nn; i++) {
      ans += cnt[a[i]] / mid;
      if (ans >= m) break;
    }
    if (ans >= m) {
      res = mid;
      left = mid + 1;
    } else
      right = mid - 1;
  }
  printf("%d\n", res);
  return 0;
}
