#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n, m, a, k;
  k = 0;
  long long int t = 0;
  long long int f[101] = {0};
  set<long long int> s1;
  vector<long long int> v1;
  cin >> n >> m;
  for (long long int i = 0; i < m; i++) {
    cin >> a;
    f[a - 1]++;
    s1.insert(a - 1);
  }
  for (auto it = s1.begin(); it != s1.end(); it++) {
    v1.push_back(f[*it]);
  }
  sort(v1.begin(), v1.end());
  long long int j = m;
  double b;
  while (j >= 1) {
    k = 0;
    for (auto it = v1.begin(); it != v1.end(); it++) {
      k = k + (*it / j);
      if (k >= n) {
        t++;
        cout << j << "  ";
        break;
      }
    }
    if (t != 0) {
      break;
    }
    b = ((j * 1.0) / (2 * 1.0));
    if (j >= 2) {
      j = ceil(b);
    } else if (j < 2) {
      break;
    }
  }
  if (t == 0) {
    cout << "0";
  }
}
