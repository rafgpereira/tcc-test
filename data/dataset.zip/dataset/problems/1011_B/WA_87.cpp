#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  long long n = 0, m = 0, mn = 1000000000007, d = 0, mx = 0, h = 0, l = 0,
            w = 0, r = 0, k = 0, j = 0, i = 0, ans;
  cin >> n >> m;
  int a[100];
  for (int i = 0; i < 100; i++) a[i] = 0;
  for (int i = 0; i < m; i++) {
    cin >> d;
    a[d - 1]++;
  }
  sort(a, a + 100, greater<int>());
  for (int i = 0; i < 100; i++) {
    if (i >= n) break;
    k += a[i];
  }
  cout << k / n << endl;
}
