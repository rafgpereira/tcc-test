#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> m >> n;
  if (m > n) {
    cout << -1 << endl;
    return 0;
  }
  int a[n];
  int sum = 0;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  unordered_map<int, int> s;
  for (int i = 0; i < n; i++) {
    if (s.find(a[i]) == s.end())
      s[a[i]] = 1;
    else {
      s[a[i]]++;
    }
  }
  int max_days = n / m;
  int count = 0;
  while (max_days != 0) {
    unordered_map<int, int>::iterator itr;
    for (itr = s.begin(); itr != s.end(); itr++) {
      count = count + (itr->second) / max_days;
      if (count >= m) {
        cout << max_days << endl;
        return 0;
      }
    }
    max_days--;
  }
  cout << -1 << endl;
  return 0;
}
