#include <bits/stdc++.h>
using namespace std;
int main(void) {
  int p, n;
  cin >> p >> n;
  int a[n], c = 0, d = 0, e;
  for (int i = 0; i < n; i++) cin >> a[i];
  sort(a, a + n);
  c = a[0];
  e = a[0];
  for (int i = 1; i < n; i++) {
    if (e != a[i]) {
      c += a[i];
      e = a[i];
    } else if (a[i] == a[i - 1])
      d++;
  }
  if (a[n - 2] != a[n - 1]) c = c - a[n - 1];
  if (p > n) {
    cout << 0 << endl;
  } else if (n == p) {
    cout << 1 << endl;
  } else if (d + 1 == n)
    cout << n / p << endl;
  else if (d == 0) {
    cout << 1 << endl;
  } else {
    cout << (c) / p << endl;
  }
  return 0;
}
