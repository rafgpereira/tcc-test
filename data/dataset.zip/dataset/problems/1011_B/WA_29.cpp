#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  vector<int> v(101, 0);
  for (int i = 0; i < m; i++) {
    int k;
    cin >> k;
    v[k] += 1;
  }
  vector<int> a;
  for (int i = 0; i < 101; i++) {
    if (v[i] != 0) a.push_back(v[i]);
  }
  sort(a.begin(), a.end());
  int x = a.size();
  for (int i = 0; i < x; i++) {
    cout << a[i] << " ";
  }
  cout << endl;
  int low = 0, high = (m / n) + 1;
  while (high > low) {
    int mid = (low + high + 1) / 2;
    int ans = 0;
    for (int i = 0; i < x; i++) {
      ans += (a[i] / mid);
    }
    if (ans < n)
      high = mid - 1;
    else
      low = mid;
  }
  cout << low << endl;
}
