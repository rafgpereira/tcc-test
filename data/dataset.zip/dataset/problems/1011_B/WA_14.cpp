#include <bits/stdc++.h>
using namespace std;
struct food {
  int food, qty;
};
bool comp(struct food a, struct food b) { return a.qty > b.qty; }
int main() {
  int n, i, num, tmp, s, ct = 0, j, days, k;
  cin >> k >> n;
  if (k > n)
    cout << "0" << endl;
  else {
    map<int, int> m;
    for (i = 0; i < n; i++) {
      cin >> num;
      m[num]++;
    }
    s = m.size();
    struct food f[s];
    i = 0;
    map<int, int>::iterator it;
    for (it = m.begin(); it != m.end(); it++) {
      f[i].food = it->first;
      f[i].qty = it->second;
      i++;
    }
    sort(f, f + s, comp);
    if (s == 1)
      cout << (f[0].qty / k) << endl;
    else {
      for (i = 0; i < s; i++) {
        tmp = f[i].qty;
        ct = 0;
        for (j = 0; j < s; j++) {
          if (f[j].qty == tmp) {
            ct++;
          } else {
            ct = ct + (f[j].qty) / tmp;
          }
        }
        if (ct == k) {
          days = f[i].qty;
          break;
        }
      }
      cout << days << endl;
    }
    return 0;
  }
}
