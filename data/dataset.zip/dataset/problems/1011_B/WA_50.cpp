#include <bits/stdc++.h>
#pragma GCC optimize("O3")
using namespace std;
struct bucket {
  int d, diff;
};
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  ;
  int n, k, t;
  cin >> n >> k;
  std::map<int, int> m;
  for (__typeof(0) c = 0; c < k; c++) {
    cin >> t;
    if (m.find(t) == m.end()) {
      m[t] = 1;
    } else {
      m[t]++;
    }
  }
  vector<int> a;
  int s = 0, ans;
  for (__typeof(m.begin()) it = m.begin(); it != m.end(); it++) {
    a.push_back(it->second);
  }
  sort((a).begin(), (a).end());
  int c;
  for (c = 0; c < a.size(); ++c) {
    if ((k / n) > a[c])
      k -= a[c];
    else
      break;
    if ((k / n) <= a[c]) return cout << a[c], 0;
  }
  cout << k / n;
}
