#include <bits/stdc++.h>
template <typename Arg1>
void ZZ(const char* name, Arg1&& arg1) {
  std::cout << name << " = " << arg1 << std::endl;
}
template <typename Arg1, typename... Args>
void ZZ(const char* names, Arg1&& arg1, Args&&... args) {
  const char* comma = strchr(names + 1, ',');
  std::cout.write(names, comma - names) << " = " << arg1;
  ZZ(comma, args...);
}
using namespace std;
long long n, m, k, q;
vector<long long> ar;
vector<long long> fr;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  cin >> m >> n;
  ar.resize(n);
  fr.resize(101, 0);
  for (long long i = 0; i < n; i++) {
    cin >> ar[i];
    fr[ar[i]]++;
  }
  long long ans = 0;
  for (long long i = 0; i < 100; i++) {
    priority_queue<long long> st;
    for (long long i = 0; i <= 100; i++) {
      st.push(fr[i]);
    }
    bool suc = true;
    for (long long j = 0; j < m; j++) {
      if (st.top() < i) {
        suc = false;
        break;
      } else {
        long long x = st.top() - i;
        st.pop();
        st.push(x);
      }
    }
    if (suc) ans = i;
  }
  cout << ans << endl;
  return 0;
}
