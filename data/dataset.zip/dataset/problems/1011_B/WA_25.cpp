#include <bits/stdc++.h>
using namespace std;
int n, k;
int a[105];
int b[105];
int check(int mid) {
  int ans = 0;
  if (mid > 0)
    for (int i = 0; i < 105; i++) {
      ans += b[i] / mid;
    }
  return ans;
}
int main() {
  cin >> n >> k;
  int ans = 0;
  for (int i = 0; i < k; i++) cin >> a[i];
  for (int i = 0; i < k; i++) b[a[i]]++;
  int l = 0, r = 104, mid;
  while (l <= r) {
    mid = (l + r) / 2;
    if (check(mid) >= n) {
      ans = max(ans, mid);
      l = mid + 1;
    } else
      r = mid - 1;
  }
  cout << ans;
}
