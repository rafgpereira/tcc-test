#include <bits/stdc++.h>
using namespace std;
int main(void) {
  int ep, num;
  cin >> ep >> num;
  int item[num], count[num];
  for (int i = 0; i < num; i++) count[i] = 0;
  for (int i = 0; i < num; i++) cin >> item[i];
  if (ep > num) {
    cout << 0 << endl;
    return 0;
  }
  sort(item, item + num);
  count[0]++;
  for (int i = 1, j = 0; i < num; i++) {
    if (item[i - 1] != item[i]) {
      j++;
      count[j]++;
    }
    if (item[i - 1] == item[i]) count[j]++;
  }
  sort(count, count + num);
  int max1 = 1, max2 = 1, countTemp = 1;
  for (int i = 1; i < num; i++) {
    if (count[i - 1] == count[i]) {
      countTemp++;
      if (ep <= countTemp) max2 = count[i];
    }
    if (count[i - 1] != count[i]) countTemp = 1;
  }
  for (int i = num - 2, j = num - 1; i >= 0; i--) {
    if (count[num - 2] == 0) {
      max1 = count[num - 1] / ep;
      break;
    }
    if (count[i] == 0)
      i--;
    else if ((count[j] / count[i]) >= 2 && count[i] > 0) {
      if (max1 < count[i]) max1 = count[i];
    } else
      continue;
  }
  if (max2 > max1)
    cout << max2 << endl;
  else
    cout << max1 << endl;
  return 0;
}
