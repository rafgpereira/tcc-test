#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 5;
const int INF = 0x3f3f3f3f;
const long long LL_INF = 0x3f3f3f3f3f3f3f3f;
const int dx[] = {-1, 0, 1, 0}, dy[] = {0, 1, 0, -1};
int n, m;
int a[105];
map<int, int> mm;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  int days = 0;
  cin >> n >> m;
  for (int i = 0; i < m; ++i) cin >> a[i], mm[a[i]] += 1;
  if (m < n) {
    cout << 0 << endl;
    return 0;
  } else if (m == n) {
    cout << 0 << endl;
    return 0;
  } else {
    for (int i = 1; i <= m / n; ++i) {
      int tot = 0;
      for (auto it = mm.begin(); it != mm.end(); ++it) {
        if (it->second >= i) {
          tot += it->second / i;
        }
      }
      if (tot >= n) ++days;
    }
    cout << days << endl;
  }
  cerr << "Time elapsed: " << 1.0 * clock() / CLOCKS_PER_SEC << " s.\n";
  return 0;
}
