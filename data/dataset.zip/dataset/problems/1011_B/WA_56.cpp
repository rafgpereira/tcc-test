#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
int visit[N];
int num[N];
int main() {
  int n, m;
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= m; i++) {
    int x;
    scanf("%d", &x);
    visit[x]++;
  }
  sort(visit + 1, visit + 100 + 1, greater<int>());
  if (m < n) {
    printf("0\n");
    return 0;
  }
  int ans = visit[1] / n;
  for (int i = 2; i <= n; i++) {
    int tmp = min(visit[1] / (n - i + 1), visit[i]);
    ans = max(ans, tmp);
  }
  printf("%d\n", ans);
  return 0;
}
