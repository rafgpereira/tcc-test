#include <bits/stdc++.h>
using namespace std;
template <typename Arg1>
void __f(const char* name, Arg1&& arg1) {
  cerr << name << " : " << arg1 << std::endl;
}
template <typename Arg1, typename... Args>
void __f(const char* names, Arg1&& arg1, Args&&... args) {
  const char* comma = strchr(names + 1, ',');
  cerr.write(names, comma - names) << " : " << arg1 << " | ";
  __f(comma + 1, args...);
}
const long long maxn = (long long)1e4 + 50;
const double EPS = 1e-9;
const long long INF = 1e18 + 18;
const long long MOD = (long long)1e9 + 7;
long long n, m, a[maxn];
map<long long, long long> mp;
signed main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cout.tie(0);
  cin >> n >> m;
  for (long long i = 1; i <= m; i++) {
    cin >> a[i];
    mp[a[i]]++;
  }
  for (long long d = 100; d >= 1; d--) {
    long long people = 0;
    for (auto x : mp) {
      people += x.second;
    }
    people /= d;
    if (people >= n) {
      cout << d << endl;
      return 0;
    }
  }
  cout << "0" << endl;
  return 0;
}
