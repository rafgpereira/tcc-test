#include <bits/stdc++.h>
using namespace std;
int n, m, t, a, offset = 0, temp;
multiset<pair<int, int> > food;
int toff[101] = {};
int main() {
  scanf("%d %d[^n]", &n, &m);
  if (m < n) {
    cout << 0;
    return 0;
  }
  if (n == m) {
    cout << 1;
    return 0;
  }
  int arr[101] = {};
  for (int i = 0; i < m; i++) {
    scanf("%d[^ ]", &t);
    arr[t]++;
  }
  for (int i = 1; i < 101; i++) {
    if (arr[i] != 0) food.insert(make_pair(arr[i], i));
  }
  offset = (--food.end())->first / n;
  while (food.size() < n) {
    if ((--food.end())->first % 2 == 0) {
      food.insert(make_pair((--food.end())->first / 2, (--food.end())->second));
      food.insert(make_pair((--food.end())->first / 2, (--food.end())->second));
    } else {
      food.insert(
          make_pair(((--food.end())->first / 2) + 1, (--food.end())->second));
      food.insert(make_pair((--food.end())->first / 2, (--food.end())->second));
    }
    food.erase(--food.end());
  }
  while (food.begin()->first <= (--food.end())->first / 2) {
    if ((--food.end())->first % 2 == 0) {
      food.insert(make_pair((--food.end())->first / 2, (--food.end())->second));
      food.insert(make_pair((--food.end())->first / 2, (--food.end())->second));
    } else {
      food.insert(
          make_pair(((--food.end())->first / 2) + 1, (--food.end())->second));
      food.insert(make_pair((--food.end())->first / 2, (--food.end())->second));
    }
    while (food.size() > n && food.begin()->first < (--food.end())->first / 2)
      food.erase(food.begin());
    food.erase(--food.end());
  }
  cout << max(offset, food.begin()->first);
  return 0;
}
