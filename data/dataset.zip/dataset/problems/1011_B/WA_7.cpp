#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m, i, j, k;
  cin >> m >> n;
  int ar[n];
  for (i = 0; i < n; i++) {
    cin >> ar[i];
  }
  if (m > n) {
    cout << "0";
  } else {
    int fe[101] = {0};
    for (i = 0; i < n; i++) {
      fe[ar[i]]++;
    }
    sort(fe, fe + 101, greater<int>());
    long int l = 0;
    for (i = 0; i < m; i++)
      if (fe[i] > 0) {
        l = l + fe[i];
      }
    l = l / m;
    cout << l;
  }
  return 0;
}
