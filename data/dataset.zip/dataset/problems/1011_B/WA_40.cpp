#include <bits/stdc++.h>
using namespace std;
int n, m, x;
int a[101];
int b[101];
int ans;
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  priority_queue<pair<double, int> > pq;
  cin >> n >> m;
  for (int i = 0; i < m; i++) {
    cin >> x;
    b[x]++;
  }
  for (int i = 1; i <= 100; i++) {
    if (b[i]) pq.push({b[i], 1});
  }
  ans = 9999;
  int cnt = 0;
  for (int i = 0; i < n; i++) {
    double t1 = pq.top().first;
    int t2 = pq.top().second;
    pq.pop();
    if (t1 <= ans) {
      cnt++;
      ans = (int)t1;
      if (cnt == n) {
        cout << ans << '\n';
        return 0;
      }
    }
    pq.push({(t1 * t2) / (t2 + 1), t2 + 1});
  }
  cout << "-1\n";
  return 0;
}
