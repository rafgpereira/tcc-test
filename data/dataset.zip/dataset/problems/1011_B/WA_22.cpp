#include <bits/stdc++.h>
using namespace std;
map<pair<pair<long long int, long long int>,
         pair<long long int, long long int>>,
    long long int>
    pqr;
map<pair<long long int, long long int>, long long int> xyz;
vector<pair<long long int, pair<long long int, long long int>>> a;
vector<pair<pair<int, int>, pair<int, int>>> b;
vector<pair<long long int, long long int>> c;
bool compare(const pair<long long int, long long int> &x,
             const pair<long long int, long long int> &y) {
  return x.first > y.first;
}
bool sortbysec(const pair<int, int> &a, const pair<int, int> &b) {
  return (a.second < b.second);
}
int main() {
  long long int x, y, z, i, j, k, m, n, cnt = 1;
  cin >> n >> m;
  vector<long long int> arr(100001);
  vector<long long int> freq(10001, 0);
  set<int> ele;
  vector<long long int> ans;
  long long int sum = 0;
  for (i = 0; i < m; i++) {
    cin >> arr[m];
    if (!ele.count(arr[m])) {
      ele.insert(arr[m]);
      ans.push_back(arr[m]);
    }
    freq[arr[m]]++;
  }
  if (n > m) {
    cout << "0" << endl;
    return 0;
  }
  sort(ans.begin(), ans.end());
  vector<long long int> ans2;
  for (i = 0; i < ans.size(); i++) {
    ans2.push_back(freq[ans[i]]);
    sum = sum + freq[ans[i]];
  }
  z = 0;
  sort(ans2.begin(), ans2.end());
  long long int val = 0;
  j = 1;
  for (j = 1; j <= 1000; j++) {
    x = j * n;
    sum = 0;
    for (i = 0; i < ans2.size(); i++) {
      if (ans2[i] < j) continue;
      sum = sum + ans2[i];
      if (sum >= x) {
        val = j;
        break;
      }
    }
  }
  cout << val << endl;
}
