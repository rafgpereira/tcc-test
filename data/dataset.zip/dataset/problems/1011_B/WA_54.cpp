#pragma GCC optimize("Ofast")
#include <bits/stdc++.h>
using namespace std;
 
typedef long long ll;
typedef long double ld;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<vi> vvi;
typedef vector<vl> vvl;
typedef pair<int, int> pi;
typedef pair<ll, ll> pl;
typedef vector<pi> vpi;
typedef vector<pl> vpl;
 
#define re return
#define sz(a) (a).size()
#define PB push_back
#define MP make_pair
#define EB emplace_back
#define F first
#define S second
#define lb lower_bound
#define ub upper_bound
#define all(a) (a).begin(), (a).end()
#define rall(a) (a).rbegin(), (a).rend()
 
#define F0r(i, a, b) for(int i = a; i < b; ++i)
#define f0r(i, a) for(int i = 0; i < a; ++i)
#define F0rd(i, a, b) for(int i = a - 1; i > b; --i)
#define f0rd(i, a) for(int i = a - 1; i >= 0; --i)
#define trav(i, a) for(auto& i : (a))
void P(auto& x) {cout << x << endl;}
void PP(auto& a, auto& b) {cout << a << " " << b << endl;}
void PV(auto& v) {int n = sz(v); trav(i, v) cout << i << " ";cout << endl;}
void PPV(auto& v) {int n = sz(v); trav(i, v) cout << i.F << " " << i.S << endl;}
 
const ll INF = (1LL << 60);
const int MOD = 1e9 + 7;
const int nax = 2e5 + 5;
const double p = 3.14159265359;
 
int main(){
   ios_base::sync_with_stdio(false);
   cin.tie(nullptr);
   int n, k;
   cin >> n >> k;
   vi a(k), cnt(101, 0);
   f0r(i, k) {
      cin >> a[i];
      cnt[a[i]]++;
   }
   if(n > k) cout << 1 << '\n';
   else{
      int ans = 0;
      F0r(i, 1, 101){
         int c = n;
         F0r(j, 1, 101){
            c = max(0, c - (cnt[j] / i));
            if(!c){
               ans = max(ans, i);
               break;
            }
         }
      }
      P(ans);
   }
   return 0;
}