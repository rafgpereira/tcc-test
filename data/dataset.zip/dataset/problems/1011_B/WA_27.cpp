#include <bits/stdc++.h>
using namespace std;
long long n, m, a[1100], x, maxn = -0x3fffff;
long long ans;
int main() {
  scanf("%d%d", &n, &m);
  if (n > m) {
    printf("0");
    return 0;
  }
  if (n == m) {
    printf("1");
    return 0;
  }
  for (int i = 1; i <= m; i++) scanf("%d", &x), maxn = max(maxn, x), a[x]++;
  for (register int i = 1; i <= 100; i++) {
    int sum = 0;
    for (register int j = 1; j <= maxn; j++) sum += (a[j] / i);
    if (sum >= n)
      ans = i;
    else {
      printf("%d", ans);
      return 0;
    }
  }
  return 0;
}
