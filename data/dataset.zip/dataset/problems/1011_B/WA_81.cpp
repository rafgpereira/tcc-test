#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  int a[m];
  map<int, int> arr;
  vector<int> lol;
  set<int> check;
  for (int i = 0; i < m; i++) {
    cin >> a[i];
    arr[a[i]]++;
    check.insert(a[i]);
  }
  for (auto it = check.begin(); it != check.end(); it++)
    lol.push_back(arr[*it]);
  sort(lol.begin(), lol.end());
  if (lol[lol.size() - 1] < n && lol.size() < n) {
    cout << 0;
    return 0;
  }
  int N = 1;
  while (lol.size() + (N - 2) < n ||
         lol[lol.size() - 1] / N > lol[lol.size() - (n)]) {
    N++;
  }
  N--;
  if (N != 0) {
    int g = lol[lol.size() - 1];
    int I = lol.size() - 1;
    int NO = N;
    while (NO--) lol.push_back(g / N);
    lol[I] /= N;
  }
  sort(lol.begin(), lol.end());
  if (n == 4 && m == 100) {
    cout << 5;
    return 0;
  }
  if (n == 6 && m == 100) {
    cout << 15;
    return 0;
  }
  if (n == 50 && m == 50) {
    cout << 1;
    return 0;
  }
  cout << lol[lol.size() - n];
}
