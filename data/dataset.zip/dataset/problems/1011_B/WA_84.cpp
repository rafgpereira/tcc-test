#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  map<int, int> mp;
  int a[m];
  for (int i = 0; i < m; i++) {
    cin >> a[i];
    mp[a[i]]++;
  }
  int l = 1, r = 3;
  while (l <= r) {
    int mid = l + (r - l) / 2, c = 0;
    for (auto i = mp.begin(); i != mp.end(); i++) {
      c = c + ((i->second) / mid);
    }
    if (c >= n) {
      l = mid + 1;
    } else {
      r = mid - 1;
    }
  }
  cout << r;
  return 0;
}
