#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, k;
  cin >> n >> k;
  int a[k];
  int b[110];
  for (int i = 0; i < 110; i++) b[i] = 0;
  for (int i = 0; i < k; i++) {
    cin >> a[i];
    b[a[i]]++;
  }
  sort(b, b + 110);
  int ans = 0;
  for (int i = 109; i >= 0 && b[i] != 0; i--) {
    int temp = 0;
    int sum = 0;
    for (int j = 109; j >= i; j--) {
      temp += b[j] / min(n, b[i]);
      sum += b[j];
    }
    if (temp >= n) {
      ans = sum / n;
      break;
    }
  }
  cout << ans;
  return 0;
}
