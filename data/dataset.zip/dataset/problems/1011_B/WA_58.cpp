#include <bits/stdc++.h>
namespace {
using P = std::pair<int32_t, int32_t>;
bool good(int32_t n, int32_t mid, std::vector<P> &x) {
  for (const auto &p : x) {
    n -= p.second / mid;
    if (n <= 0) {
      return true;
    }
  }
  return n <= 0;
}
void solve() {
  int32_t n, m;
  std::cin >> n >> m;
  std::unordered_map<int32_t, int32_t> fp;
  for (int32_t i = 0, x = 0; i < m; i++) {
    std::cin >> x;
    fp[x]++;
  }
  std::vector<P> x(fp.begin(), fp.end());
  std::sort(x.begin(), x.end(),
            [](const P &lhs, const P &rhs) { return lhs.second > rhs.second; });
  int32_t l = 0, r = m, ans = 0;
  while (l < r) {
    auto mid = (l >> 1) + (r >> 1);
    if (!mid) {
      break;
    }
    if (good(n, mid, x)) {
      ans = mid;
      l = mid + 1;
    } else {
      r = mid;
    }
  }
  std::cout << ans << std::endl;
}
}  // namespace
int32_t main(void) {
  std::ios_base::sync_with_stdio(0);
  std::cin.tie(0);
  std::cout.tie(0);
  solve();
}
