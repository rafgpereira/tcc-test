#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  int a[n], b[105] = {0};
  for (int i = 0; i < m; i++) {
    cin >> a[i];
    b[a[i]]++;
  }
  vector<int> v;
  for (int i = 0; i < 105; i++) {
    if (b[i] > 0) v.push_back(b[i]);
  }
  int l = v.size();
  for (int i = 105; i > 0; i--) {
    int x = i, sum = 0;
    for (int j = 0; j < l; j++) {
      sum += v[j] / i;
    }
    if (sum >= n) return cout << i, 0;
  }
  cout << "0";
}
