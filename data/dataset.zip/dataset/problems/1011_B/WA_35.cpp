#include <bits/stdc++.h>
using namespace std;
int sorte(int m, int p[10]);
int main() {
  ios_base::sync_with_stdio(0);
  int n, m;
  cin >> n >> m;
  int k[m];
  int c = m / n;
  int d[m];
  for (int i = 0; i < m; i++) {
    cin >> d[i];
  }
  for (int i = 0; i < m; i++) {
    for (int j = i; j < m; j++) {
      if (d[i] > d[j]) {
        int k = d[i];
        d[i] = d[j];
        d[j] = k;
      }
    }
  }
  int p = 0;
  for (int i = 0; i < m; i++) {
    k[p] = 0;
    for (int j = i; j < m; j++) {
      if (d[i] == d[j]) {
        k[p]++;
        if (j == m - 1) i = m;
      } else {
        i = j - 1;
        j = m;
      }
    }
    p++;
  }
  int o = 0;
  int sum;
  for (int i = 0; i < c; i++) {
    sum = 0;
    o++;
    int dr[n];
    for (int j = 0; j < p; j++) {
      dr[j] = k[j] / o;
    }
    for (int i = 0; i < p; i++) {
      for (int j = i; j < p; j++) {
        if (dr[i] < dr[j]) {
          int k = dr[i];
          dr[i] = dr[j];
          dr[j] = k;
        }
      }
    }
    for (int i = 0; i < n; i++) {
      sum += dr[i];
    }
    if (sum == n) {
      i = c;
    }
    if (sum < n) {
      i = c;
      o -= 1;
    }
  }
  cout << o << endl;
  return 0;
}
