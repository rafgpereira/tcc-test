#include <bits/stdc++.h>
using namespace std;
long long int arr[110];
map<long long int, long long int> mp;
int main() {
  long long int n, m;
  cin >> n >> m;
  long long int sum = 0;
  for (int j = 0; j < m; j++) {
    cin >> arr[j];
    mp[arr[j]]++;
  }
  map<long long int, long long int>::iterator it = mp.begin();
  for (; it != mp.end(); it++) {
    sum += it->second;
  }
  long long int i = sum / n + 1;
  bool flag = false;
  long long int ans = -1;
  long long int sum2 = 0;
  for (; i >= 1 && !flag; i--) {
    it = mp.begin();
    for (; it != mp.end(); it++) {
      sum2 += (it->second / i);
      if (sum2 == n) {
        ans = i;
        cout << ans;
        flag = true;
        break;
      }
    }
    sum2 = 0;
  }
  if (!flag) {
    cout << 0;
  }
  return 0;
}
