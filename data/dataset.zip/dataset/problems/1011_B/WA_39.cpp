#include <bits/stdc++.h>
using namespace std;
int binarysearch(vector<int> v, int n, map<int, int> mp) {
  int l = 1, r = INT_MAX, mid, sum = 0;
  while (l <= r) {
    sum = 0;
    mid = l - (l - r) / 2;
    for (int i = 0; i < v.size(); i++) {
      sum += mp[v[i]] / mid;
    }
    if (sum < n) {
      r = mid - 1;
    } else {
      return mid;
    }
  }
}
int main() {
  int n, m;
  cin >> n >> m;
  map<int, int> mp;
  vector<int> v;
  int arr[m];
  for (int i = 0; i < m; i++) {
    cin >> arr[i];
    if (!mp[arr[i]]) {
      v.push_back(arr[i]);
    }
    mp[arr[i]]++;
  }
  cout << binarysearch(v, n, mp);
}
