#include <bits/stdc++.h>
using namespace std;
int a[102];
int main() {
  int n, m;
  cin >> n >> m;
  int dzuske;
  for (int i = 0; i < m; i++) {
    cin >> dzuske;
    a[dzuske]++;
  }
  sort(a, a + 102);
  reverse(a, a + 102);
  int ans = 0;
  for (int i = 0; i < n; i++) ans += a[i];
  cout << ans / n;
}
