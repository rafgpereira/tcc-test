#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  int d[101];
  memset(d, 0, sizeof(d));
  for (int i = 1; i <= m; i++) {
    int x;
    cin >> x;
    d[x]++;
  }
  int l = 0, r = 100;
  int res;
  while (l < r - 1) {
    int mid = (l + r) >> 1;
    int cnt = 0;
    for (int i = 1; i <= 100; i++)
      if (d[i] >= mid) {
        cnt += (d[i] / mid);
      }
    if (cnt >= n)
      l = mid;
    else
      r = mid;
    res = l;
  }
  cout << res;
  return 0;
}
