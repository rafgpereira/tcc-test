#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  int arr[100];
  for (int i = 0; i < 100; i++) {
    arr[i] = 0;
  }
  for (int i = 0; i < m; i++) {
    int x;
    cin >> x;
    arr[x - 1]++;
  }
  sort(arr, arr + 100);
  reverse(arr, arr + 100);
  int i = 0;
  int sum = arr[i];
  int currVal = sum / n;
  while (currVal < arr[i] && arr[i] != 0 && i < 99) {
    i++;
    sum += arr[i];
    currVal = sum / n;
  }
  cout << currVal;
  return 0;
}
