#include <bits/stdc++.h>
using namespace std;
map<int, int> mp;
int a[1005];
int main() {
  int n, m;
  cin >> n >> m;
  int cnt = 0;
  for (int i = 1; i <= m; i++) {
    int t;
    cin >> t;
    mp[t]++;
  }
  int ans = 0;
  for (int i = 1; i <= n; i++) {
    int tmp = n, j;
    for (j = 1; j <= 100; j++) {
      tmp -= mp[j] / i;
    }
    if (tmp > 0) break;
    if (ans < i) ans = i;
  }
  cout << ans << endl;
  return 0;
}
