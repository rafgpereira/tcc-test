#include <bits/stdc++.h>
using namespace std;
int b[200];
int main() {
  int n, m, x;
  cin >> n >> m;
  set<int> _set;
  memset(b, 0, sizeof(b));
  for (int i = 0; i < m; i++) {
    cin >> x;
    _set.insert(x);
    b[x]++;
  }
  set<int>::iterator it;
  for (int i = 1; i <= 100; i++) {
    int x = 0;
    for (it = _set.begin(); it != _set.end(); it++) x += b[*it] / i;
    if (x < n) {
      cout << i - 1 << "\n";
      break;
    }
  }
  return 0;
}
