#include <bits/stdc++.h>
using namespace std;
void me(int arr[], int l, int m, int r) {
  int i, j, k;
  int x = m - l + 1;
  int y = r - m;
  int L[x], R[y];
  for (i = 0; i < x; i++) L[i] = arr[l + i];
  for (j = 0; j < y; j++) R[j] = arr[m + 1 + j];
  i = 0;
  j = 0;
  k = l;
  while (i < x && j < y) {
    if (L[i] <= R[j]) {
      arr[k] = L[i];
      i++;
    } else {
      arr[k] = R[j];
      j++;
    }
    k++;
  }
  while (i < x) {
    arr[k] = L[i];
    i++;
    k++;
  }
  while (j < y) {
    arr[k] = R[j];
    j++;
    k++;
  }
}
void ms(int arr[], int l, int r) {
  if (l < r) {
    int m = l + (r - l) / 2;
    ms(arr, l, m);
    ms(arr, m + 1, r);
    me(arr, l, m, r);
  }
}
int main() {
  int n, m, i, cs = 1, temp, k = 0, sum, j;
  cin >> n >> m;
  int arr[m], brr[m];
  for (i = 0; i < m; i++) cin >> arr[i];
  ms(arr, 0, m - 1);
  temp = arr[0];
  for (i = 1; i < m; i++) {
    if (arr[i] == temp)
      cs++;
    else {
      brr[k++] = cs;
      cs = 1;
      temp = arr[i];
    }
  }
  if (i == m && arr[m - 1] == arr[m - 2])
    brr[k++] = cs + 1;
  else if (i == m && arr[m - 1] != arr[m - 2])
    brr[k++] = 1;
  ms(brr, 0, k - 1);
  for (i = 1; i <= brr[k - 1]; i++) {
    sum = 0;
    for (j = 0; j < k; j++) sum += (brr[j] / i);
    if (sum < n) break;
  }
  cout << (i - 1) << '\n';
  return 0;
}
