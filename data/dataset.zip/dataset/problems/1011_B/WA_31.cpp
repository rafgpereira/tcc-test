#include <bits/stdc++.h>
using namespace std;
const int inf = 0x3f3f3f3f;
const int maxn = 1005;
inline void read(int &x) {
  int f = 1;
  x = 0;
  char s = getchar();
  while (s < '0' || s > '9') {
    if (s == '-') f = -1;
    s = getchar();
  }
  while (s >= '0' && s <= '9') {
    x = x * 10 + s - '0';
    s = getchar();
  }
  x *= f;
}
inline void print(int x) {
  if (x < 0) {
    putchar('-');
    x = -x;
  }
  if (x > 9) print(x / 10);
  putchar(x % 10 + '0');
}
int n, m, ans, tot;
int vis[maxn], a[maxn];
int main() {
  cin >> n >> m;
  for (int i = 0; i < m; i++) {
    read(a[i]);
    vis[a[i]]++;
  }
  sort(vis, vis + 105, greater<int>());
  for (int i = n; i > 0; i--) {
    tot = 0;
    for (int j = 0; j < n; j++) {
      if (vis[j] >= i && tot <= n) {
        tot += vis[j] / i;
        ans = i;
      }
    }
    if (tot == n) break;
  }
  if (tot < n) ans = 0;
  cout << ans << endl;
  return 0;
}
