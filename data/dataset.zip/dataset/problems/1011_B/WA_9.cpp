//...jai shree ram...//
#include<bits/stdc++.h>
using namespace std;
#define ll long long 
#define ld long double
#define endl "\n"
#define Endl "\n"
#define INF 10000000000000009
#define M 1000000007
#define p1 1000003
#define pb emplace_back
#define ff first
#define ss second
#define forn(i,n) for(ll i=0;i<n;i++)
#define form(i,n) for(ll i=1;i<=n;i++)
#define rfor(i,n) for(ll i=n-1;i>=0;i--)
#define lcm(a,b) (a*b)/(ll)(__gcd(a,b))
#define ssort(s) sort(s.begin(),s.end())
#define rsort(s) sort(s.begin(),s.end(),greater<>())
#define rev(s) reverse(s.begin(),s.end())
#define precise(ans) cout<<fixed<<setprecision(15)<<ans<<endl
#define lbound(v,a) lower_bound(v.begin(), v.end(),a)-v.begin()
void print(vector<ll> ar) {forn(i,ar.size()) cout<<ar[i]<<" ";cout<<endl;}
void rprint(vector<ll> ar) {rfor(i,ar.size()) cout<<ar[i]<<" ";cout<<endl;}
/************^^^^^^^^^^^^^^*************^^^^^^^^^^^^^***********^^^^^^^^^^^^^*********/
int main()
{ios_base::sync_with_stdio(false);
 cin.tie(NULL); cout.tie(NULL); 
 ll t=1;//cin>>t;
 while(t--)
   {
    ll n,m;
    cin>>n>>m;
    ll ar[m];
    map<ll,ll> mm;
    ll summ=0;
    forn(i,m) {cin>>ar[i]; mm[ar[i]]++;summ+=ar[i];}
    vector<ll> v1,v;
    for(auto it=mm.begin();it!=mm.end();it++)
       {
        
        v1.pb(it->second);
       }
    rsort(v1);
    forn(i,v1.size())
      {if(v.size()<n)
         v.pb(v1[i]);
      }
    while(v.size()!=n)
       v.pb(0);
   
   // forn(i,v.size()) cout<<v[i]<<" ";
   //   cout<<endl;

   if(summ>=n)
     {ll val=200;
      while(val--)
            { 
              ll i=0,j=n-1;
              ll cal=0,count=0;
              while(j>=0&&cal+v[j]<=v[0])
                 {cal+=v[j];j--;count++;}
            if(count!=0)
             {   ll a=v[0]/count;
                  vector<ll> temp;
                  forn(i,count-1)
                    temp.pb(a);
                  if(count!=0)
                  {if(v[0]%count!=0)
                     temp.pb(a+v[0]%count);
                   else
                     temp.pb(a);}
                for(ll i=1;i+count<=n;i++)
                   temp.pb(v[i]);
                  v.clear();
                  v=temp;
             rsort(v);
           // forn(i,v.size()) cout<<v[i]<<" ";
           // cout<<endl;  
             }
            else
               {break;}
            }
     // forn(i,v.size()) cout<<v[i]<<" ";
     // cout<<endl;
     cout<<v[v.size()-1]<<endl;
     }
   else
     cout<<0<<endl;
   }
}                
               
                   
                    

                 
              