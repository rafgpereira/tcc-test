#include <bits/stdc++.h>
using namespace std;
const int N = 105;
vector<int> arr;
int n, m, sz, a, cnt[N], b[N];
bool chk(int x) {
  for (int i = 0; i < sz; i++) b[i] = arr[i];
  int k, ans = 0, lowbound = n;
  for (int i = 0; i < min(sz, n); i++) {
    k = b[i] / x;
    ans += k;
    if (ans >= n) return true;
  }
  return false;
}
int main() {
  cin >> n >> m;
  int mx = m / n;
  for (int i = 0; i < m; i++) {
    cin >> a;
    cnt[a]++;
  }
  for (int i = 0; i < N; i++) {
    if (cnt[a] > 0) {
      arr.push_back(cnt[a]);
    }
  }
  sort(arr.begin(), arr.end(), greater<int>());
  sz = arr.size();
  int lo = 0, hi = mx;
  while (lo < hi) {
    int mid = (hi + lo + 1) / 2;
    if (chk(mid))
      lo = mid;
    else
      hi = mid - 1;
  }
  cout << lo << endl;
  return 0;
}
