#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/tree_policy.hpp>
#include<bits/stdc++.h>
#include<tr1/unordered_map>
#define ll long long
#define mod 1000000007
#define pb push_back
#define mp make_pair
#define vl vector<ll>
#define pl pair<ll,ll>
#define rep(i,xi,yi,zi) for(ll i=xi;i<yi;i+=zi)
#define repe(i,xi,yi,zi) for(ll i=xi;i<=yi;i+=zi)
#define rrep(i,xi,yi,zi) for(ll i=xi;i>=yi;i-=zi)
#define pq priority_queue<ll>
#define rpq priority_queue<ll, vl, greater<ll> >
#define umap tr1::unordered_map
#define fastIO ios_base::sync_with_stdio(false);cin.tie(NULL);
using namespace std;
using namespace __gnu_pbds; 
typedef tree<ll, null_type, less<ll>, rb_tree_tag, tree_order_statistics_node_update> pset; 
ll cnt[102],freq[102];
 
int main()
{
	fastIO
	ll n,m;
	cin>>n>>m;
	ll a[m];
	rep(i,0,m,1)
	{
		cin>>a[i];
		cnt[a[i]]+=1;
	}
	ll mx=0,ans;
	rep(i,1,101,1)
	{
		repe(j,1,cnt[i],1)
		{
			freq[j]+=(cnt[i]/j);
		}
	}
	rep(i,1,101,1)
	{
		if(freq[i]>=n)
		{
			ans=i;
		}
	}
	cout<<ans;
	return 0;
}