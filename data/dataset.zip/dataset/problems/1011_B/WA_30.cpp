#include <bits/stdc++.h>
using namespace std;
void ans() {
  int l, num, i, a = 0;
  cin >> l >> num;
  int A[200] = {0}, k = 1, c = 0, flag = 0, sum = 0;
  for (i = 0; i < num; i++) {
    int x;
    cin >> x;
    A[x]++;
  }
  vector<int> v;
  vector<int> v1;
  for (i = 0; i < 150; i++) {
    if (A[i] != 0) {
      v1.push_back(A[i]);
      sum += A[i];
    }
  }
  if (sum < l) {
    cout << 0;
    exit(0);
  }
  sort(v1.begin(), v1.end(), greater<int>());
  for (i = 0; i < l; i++) {
    v.push_back(v1[i]);
  }
  if (v.size() == 1) {
    cout << v[0] / l;
    exit(0);
  }
  for (i = 1;; i++) {
    for (int j = 0; j < v.size(); j++) {
      if (v[j] < i) {
        c++;
      }
    }
    if (c != 0) {
      for (int j = 0; j < v.size(); j++) {
        if (v[j] >= i * (c + 1)) {
          c = 0;
          break;
        } else {
          flag = 1;
        }
      }
    }
    k++;
    if (flag == 1) {
      break;
    }
  }
  cout << i - 1;
}
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  ans();
}
