#include <bits/stdc++.h>
using namespace std;
int n, m;
int cnt[110];
bool judge(int d) {
  if (d == 0) return false;
  int ct = 0;
  for (int i = 1; i <= 100; i++) {
    int x = d;
    while (cnt[i] >= x) {
      ct++;
      x += d;
    }
    if (ct >= n) break;
  }
  if (ct >= n) return true;
  return false;
}
int main() {
  scanf("%d%d", &n, &m);
  int x;
  for (int i = 1; i <= m; i++) {
    scanf("%d", &x);
    cnt[x]++;
  }
  int l = 0, r = 100;
  int ans = 0;
  while (l <= r) {
    int mid = (l + r) >> 1;
    if (judge(mid))
      l = mid + 1, ans = mid;
    else
      r = mid - 1;
  }
  printf("%d", ans);
  return 0;
}
