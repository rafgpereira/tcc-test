#include <bits/stdc++.h>
using namespace std;
int br[105];
int main() {
  int n, m;
  cin >> n >> m;
  int ar[105];
  int mn = 105;
  set<int> s;
  int mm = 0;
  int kk = m / n;
  int kr = n * kk;
  for (int i = 1; i <= m; i++) {
    cin >> ar[i];
    br[ar[i]]++;
    s.insert(ar[i]);
    if (br[ar[i]] >= 0) mm = max(mm, br[ar[i]]);
  }
  if (n > m)
    cout << '0' << endl;
  else if (mm >= kr)
    cout << mm / n << endl;
  else {
    vector<int> v;
    for (auto it : s) {
      v.push_back(br[it]);
    }
    sort(v.rbegin(), v.rend());
    if (n == m)
      cout << "1" << endl;
    else if (s.size() < n) {
      int pi = n - s.size();
      cout << v[pi - 1] / pi << endl;
    } else {
      int po = v[n - 1];
      int sum = 0;
      int ft = 0;
      for (auto it : v) {
        sum += it;
        if (sum >= kr) {
          ft = it;
          break;
        }
      }
      cout << max(ft, po) << endl;
    }
  }
}
