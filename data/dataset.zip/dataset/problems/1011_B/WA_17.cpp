#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5, mod = 1e9 + 7;
int n, m, x[105], f[101], a, ans;
bool ok(int s) {
  int q = 0;
  for (int i = 1; i <= 100; i++) {
    q += f[i] / s;
  }
  return q >= n;
}
int bs() {
  int l = 0, h = 20, mid;
  while (l < h) {
    mid = (l + h + 1) / 2;
    if (ok(mid))
      l = mid;
    else
      h = mid - 1;
  }
  return l;
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  ;
  cin >> n >> m;
  for (int i = 0; i < m; i++) {
    cin >> a;
    f[a]++;
  }
  ans = bs();
  if (ans <= 1) {
    if (m >= n)
      cout << 1;
    else
      cout << 0;
  } else
    cout << ans;
}
