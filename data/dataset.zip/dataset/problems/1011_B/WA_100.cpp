#include <bits/stdc++.h>
using namespace std;
int col[1000];
int main() {
  int n, m;
  cin >> n >> m;
  int a[m + 100];
  set<int> s;
  set<int>::iterator it;
  for (int i = 0; i < m; i++) {
    cin >> a[i];
    col[a[i]]++;
    s.insert(a[i]);
  }
  int c = 0;
  if (n > m) {
    cout << c << endl;
    return 0;
  }
  int v = n, f = 0;
  int x = -1;
  sort(a, a + m);
  while (n) {
    for (it = s.begin(); it != s.end(); ++it) {
      c += col[*it] / n;
    }
    x = max(c, x);
    if (x == v) {
      f = 1;
      cout << n << endl;
      return 0;
    }
    c = 0;
    n--;
  }
  if (f == 0) cout << 1 << endl;
}
