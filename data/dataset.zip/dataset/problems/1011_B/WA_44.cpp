#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  long long int n, m;
  cin >> n >> m;
  long long int a[m], f[101] = {0};
  vector<long long int> v;
  for (long long int i = 0; i < m; ++i) {
    cin >> a[i];
    f[a[i]]++;
  }
  for (long long int i = 0; i < 101; ++i)
    if (f[i]) v.push_back(f[i]);
  for (long long int i = m / n; i >= 0; --i) {
    long long int k = i * n, s = 0;
    for (auto j : v) {
      if (j < i) break;
      if (i == 0) {
        cout << i << endl;
        return 0;
      }
      long long int p = j / i;
      s += p;
      if (s == n) {
        cout << i << endl;
        return 0;
      }
    }
  }
  return 0;
}
