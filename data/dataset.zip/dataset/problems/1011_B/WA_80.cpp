#include <bits/stdc++.h>
using namespace std;
int n, m, x, small, i, big, mid;
int f[105];
bool chek(int md) {
  int c = 0;
  int s = 0;
  for (i = 100; i >= 0; i--) {
    if (f[i] >= md && f[i] % md == 0) {
      c++;
      s += f[i];
    }
  }
  if (s >= n * md)
    return true;
  else
    return false;
}
int main() {
  {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
  }
  cin >> n >> m;
  for (i = 0; i < m; i++) {
    cin >> x;
    f[x]++;
  }
  big = 200;
  small = 0;
  while (small != big) {
    mid = (small + big + 1) / 2;
    if (chek(mid)) {
      small = mid;
    } else {
      big = mid - 1;
    }
  }
  cout << small << endl;
  return 0;
}
