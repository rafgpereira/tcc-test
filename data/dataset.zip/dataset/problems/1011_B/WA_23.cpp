#include <bits/stdc++.h>
using namespace std;
int g[105];
int main() {
  int x, y, i, j, k, l = -1, q[105], p, r = 0, o = 0;
  cin >> x >> y;
  for (i = 1; i <= y; i++) {
    cin >> k;
    g[k]++;
  }
  for (i = 1; i <= 100; i++) {
    if (g[i] > 0) q[++l] = g[i];
  }
  sort(q, q + l + 1);
  if (x > y)
    cout << "0" << endl;
  else {
    for (p = l; p >= 0; p--) {
      r = r + q[p] / x;
    }
    for (p = l; p >= 0; p--) {
      o = 0;
      for (j = l; j >= p; j--) {
        o = o + q[j] / q[p];
      }
      if (o >= x) break;
    }
    int h;
    if (p == -1)
      h = 0;
    else
      h = q[p];
    r = max(r, h);
    cout << r << endl;
  }
  return 0;
}
