#include <bits/stdc++.h>
using namespace std;
const int MOD = 1e9 + 7;
const double EPS = 1e-9;
int main() {
  ios_base::sync_with_stdio(false);
  cout.precision(10);
  int n, m, max_days;
  cin >> n >> m;
  max_days = m / n;
  map<int, int> mp;
  vector<pair<int, int> > t;
  for (int i = 1; i <= m; i++) {
    int f;
    cin >> f;
    if (mp.count(f))
      mp[f]++;
    else
      mp[f] = 1;
  }
  vector<vector<int> > p(n);
  for (auto a : mp) t.push_back({a.second, a.first});
  sort(t.begin(), t.end(), greater<pair<int, int> >());
  int f = 0;
  for (int i = 0; i < n; i++) {
    while ((int)p[i].size() < max_days && t[f].first) {
      if (p[i].empty() || t[f].second == p[i].back()) {
        p[i].push_back(t[f].second);
        t[f].first--;
      } else
        break;
    }
    sort(t.begin(), t.end(), greater<pair<int, int> >());
  }
  int ans = MOD;
  for (int i = 0; i < n; i++) {
    ans = min(ans, (int)p[i].size());
  }
  cout << ans << endl;
  return 0;
}
