#include <bits/stdc++.h>
using namespace std;
int a[123];
int cnt[123];
int main() {
  int n, m;
  cin >> n >> m;
  for (int i = 1; i <= m; i++) {
    cin >> a[i];
    cnt[a[i]]++;
  }
  vector<int> vv;
  for (int i = 1; i <= 100; i++) {
    if (cnt[i]) vv.push_back(cnt[i]);
  }
  sort(vv.begin(), vv.end());
  int suma, maxe;
  for (int i = 1; i <= 100; i++) {
    suma = 0;
    for (int j = 0; j < vv.size(); j++) {
      suma += (vv[j] / i);
      if (suma >= n) {
        maxe = max(maxe, i);
      }
    }
  }
  cout << maxe;
}
