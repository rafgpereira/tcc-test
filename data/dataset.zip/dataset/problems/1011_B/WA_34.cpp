#include <bits/stdc++.h>
using namespace std;
const int N = 5e5 + 5;
const int mod = 1 << 30;
int n, k;
int arr[101] = {};
vector<int> ans;
int main() {
  scanf("%d", &n), scanf("%d", &k);
  for (int i = 0; i < (int)(k); ++i) {
    int a;
    scanf("%d", &a);
    arr[a]++;
  }
  for (int i = 0; i < 101; i++)
    if (arr[i]) ans.push_back(arr[i]);
  sort(ans.rbegin(), ans.rend());
  if (ans.size() == 1) {
    cout << ans[0] / n;
    return 0;
  }
  int j = 0, l = 1, mx = ans[0];
  n--;
  while (n > 0 && l < ans.size()) {
    if (ans[j] >= ans[l] * 2) {
      ans[j] >>= 1;
      mx = min(ans[j], mx);
      if (ans[j] < ans[j + 1]) j++;
      n -= 1;
      continue;
    }
    mx = min(ans[l], mx);
    l++;
    n -= 1;
  }
  if (n != 0) {
    puts("0");
  } else
    cout << mx;
  return 0;
}
