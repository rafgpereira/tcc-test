#include <bits/stdc++.h>
using namespace std;
bool f(int i, int j) { return i > j; }
int main() {
  int n, m, x, nr = 0;
  vector<int> v(101, 0);
  cin >> n >> m;
  for (int i = 0; i < m; i++) {
    cin >> x;
    v[x]++;
    if (v[x] == 1) nr++;
  }
  sort(v.begin(), v.end(), f);
  int s = v[0];
  for (int i = 1; i < min(n, nr); i++) s += v[i];
  cout << s / n;
  return 0;
}
