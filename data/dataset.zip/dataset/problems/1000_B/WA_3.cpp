#include <bits/stdc++.h>
using namespace std;
const int N = 100005;
int n, m, a[N], s1[N], s2[N];
int main() {
  int i, re = 0;
  scanf("%d%d", &n, &m);
  for (i = 1; i <= n; i++) scanf("%d", &a[i]);
  a[0] = 0;
  a[n + 1] = m;
  if (n & 1) {
    s1[1] = a[1] - a[0];
    for (i = 3; i <= n; i += 2) {
      s1[i] = s1[i - 2] + a[i] - a[i - 1];
    }
    s1[n + 2] = s1[n];
    re = max(re, s1[n]);
    s2[0] = 0;
    for (i = 2; i <= n + 1; i += 2) {
      s2[i] = s2[i - 2] + a[i] - a[i - 1];
    }
    s2[n + 3] = s2[n + 1];
    for (i = 0; i <= n; i++) {
      if (a[i + 1] - a[i] <= 1) continue;
      if (i & 1)
        re = max(re, s1[i] + a[i + 1] - a[i] - 1 + s2[i + 3] - s2[i + 1]);
      else
        re = max(re, s1[i - 1] + a[i + 1] - a[i] - 1 + s2[i + 2] - s2[i]);
    }
  } else {
    s1[1] = a[1] - a[0];
    for (i = 3; i <= n + 1; i += 2) {
      s1[i] = s1[i - 2] + a[i] - a[i - 1];
    }
    s1[n + 3] = s1[n + 1];
    re = max(re, s1[n + 1]);
    s2[0] = 0;
    for (i = 2; i <= n; i += 2) {
      s2[i] = s2[i - 2] + a[i] - a[i - 1];
    }
    s2[n + 2] = s2[n];
    for (i = 0; i <= n; i++) {
      if (a[i + 1] - a[i] <= 1) continue;
      if (i & 1)
        re = max(re, s1[i] + a[i + 1] - a[i] - 1 + s2[i + 3] - s2[i + 1]);
      else
        re = max(re, s1[i - 1] + a[i + 1] - a[i] - 1 + s2[i + 2] - s2[i]);
    }
  }
  printf("%d\n", re);
}
