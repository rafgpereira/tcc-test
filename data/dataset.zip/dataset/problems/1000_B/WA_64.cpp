//ash
#include<bits/stdc++.h>
#define ll             long long
#define pb             push_back
#define mp             make_pair
#define pii            pair<int,int>
#define pll            pair<long,long>
#define vi             vector<int>
//vector< vector<int> > Matrix(N, vector<int>(M, -1)); N*M
#define all(a)         (a).begin(),(a).end()
#define F              first
#define S              second
#define sz(x)          (int)x.size()
#define hell           1000000007
#define loop(i,a,b)	   for(long long i=a;i<b;i++)
#define dec(i,a,b)     for(long long i=a;i>=b;i--)
#define PI 			   3.141592653589793l
#define vl             vector<long>
#define inf            5000000000000000000          
//18 0's
#define tr(c,i)        for(typeof((c).begin() i = (c).begin(); i != (c).end(); i++) 
#define present(c,x)   ((c).find(x) != (c).end()) 
#define cpresent(c,x)  (find(all(c),x) != (c).end()) 
#define fill(a,b)     memset(a,b,sizeof(a))
#define sp(x)   fixed<<setprecision(x)
using namespace std;
long long min(long long a,long long b){
	if(a<b)
	 return a;
	 else
	 return b;
}
long long lcm(long long a, long long b)
{
    long long temp = __gcd(a, b);
 
    return temp ? (a / temp * b) : 0;
}
/*long long bin(int n, int k)
{
    long long res = 1;
 
    // Since C(n, k) = C(n, n-k)
    if ( k > n - k )
        k = n - k;
 
    // Calculate value of [n * (n-1) *---* (n-k+1)] / [k * (k-1) *----* 1]
    for (int i = 0; i < k; ++i)
    {
        res *= (n - i);
        res /= (i + 1);
    }
    return res;
}
typedef unsigned long long uint64;
 
uint64 PowMod(uint64 x, uint64 e, uint64 mod)
{
  uint64 res;
 
  if (e == 0)
  {
    res = 1;
  }
  else if (e == 1)
  {
    res = x;
  }
  else
  {
    res = PowMod(x, e / 2, mod);
    res = res * res % mod;
    if (e % 2)
      res = res * x % mod;
  }
 
  return res;
}*/
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    //freopen("C-small-1-attempt0 (1).txt","r",stdin);
    //freopen("cheating.txt","w",stdout);    
    ll n,m;
    cin>>n>>m;
    cout<<n<<" "<<m<<endl;
    std::vector<ll> v(n+2);
    v[0]=0;v[n+1]=m;
    loop(i,1,n+1){
      cin>>v[i];
    }  
    std::vector<ll> store;
    for(int i=2;i<n+2;i+=2){
      store.pb(v[i]-v[i-1]);
    }
    ll sum[store.size()+1]={0};
    dec(i,store.size()-1,0){
      sum[i]=sum[i+1]+store[i];
      //cout<<i<<" "<<sum[i]<<endl;
    }
    ll ptr=0;
    ll till=0;
    ll res=-1;
    ll ans;
    for(int i=1;i<n+2;i++){
      if(v[i]>v[i-1]+1){
        if(i%2){
          ans=till+v[i]-v[i-1]-1+(ptr<store.size()+1?sum[ptr]:0);
    //      cout<<i<<" "<<ans<<endl;
          res=max(res,ans);
        }
        else {
          ans=till+(v[i]-v[i-1]-1)+(ptr<store.size()+1?sum[ptr]:0);
          //cout<<i<<" "<<till<<" "<<sum[ptr]<<" "<<ans<<endl;
          res=max(res,ans);
        }
      }
      if(i%2){
        ptr++;
        till+=v[i]-v[i-1];
      }
    }
    ans=0;
    for(int i=1;i<n+2;i+=2){
      ans+=v[i]-v[i-1];
    }
    res=max(res,ans);
    cout<<res<<endl;
    return 0;
}