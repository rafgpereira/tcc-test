#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
using pli = pair<ll, int>;
using vi = vector<int>;
using vl = vector<ll>;
using vpii = vector<pii>;
template <class T>
inline bool ckmin(T& a, const T& b) {
  return b < a ? a = b, 1 : 0;
}
template <class T>
inline bool ckmax(T& a, const T& b) {
  return b > a ? a = b, 1 : 0;
}
mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
const char nl = '\n';
const int mxN = 1e5 + 10;
const int MOD = 1e9 + 7;
const ll infLL = 1e18;
const ld eps = 1e-6;
int n;
ll m;
ll a[mxN];
ll p[mxN];
ll ans = 0;
int32_t main() {
  cin.tie(0)->sync_with_stdio(0);
  cin >> n >> m;
  for (int i = (1); i < (n + 1); i++) cin >> a[i];
  a[n + 1] = m;
  bool on = 1;
  for (int i = (1); i < (n + 2); i++) {
    if (on)
      p[i] = (i ? p[i - 1] : 0) + (a[i] - a[i - 1]);
    else
      p[i] = p[i - 1];
    on ^= 1;
  }
  ckmax(ans, p[n + 1]);
  ll pp = 0;
  on = 1;
  for (int i = (1); i < (n + 2); i++) {
    if (a[i] == a[i - 1] + 1) continue;
    ll res = p[n + 1] - p[i];
    res = m - a[i] - res;
    ckmax(ans, res + pp + (on ? a[i] - a[i - 1] - 1 : 0));
    if (on) pp += a[i] - a[i - 1];
    on ^= 1;
  }
  cout << ans << nl;
}
