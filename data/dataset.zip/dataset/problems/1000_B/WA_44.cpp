#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n, m;
  cin >> n >> m;
  int sm = 0;
  int tf = 0;
  int k = 0;
  int flag = 1;
  int a[n];
  for (int i = 0; i < n; i++) {
    cin >> a[i];
    if (flag) {
      sm = sm + a[i] - k;
      k = a[i];
      flag = 0;
    } else {
      tf = tf + a[i] - k;
      k = a[i];
      flag = 1;
    }
  }
  if (flag) {
    sm = sm + m - k;
  } else {
    tf = tf + m - k;
  }
  flag = 0;
  k = 0;
  int ps = 0;
  int rs = sm;
  int pf = 0;
  int rf = tf;
  int ans = sm;
  for (int i = 0; i < n; i++) {
    if (!flag) {
      ps = ps + a[i] - k;
      rs = sm - ps;
      if (ps + rf - 1 > sm) {
        if (i < n - 1) {
          if (a[i + 1] - a[i] > 1)
            sm = ps + rf - 1;
          else {
            if (a[i] - k > 1) sm = ps + rf - 1;
          }
        } else {
          if (m - a[i] > 1)
            sm = ps + rf - 1;
          else if (a[i] - k > 1)
            sm = ps + rf - 1;
        }
      }
      k = a[i];
      flag = 1;
    } else {
      rf = tf - a[i] + k;
      k = a[i];
      flag = 0;
    }
  }
  cout << sm << endl;
}
