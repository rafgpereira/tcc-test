#include <bits/stdc++.h>
using namespace std;
const int INF = 20050208;
int num[100005];
int ti[100005];
int sum;
int pre[100005];
int main() {
  int n, m;
  cin >> n >> m;
  for (int i = 0; i < n; i++) {
    cin >> num[i];
  }
  num[n] = m;
  n++;
  ti[0] = num[0];
  for (int i = 1; i < n; i++) {
    ti[i] = num[i] - num[i - 1];
  }
  bool on = true;
  int cnt = 0;
  for (int i = 0; i < n; i++) {
    if (i % 2 == 0) {
      pre[i] += ti[i];
    }
  }
  for (int i = 1; i < n; i++) {
    pre[i] += pre[i - 1];
  }
  for (int i = 0; i < n; i++) {
    if (i % 2 == 0) {
      sum += ti[i];
    }
  }
  int til = 0;
  int ans = sum;
  for (int i = 0; i < n; i++) {
    cnt += ti[i];
    int off = m - cnt - (sum - pre[i]);
    int on = sum - pre[i];
    if (i % 2 == 0) {
      til += ti[i];
      int tmp = til - 1 + off;
      ans = max(ans, tmp);
      tmp = til - 1 + off - 1;
      ans = max(ans, tmp);
    } else {
      int tmp = til + 1 + off;
      ans = max(ans, tmp);
      tmp = til + 1 + off;
      ans = max(ans, tmp);
    }
  }
  cout << ans;
  return 0;
}
