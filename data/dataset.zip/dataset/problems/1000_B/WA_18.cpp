#include <bits/stdc++.h>
using namespace std;
int a[100009];
int main() {
  int n, m;
  cin >> n >> m;
  a[0] = 0;
  for (int i = 1; i <= n; i++) cin >> a[i];
  a[n + 1] = m;
  int ans = 0;
  for (int i = 1; i <= n; i++) {
    if (a[i + 1] == 1 + a[i]) {
      ans += a[i] - a[i - 1];
      i++;
    } else {
      ans += a[i] - a[i - 1];
      a[i]++;
    }
  }
  cout << a[n + 1] - a[n] + ans << endl;
}
