#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  ;
  long long int a, b, c, d, e, m, flag, last = 0, ans = 0, maxx = 0;
  cin >> a;
  long long int A[a + 2];
  A[0] = 0;
  cin >> A[a + 1];
  for (b = 1; b <= a; b++) cin >> A[b];
  long long int paon[a + 1];
  for (b = a; b >= 0; b--) {
    if (b % 2 == 0) {
      paon[b] = last + A[b + 1] - A[b];
      last = last + A[b + 1] - A[b];
    } else {
      paon[b] = last;
    }
  }
  for (b = 0; b < a; b++) {
    if (b % 2 == 0) {
      ans = ans + A[b + 1] - A[b];
      maxx = max(ans + paon[b + 1], maxx);
    } else {
      maxx =
          max(ans + A[b + 1] - A[b] - 1 + (A[a + 1] - A[b + 1] - paon[b + 1]),
              maxx);
    }
  }
  cout << maxx << endl;
}
