#include <bits/stdc++.h>
using namespace std;
int n, m, s1, s2, c1, c2, ls, ans, sum;
int a[100005], b[100005];
int main() {
  cin >> n >> m;
  for (int i = 1; i <= n; i++) {
    int val, t;
    cin >> val;
    t = val - ls;
    if (i & 1)
      a[c1++] = t, s1 += t;
    else
      b[c2++] = t, s2 += t;
    ls = val;
  }
  if (n & 1)
    b[c2++] = m - ls, s2 += m - ls;
  else
    a[c1++] = m - ls, s1 += m - ls;
  ans = s1;
  sum = a[0];
  s1 -= a[0];
  for (int i = 0, j = 1; i < c2 && j < c1; i++, j++) {
    if (s2 > s1 + 1) ans = max(ans, sum + s2 - 1);
    sum += a[j];
    s1 -= a[j];
    s2 -= b[i];
  }
  cout << ans;
  return 0;
}
