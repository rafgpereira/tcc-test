#include <bits/stdc++.h>
using namespace std;
int main() {
  clock_t tStart = clock();
  long long n;
  scanf("%lld", &n);
  long long arr[n];
  long long M;
  scanf("%lld", &M);
  for (long long i = 0; i < n; i++) scanf("%lld", &arr[i]);
  long long presum_lit[n + 2];
  for (int i = 0; i < n + 1; i++) {
    if (i == 0)
      presum_lit[i] = arr[i] - 0;
    else {
      if (i == n) {
        if (i % 2 == 0)
          presum_lit[i] = presum_lit[i - 1] + (M - arr[i - 1]);
        else
          presum_lit[i] = presum_lit[i - 1];
      } else {
        if (i % 2 == 0)
          presum_lit[i] = presum_lit[i - 1] + (arr[i] - arr[i - 1]);
        else
          presum_lit[i] = presum_lit[i - 1];
      }
    }
  }
  long long presum_off[n + 2];
  for (int i = 0; i < n + 1; i++) {
    if (i == 0)
      presum_off[i] = 0;
    else {
      if (i == n) {
        if (i % 2 != 0)
          presum_off[i] = presum_off[i - 1] + (M - arr[i - 1]);
        else
          presum_off[i] = presum_off[i - 1];
      } else {
        if (i % 2 != 0)
          presum_off[i] = presum_off[i - 1] + (arr[i] - arr[i - 1]);
        else
          presum_off[i] = presum_off[i - 1];
      }
    }
  }
  long long maxi = -1;
  for (int i = 0; i < n - 1; i++) {
    if (i == 0) {
      maxi = max(maxi, presum_off[n] + arr[i] - 1);
    } else {
      if (i % 2 != 0) {
        long long t1 = presum_off[n] - presum_off[i + 1];
        long long t2 = presum_lit[i - 1];
        long long temp = arr[i + 1] - arr[i] - 1;
        temp += t1 + t2;
        maxi = max(maxi, temp);
      } else {
        long long t1 = presum_lit[n] - presum_lit[i + 1];
        long long t2 = presum_lit[i - 1];
        long long temp = arr[i + 1] - arr[i] - 1;
        temp += t1 + t2;
        maxi = max(maxi, temp);
      }
    }
  }
  maxi = max(maxi, max(presum_off[n], presum_lit[n]));
  cout << maxi << endl;
  return 0;
}
