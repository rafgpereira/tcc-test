/*
	Name: Harshit Jain
	Institution: IIIT Vadodara
*/
#ifndef _GLIBCXX_NO_ASSERT
#include <cassert>
#endif
#include <unordered_set>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <ciso646>
#include <climits>
#include <clocale>
#include <cmath>
#include <csetjmp>
#include <csignal>
#include <cstdarg>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

#if __cplusplus >= 201103L
#include <ccomplex>
#include <cfenv>
#include <cinttypes>
#include <cstdalign>
#include <cstdbool>
#include <cstdint>
#include <ctgmath>
#include <cwchar>
#include <cwctype>
#endif

// C++
#include <algorithm>
#include <bitset>
#include <complex>
#include <deque>
#include <exception>
#include <fstream>
#include <functional>
#include <iomanip>
#include <ios>
#include <iosfwd>
#include <iostream>
#include <istream>
#include <iterator>
#include <limits>
#include <list>
#include <locale>
#include <map>
#include <memory>
#include <new>
#include <numeric>
#include <ostream>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <streambuf>
#include <string>
#include <typeinfo>
#include <utility>
#include <valarray>
#include <vector>

#if __cplusplus >= 201103L
#include <array>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <forward_list>
#include <future>
#include <initializer_list>
#include <mutex>
#include <random>
#include <ratio>
#include <regex>
#include <scoped_allocator>
#include <system_error>
#include <thread>
#include <tuple>
#include <typeindex>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#endif

#include <algorithm>
// #include <ext/pb_ds/detail/standard_policies.hpp>
#define trace2(x, y)             cout <<#x<<": "<<x<<" | "<<#y<<": "<<y<< endl;
#define trace3(x, y, z)          cout <<#x<<": "<<x<<" | "<<#y<<": "<<y<<" | "<<#z<<": "<<z<<endl;
#define trace4(a, b, c, d)       cout <<#a<<": "<<a<<" | "<<#b<<": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<endl;
#define trace5(a, b, c, d, e)    cout <<#a<<": "<<a<<" | "<<#b<<": "<<b<<" | "<<#c<<": "<<c<<" | "<<#d<<": "<<d<<" | "<<#e<<": "<<e<<endl;
const double PI=3.141592653589793238462643383279502884197169399375105820974944;
#define pb push_back
#define mp make_pair
#define F first
#define S second
#define ll long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
#define ull unsigned long long
#define rep(i,a,b) for(ll i = a; i < b; ++i)
#define sz(a) int((a).size()) 
#define pb push_back 
#define all(c) (c).begin(),(c).end() 
#define tr(c,i) for(typeofa((c).begin() i = (c).begin(); i != (c).end(); i++) 
#define present(c,x) ((c).find(x) != (c).end()) 
#define cpresent(c,x) (find(all(c),x) != (c).end()) 
#define p(a) cout << a << "\n";
#define p1(a) cout << a << " ";

#define PI 3.141592653589793
#define MOD (ll)(1e9 + 7)
#define m(a) ((a)%MOD)

using namespace std;
typedef vector<int> vi; 
typedef vector<vi> vvi; 
typedef pair<ll,ll> ii; 
//=======================

void solve()
{	
	ll n,m;
	cin >> n >> m;
	ll sum = 0;
	vector<ll> vec;
	vec.pb(0);
	ll ans = 0;
	rep(i,0,n)
	{
		ll a;
		cin >> a;
		vec.pb(a);
		if(i%2 == 0)
		{	
			ans += vec[i+1] - vec[i];
		}
		else
		{
			sum += vec[i+1] - vec[i];			
		}
	}
	vec.pb(m);
	// rep(i,0,vec.size())
	// {
	// 	p1(vec[i])
	// }
	// p("")
	if(n%2 == 1)
	{
		sum += vec[vec.size()-1] - vec[vec.size()-2];
	}	
	else
	{
		ans += vec[vec.size()-1] - vec[vec.size()-2];
	}
	ll finalans = ans, current = 0;
	// trace2(sum, ans)
	ans = 0;
	rep(i,1,vec.size()-1)
	{
		if(i%2 == 1)
		{
			ans += vec[i] - vec[i-1];
			if(vec[i+1] - vec[i] > 1)
				finalans = max(finalans, sum + ans - 1);
		}
		else
		{			
			sum -= vec[i] - vec[i-1];
			if(vec[i+1] - vec[i] > 1)
				finalans = max(finalans, sum + ans - 1);
		}
		trace4(vec[i], vec[i-1], finalans, sum + ans - 1)
	}
	p(finalans)
}

//=======================
int main()
{
	bool testing = false;
	IOS
	if(testing)
	{
		freopen("test.txt","rt",stdin);
		int start = clock();
		solve();
		int end = clock();
		cout << "time: " << (end - start)/(double)(CLOCKS_PER_SEC)*1000 << " milliseconds\n";
	}
	else
	{
		solve();
	}
} 