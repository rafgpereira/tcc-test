#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e6 + 5;
const long long minn = 1e9 + 5;
const long long mod = 1000000007;
const int INF = 0x3f3f3f3f;
const long long LIMIT = 4294967295LL;
vector<int> v[maxn];
int dp[maxn];
vector<int> G[maxn];
bool row[maxn], col[maxn];
bool flag = 0;
queue<int> q;
long long a[maxn];
int main() {
  ios::sync_with_stdio(false);
  int n, m;
  long long sum1 = 0, sum2 = 0;
  cin >> n >> m;
  for (int i = 1; i <= n; i++) cin >> a[i];
  a[n + 1] = m;
  for (int i = 2; i <= n + 1; i += 2) sum1 += a[i] - a[i - 1];
  sum1 += a[1] - 1;
  for (int i = 3; i <= n + 1; i += 2) sum2 += a[i] - a[i - 1];
  sum2 += a[1];
  cout << max(sum1, sum2) << endl;
  return 0;
}
