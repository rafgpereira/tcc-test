#include <bits/stdc++.h>
using namespace std;
int TN = 1;
void solve() {
  int n, m;
  cin >> n >> m;
  int a[n + 3], b[n + 3], st = 1;
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  a[n] = 0;
  a[n + 1] = m;
  sort(a + 0, a + n + 2);
  int cnt1 = 0;
  for (int i = 1; i < n + 2; i += 2) {
    cnt1 += a[i] - a[i - 1];
  }
  for (int i = 0; i < n + 2; i++) {
    b[i] = st;
    st = 1 - st;
  }
  int ans = 0, id = -1;
  for (int i = 1; i < n + 2; i++) {
    if (b[i - 1] == 1) {
      if (ans < a[i] - 1 - a[i - 1]) {
        ans = a[i] - 1 - a[i - 1];
        id = a[i] - 1;
      }
    } else {
      if (ans < a[i] - 1 - a[i - 1]) {
        ans = a[i] - 1 - a[i - 1];
        id = a[i - 1] + 1;
      }
    }
  }
  a[n + 2] = id;
  sort(a + 0, a + n + 3);
  int cnt = 0;
  for (int i = 1; i < n + 3; i += 2) {
    cnt += a[i] - a[i - 1];
  }
  cout << max(cnt, cnt1);
}
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(NULL);
  cout.tie(NULL);
  while (TN--) solve();
  return 0;
}
