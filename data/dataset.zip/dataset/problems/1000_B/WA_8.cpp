#include <bits/stdc++.h>
using namespace std;
int main() {
  int noElements, offTime;
  cin >> noElements >> offTime;
  list<int> times;
  int time;
  for (int i = 0; i < noElements; i++) {
    cin >> time;
    times.push_back(time);
  }
  bool front, back, between;
  front = false;
  back = false;
  between = false;
  int max1 = 0, max3 = 0;
  if ((times.front() - 0) > 1) {
    front = true;
    max1 = (times.front() - 0);
  }
  if ((offTime - times.back()) > 1) {
    back = true;
    max3 = (offTime - times.back());
  }
  int max2 = 0;
  list<int>::iterator it1, it2;
  it2 = times.end();
  advance(it2, -1);
  for (auto i = times.begin(); i != it2; i++) {
    int time1 = *i;
    advance(i, 1);
    int time2 = *i;
    if ((time2 - time1) > 1) between = true;
    if ((time2 - time1) > max2) {
      max2 = (time2 - time1);
      it1 = i;
    }
    advance(i, -1);
  }
  if (max1 > max2 && max1 > max3 && max1 > 1)
    times.push_front(max1 - 1);
  else if (max3 > max1 && max3 > max2 && max3 > 1)
    times.push_back(offTime - 1);
  else if ((max2 > max1 && max2 > max3) && max2 > 1) {
    if (noElements % 2 == 0) {
      list<int>::iterator i = it1;
      it1--;
      times.insert(i, *it1 + 1);
    } else
      times.insert(it1, *it1 - 1);
  } else if ((max1 == max3 && max1 > 1) || (max1 == max2 && max1 > 1))
    times.push_front(max1 - 1);
  else if (max3 == max2 && max3 > 1)
    times.push_back(offTime - 1);
  times.push_front(0);
  times.push_back(offTime);
  int max = 0;
  list<int>::iterator it = times.begin();
  advance(it, 1);
  for (; it != times.end(); advance(it, 2)) {
    int time1 = *it;
    advance(it, -1);
    int time2 = *it;
    max += (time1 - time2);
    advance(it, 1);
    if (*it == offTime) break;
  }
  cout << max;
  return 0;
}
