#include <bits/stdc++.h>
using namespace std;
int II() {
  int q;
  scanf("%d", &q);
  return q;
}
int dx[] = {0, -1, 0, 1};
int dy[] = {-1, 0, 1, 0};
void solve() {
  long long N, M;
  cin >> N >> M;
  long long ar[N + 10];
  ar[0] = 0;
  for (long long i = 1; i <= N; i++) cin >> ar[i];
  ar[N + 1] = M;
  vector<long long> v;
  for (long long i = 1; i <= N + 1; i++) {
    v.push_back(ar[i] - ar[i - 1]);
  }
  long long br[N + 10][2];
  br[N + 1][0] = br[N + 1][1] = 0;
  for (long long i = N; i >= 0; i--) {
    if (i & 1) {
      br[i][1] = v[i] + br[i + 1][1];
      br[i][0] = br[i + 1][0];
    } else {
      br[i][0] = v[i] + br[i + 1][0];
      br[i][1] = br[i + 1][1];
    }
  }
  long long cr[N + 10][2];
  cr[0][0] = v[0];
  cr[0][1] = 0;
  for (long long i = 1; i <= N; i++) {
    if (i & 1) {
      cr[i][1] = v[i] + cr[i - 1][1];
      cr[i][0] = cr[i - 1][0];
    } else {
      cr[i][0] = v[i] + cr[i - 1][0];
      cr[i][1] = cr[i - 1][1];
    }
  }
  long long mx = 0;
  for (long long i = 0; i <= N; i++) {
    if (i == 0) {
      mx = max(mx, v[i] - 1 + max(br[i + 1][0], br[i + 1][1]));
    } else if (i == N) {
      mx = max(mx, v[i] - 1 + max(cr[i - 1][0], cr[i - 1][1]));
    } else {
      mx = max(mx,
               max(cr[i - 1][0] + br[i + 1][1], cr[i - 1][1] + br[i + 1][0]) +
                   v[i] - 1);
    }
  }
  long long w = max(br[0][0], br[0][1]);
  cout << max(mx, w) << endl;
}
int32_t main() {
  long long tt;
  tt = 1;
  long long cas = 1;
  while (tt--) {
    solve();
  }
}
