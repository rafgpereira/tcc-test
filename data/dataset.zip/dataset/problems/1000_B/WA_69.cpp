#include <bits/stdc++.h>
using namespace std;
vector<long long int> v, w;
int main() {
  long long int n, k;
  scanf("%lld%lld", &n, &k);
  v.push_back(0);
  for (long long int i = 0; i < n; i++) {
    long long int a;
    scanf("%lld", &a);
    v.push_back(a);
  }
  v.push_back(k);
  long long int sum = 0, sum2 = 0, mx = 0;
  for (long long int i = 1; i < v.size(); i++) {
    if (i % 2 == 1)
      sum += v[i] - v[i - 1];
    else
      sum2 += v[i] - v[i - 1];
    mx = max(mx, sum - sum2);
  }
  if (mx == 0)
    cout << sum2 << endl;
  else
    cout << sum2 + mx - 1 << endl;
}
