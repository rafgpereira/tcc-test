#include <bits/stdc++.h>
using namespace std;
void ins(long long int a[], long long int n, long long int i = 0) {
  for (long long int i = 0; i < n; i++) a[i] = i;
}
template <typename t>
void ins(t a[], long long int n, t b = 0) {
  for (long long int i = 0; i < n; i++) a[i] = b;
}
void print(long long int a[], long long int n) {
  for (long long int i = 0; i < n; i++) cout << a[i] << " ";
  ;
  cout << endl;
}
template <typename t>
void print(t a[], long long int n) {
  for (long long int i = 0; i < n; i++) cout << a[i] << " ";
  ;
  cout << endl;
}
void po(long long int a[], long long int n) {
  for (long long int i = 0; i < n; i++) {
    cin >> a[i];
  }
}
template <typename t>
void po(t a[], long long int n) {
  for (long long int i = 0; i < n; i++) {
    cin >> a[i];
  }
}
int main() {
  long long int n, m;
  cin >> n >> m;
  long long int p;
  if ((n + 1) % 2 == 0) {
    p = 0;
  } else {
    p = 1;
  }
  long long int a[n + 1];
  long long int b[(n + 1) / 2];
  long long int c[(n + 1) / 2];
  long long int sum = 0;
  for (long long int i = 0; i < n; i++) {
    cin >> a[i];
  }
  a[n] = m;
  for (long long int i = 0; i < n + 1; i++) {
    if (i % 2 == 1) sum += a[i] - a[i - 1];
  }
  long long int counter = 0;
  long long int sum1 = 0;
  long long int max = numeric_limits<double>::min();
  for (long long int i = 0; i < n + 1; i++) {
    if (i % 2 == 0) {
      if (i != 0)
        sum1 += a[i] - a[i - 1];
      else
        sum1 += a[i];
      b[i / 2] = sum1;
    }
  }
  for (long long int i = 0; i < n + 1; i++) {
    if (i % 2 == 1) {
      c[i / 2] = sum;
      sum -= a[i] - a[i - 1];
    }
  }
  long long int v;
  if (p == 1) {
    v = (n + 1) / 2;
  } else {
    v = (n + 1) / 2 - 1;
  }
  for (long long int i = 0; i < min((n + 1) / 2, v); i++) {
    long long int u = b[i / 2] - 1 + c[i / 2];
    if (max < u) {
      max = u;
    }
  }
  if (true) {
    if (max < sum1) {
      max = sum1;
    }
  }
  if (n == 1) {
    cout << a[1] - 1;
  } else
    cout << max << endl;
  return 0;
}
