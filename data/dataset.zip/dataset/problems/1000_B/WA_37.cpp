#include <bits/stdc++.h>
using namespace std;
const long long maxn = 1e5 + 5;
int n, m;
pair<int, int> v[maxn];
long long ans = 0;
long long pos = 0;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cin >> n >> m;
  long long Max = 0;
  long long t1 = 0, t2 = 0;
  int tmp;
  v[0].first = 0, v[0].second = 0;
  for (int i = 1; i < n + 1; i++) {
    cin >> tmp;
    v[i].first = tmp, v[i].second = tmp - v[i - 1].first;
    if (v[i].second > Max) {
      pos = i, Max = v[i].second;
    }
    if (i % 2) t1 += v[i].second;
  }
  v[n + 1].first = m, v[n + 1].second = m - v[n].first;
  if (n % 2 == 0) t1 += v[n + 1].second;
  if (pos % 2) {
    v[n + 2].first = v[pos].first - 1;
    v[n + 2].second = Max - 1;
    v[pos].second = 1;
  } else {
    v[n + 2].first = v[pos - 1].first + 1;
    v[n + 2].second = 1;
    v[pos].second = Max - 1;
  }
  sort(v, v + n + 3);
  for (int i = 1; i < n + 3; i++) {
    if (i % 2) t2 += v[i].second;
  }
  ans = max(t1, t2);
  cout << ans;
}
