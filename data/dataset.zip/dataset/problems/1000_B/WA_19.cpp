#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 9;
long long a[maxn];
long long s1[maxn], s2[maxn];
long long sum[maxn];
long long n, m;
int main() {
  scanf("%I64d%I64d", &n, &m);
  for (int i = 1; i <= n; i++) {
    scanf("%I64d", a + i);
    if (i % 2 == 1) {
      s1[i] = a[i] - a[i - 1];
    } else {
      s2[i] = a[i] - a[i - 1];
    }
    sum[i] = sum[i - 1] + s1[i];
  }
  if ((n + 1) % 2 == 1) {
    s1[n + 1] = m - a[n];
  } else {
    s2[n + 1] = m - a[n];
  }
  for (int i = n; i >= 1; i--) {
    s1[i] += s1[i + 1];
    s2[i] += s2[i + 1];
  }
  int flag = 1;
  long long ans;
  for (int i = 1; i <= n; i++) {
    if (s2[i] > s1[i] + 1) {
      if (i % 2 == 1)
        ans = s2[i] - 1 + sum[i];
      else
        ans = s2[i] - 1 + sum[i - 1];
      flag = 0;
      break;
    }
  }
  if (flag) ans = s1[1];
  printf("%I64d\n", ans);
  return 0;
}
