#include <bits/stdc++.h>
#pragma comment(linker, "/STACK:268435456")
using namespace std;
template <typename T1, typename T2>
istream& operator>>(istream& in, pair<T1, T2>& t) {
  return in >> t.first >> t.second;
}
template <typename T1, typename T2>
ostream& operator<<(ostream& out, pair<T1, T2>& t) {
  return out << t.first << " " << t.second << endl;
}
template <typename T>
istream& operator>>(istream& in, vector<T>& t) {
  for (long long i = 0; i < t.size(); i++) in >> t[i];
  return in;
}
template <typename T>
ostream& operator<<(ostream& out, vector<T>& t) {
  for (long long i = 0; i < t.size(); i++) out << t[i] << " ";
  return out;
}
signed main() {
  long long rrrr = 1e5;
  long long n, m;
  cin >> n >> m;
  vector<long long> ve(n);
  cin >> ve;
  ve.insert(ve.begin(), 0);
  ve.insert(ve.end(), m);
  long long defoff = 0;
  for (long long i = 2; i < ve.size(); i += 2) {
    defoff += ve[i] - ve[i - 1];
  }
  long long defon = 0;
  for (long long i = 1; i < ve.size(); i += 2) {
    defon += ve[i] - ve[i - 1];
  }
  long long out = defon;
  long long cur = 0;
  for (long long i = 1; i < ve.size() - 1; ++i) {
    if (i % 2 == 0) {
      defoff -= ve[i] - ve[i - 1];
      out = max(out, defoff + cur + ve[i] - ve[i - 1] - 1);
    } else {
      defon -= ve[i] - ve[i - 1];
      out = max(out, defon + cur + ve[i] - ve[i - 1] - 1);
      cur += ve[i] - ve[i - 1];
    }
  }
  cout << out << endl;
  return 0;
}
