#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  cout.tie(0);
  int n;
  cin >> n;
  long long m;
  cin >> m;
  long long a[100010];
  for (int i = 1; i <= n; i++) {
    cin >> a[i];
  }
  a[0] = 0;
  a[n + 1] = m;
  long long pre[100010] = {0};
  for (int i = 1; i <= n + 1; i++) {
    if (i & 1) {
      pre[i] = pre[i - 1] + a[i] - a[i - 1];
    } else
      pre[i] = pre[i - 1];
  }
  long long postEven[100010] = {0}, postOdd[100010] = {0};
  for (int i = n; i >= 0; i -= 2) {
    if (i + 2 <= n + 1) postEven[i + 1] = postEven[i + 2];
    postEven[i] = postEven[i + 1] + a[i + 1] - a[i];
  }
  for (int i = n - 1; i >= 0; i -= 2) {
    if (i + 2 <= n + 1) postOdd[i + 1] = postOdd[i + 2];
    postOdd[i] = postOdd[i + 1] + a[i + 1] - a[i];
  }
  long long ans = pre[n + 1];
  for (int i = 0; i < n + 1; i += 2) {
    if (a[i + 1] - a[i] == 1) continue;
    long long temp = 0;
    int cnt = 0;
    if (i - 1 >= 0) temp += pre[i - 1];
    temp += (a[i + 1] - 1) - a[i];
    cnt = n + 1 - i;
    if (cnt & 1)
      temp += postOdd[i + 1];
    else
      temp += postEven[i + 1];
    ans = max(ans, temp);
    temp = 0;
    cnt = 0;
    if (i == 0) continue;
    if (a[i] - a[i - 1] == 1) continue;
    temp = pre[i - 1];
    temp += a[i] - (a[i - 1] + 1);
    cnt = n + 1 - i;
    if (cnt & 1)
      temp += postOdd[i + 1];
    else
      temp += postEven[i + 1];
    ans = max(ans, temp);
  }
  cout << ans;
  return 0;
}
