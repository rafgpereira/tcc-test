#include <bits/stdc++.h>
using namespace std;
const int N = 110000;
int n, m, a[N], maxn;
int main() {
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
  a[0] = 0;
  a[n + 1] = m;
  maxn = 0;
  int last = 0, sum = 0;
  for (int i = 0; i <= n; i++) {
    if ((i & 1))
      maxn += a[i];
    else
      maxn -= a[i];
    sum += (i % 2 == 0) ? a[i] : -a[i];
  }
  if ((n + 1) & 1) maxn += a[n + 1];
  for (int i = 1; i <= n; i++) {
    int ans = 0;
    last += (ans + ((i - 1) % 2 == 1 ? a[i - 1] : (-a[i - 1])));
    ans = last;
    sum -= (i % 2 == 0) ? a[i] : -a[i];
    ans += sum;
    if ((n + 1) % 2 == 0) ans += a[n + 1];
    if (a[i] - 1 == a[i - 1] && a[i] + 1 == a[i + 1])
      maxn = max(maxn, ans);
    else {
      if (i % 2 == 0)
        ans++;
      else
        ans--;
      maxn = max(maxn, ans);
    }
  }
  printf("%d\n", maxn);
  return 0;
}
