#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  vector<int> a(n + 3);
  a.push_back(0);
  for (int i = 0; i < n; i++) {
    int dd;
    cin >> dd;
    a.push_back(dd);
  }
  a.push_back(m);
  vector<int> even, odd;
  for (int i = 1; i < (int)a.size(); i++) {
    if (i % 2 != 0) {
      even.push_back(a[i] - a[i - 1]);
    } else {
      odd.push_back(a[i] - a[i - 1]);
    }
  }
  for (int i = 1; i < (int)even.size(); i++) {
    even[i] += even[i - 1];
  }
  for (int i = 1; i < (int)odd.size(); i++) {
    odd[i] += odd[i - 1];
  }
  int ans = 0;
  for (int i = 0; i < (int)a.size() - 2; i++) {
    if (a[i + 1] - a[i] == 1) continue;
    if (i % 2 == 0) {
      ans = max(ans, max(even[(int)even.size() - 1] - (a[i + 1] - a[i - 1]) +
                             (a[i + 1] - a[i]) - 1,
                         odd[(int)odd.size() - 1] + (a[i + 1] - a[i]) - 1));
    }
    if (i % 2 != 0)
      ans = max(ans, max(even[(int)even.size() - 1] - (a[i + 2] - a[i + 1]) +
                             (a[i + 1] - a[i]) - 1,
                         odd[(int)odd.size() - 1] + (a[i + 1] - a[i]) - 1 -
                             (a[i + 2] - a[i - 1])));
  }
  if (even[(int)even.size() - 1] > ans) ans = even[even.size() - 1];
  if (odd[odd.size() - 1] > ans) ans = odd[(int)odd.size() - 1];
  cout << ans;
}
