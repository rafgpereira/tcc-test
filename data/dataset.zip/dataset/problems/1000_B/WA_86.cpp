#include <bits/stdc++.h>
using namespace std;
long long modexpo(long long a, long long b) {
  long long res = 1;
  while (b > 0) {
    if (b & 1) res = (res * a) % 1000000007;
    a = (a * a) % 1000000007;
    b >>= 1;
  }
  return res;
}
long long expo(long long a, long long b) {
  long long res = 1;
  while (b > 0) {
    if (b & 1) res = (res * a);
    a = (a * a);
    b >>= 1;
  }
  return res;
}
long long gcd(long long a, long long b) {
  if (a == 0) return b;
  return gcd(b % a, a);
}
bool isPrime(long long n) {
  if (n <= 1) return false;
  if (n <= 3) return true;
  if (n % 2 == 0 || n % 3 == 0) return false;
  for (int i = 5; i * i <= n; i += 6) {
    if ((n % i == 0) || (n % (i + 2) == 0)) return false;
  }
  return true;
}
long long max_value(vector<long long> arr) {
  long long m = 0;
  for (int i = 0; i < arr.size(); i++) m = max(m, arr[i]);
  return m;
}
long double dist(long long x1, long long y1, long long x2, long long y2) {
  return (long double)sqrt(
      (long double)((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)));
}
vector<long long> getdivisorsum(vector<long long> ans) {
  for (int i = 2; i <= ans.size() - 1; i++) {
    for (int j = i; j < ans.size(); j += i) ans[j]++;
  }
  return ans;
}
unordered_map<long long, long long> m;
void PrimeFactorization(long long n) {
  unordered_set<long long> temp;
  while (n % 2 == 0) {
    if (temp.find(2) == temp.end()) {
      temp.insert(2);
      m[2]++;
    }
    n = n / 2;
  }
  for (int i = 3; i <= sqrt(n); i += 2) {
    if (n % i == 0) {
      while (n % i == 0) {
        if (temp.find(i) == temp.end()) {
          temp.insert(i);
          m[i]++;
        }
        n = n / i;
      }
    }
  }
  if (n > 2) {
    temp.insert(n);
    m[n]++;
  }
}
long long nCr(long long n, long long r) {
  if (r == 0) return 1;
  return (n * nCr(n - 1, r - 1)) / r;
}
long long lcm(long long a, long long b, long long c) {
  long long l = (a * b) / (gcd(a, b));
  l = (l * c) / (gcd(l, c));
  return l;
}
int main() {
  long long n, m;
  cin >> n >> m;
  cout << m << endl;
  vector<long long> arr(n + 2, 0);
  arr.push_back(0);
  for (int i = 1; i <= n; i++) cin >> arr[i];
  arr[n + 1] = m;
  vector<pair<long long, long long> > foo(n + 2, make_pair(0, 0));
  for (int i = 0; i < n + 2; i++) {
    if (i % 2 == 1) {
      if (i == 0)
        foo[i].first += arr[i];
      else
        foo[i].first = arr[i] - arr[i - 1];
    } else {
      if (i == 0)
        foo[i].second += arr[i];
      else
        foo[i].second = arr[i] - arr[i - 1];
    }
  }
  for (int i = 1; i < n + 2; i++) {
    foo[i].first += foo[i - 1].first;
    foo[i].second += foo[i - 1].second;
  }
  long long ans = foo[n + 1].first;
  for (int i = 1; i <= n + 1; i++) {
    long long temp = 0;
    if (i % 2 == 1) {
      temp = temp + foo[i].first - 1;
      temp += (foo[n + 1].second - foo[i - 1].second);
    } else {
      temp = temp + foo[i - 1].first + arr[i] - arr[i - 1] - 1;
      temp += (foo[n + 1].second - foo[i].second);
    }
    ans = max(temp, ans);
  }
  cout << ans << endl;
  return 0;
}
