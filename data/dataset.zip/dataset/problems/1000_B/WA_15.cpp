#include <bits/stdc++.h>
using namespace std;
const long long N = 200005;
long long n, m, a[N], s1[N], s2[N];
signed main() {
  long long i, re = 0;
  scanf("%lld%lld", &n, &m);
  for (i = 1; i <= n; i++) scanf("%lld", &a[i]);
  sort(a + 1, a + n + 1);
  a[0] = 0;
  a[n + 1] = m;
  if (n == 0) return 0 * puts("0");
  if (n & 1) {
    s1[1] = a[1] - a[0];
    for (i = 3; i <= n; i += 2) {
      s1[i] = s1[i - 2] + a[i] - a[i - 1];
    }
    s1[n + 2] = s1[n + 4] = s1[n];
    re = max(re, s1[n]);
    s2[0] = 0;
    for (i = 2; i <= n + 1; i += 2) {
      s2[i] = s2[i - 2] + a[i] - a[i - 1];
    }
    s2[n + 3] = s2[n + 5] = s2[n + 1];
    for (i = 0; i <= n; i++) {
      if (a[i + 1] - a[i] <= 1) continue;
      if (i & 1)
        re = max(re, s1[i] + a[i + 1] - a[i] - 1 + s2[i + 3] - s2[i + 1]);
      else
        re = max(re, s1[i - 1] + a[i + 1] - a[i] - 1 + s2[i + 2] - s2[i]);
    }
  } else {
    s1[1] = a[1] - a[0];
    for (i = 3; i <= n + 1; i += 2) {
      s1[i] = s1[i - 2] + a[i] - a[i - 1];
    }
    s1[n + 3] = s1[n + 5] = s1[n + 1];
    re = max(re, s1[n + 1]);
    s2[0] = 0;
    for (i = 2; i <= n; i += 2) {
      s2[i] = s2[i - 2] + a[i] - a[i - 1];
    }
    s2[n + 2] = s2[n + 4] = s2[n];
    for (i = 0; i <= n; i++) {
      if (a[i + 1] - a[i] <= 1) continue;
      if (i & 1)
        re = max(re, s1[i] + a[i + 1] - a[i] - 1 + s2[i + 3] - s2[i + 1]);
      else
        re = max(re, s1[i - 1] + a[i + 1] - a[i] - 1 + s2[i + 2] - s2[i]);
    }
  }
  printf("%lld\n", re);
}
