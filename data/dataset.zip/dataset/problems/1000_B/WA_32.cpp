#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m, flag;
  cin >> n >> m;
  int a[n], off[n], on[n];
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  if (n % 2 == 0) {
    on[n - 1] = m - a[n - 1];
    off[n - 1] = 0;
    flag = 0;
  }
  if (n % 2 == 1) {
    off[n - 1] = m - a[n - 1];
    on[n - 1] = 0;
    flag = 1;
  }
  for (int i = n - 2; i >= 0; i--) {
    if (flag == 1) {
      on[i] = on[i + 1] + (a[i + 1] - a[i]);
      off[i] = off[i + 1];
      flag = 0;
    } else if (flag == 0) {
      off[i] = off[i + 1] + (a[i + 1] - a[i]);
      on[i] = on[i + 1];
      flag = 1;
    }
  }
  int dif[n], md = INT_MIN, mdi;
  for (int i = 0; i < n; i++) {
    dif[i] = off[i] - on[i];
    if (md < dif[i]) {
      md = dif[i];
      mdi = i;
    }
  }
  int ans = 0;
  if (a[mdi] < a[mdi + 1] - 1 && a[mdi] < m - 1) {
    if (mdi % 2 == 0) {
      ans = off[mdi + 1] + (on[0] - on[mdi]);
      ans = ans + (a[mdi + 1] - a[mdi]) - 1;
      ans = ans + a[0];
    } else {
      ans = on[mdi + 1] + (on[0] - on[mdi]);
      ans = ans + (a[mdi + 1] - a[mdi]) - 1;
      ans = ans + a[0];
    }
  } else {
    ans = ans + a[0] + on[0];
  }
  if (md < 0 && n % 2 == 1 && a[n - 1] < m - 1) {
    ans = ans + (m - a[n - 1]) - 1;
  }
  cout << ans;
  return 0;
}
