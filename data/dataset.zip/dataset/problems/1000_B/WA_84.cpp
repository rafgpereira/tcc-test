#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10, INF = 0x3f3f3f3f, mod = 1e9 + 7;
int n, m;
int flag[N];
int a[N];
void solve() {
  scanf("%d%d", &n, &m);
  long long sum = 0;
  for (int i = 1; i <= n; i++) {
    scanf("%d", &a[i]);
    if (i % 2) sum += (a[i] - a[i - 1]);
  }
  if (n % 2 == 0) sum += m - a[n];
  a[n + 1] = m;
  long long ma = sum;
  for (int i = n; i; i--) {
    if (i % 2 == 0)
      sum -= (a[i + 1] - a[i]);
    else
      sum += (a[i + 1] - a[i]);
    if (ma < sum) {
      ma = sum;
    }
  }
  printf("%lld\n", ma - 1);
}
int main() {
  solve();
  return 0;
}
