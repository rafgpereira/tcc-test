#include <bits/stdc++.h>
using namespace std;
int n, m, a[100005], on[100005], off[100005];
bool of[100005];
int main() {
  scanf("%d%d", &n, &m);
  for (int i = 0; i < n; ++i) scanf("%d", a + i);
  a[n] = m;
  for (int i = 0; i < n; ++i)
    if (i % 2) of[i] = 1;
  for (int i = n - 1; i >= 0; --i)
    if (of[i]) {
      on[i] += on[i + 1] + a[i + 1] - a[i];
      off[i] = off[i + 1];
    } else {
      on[i] = on[i + 1];
      off[i] += off[i + 1] + a[i + 1] - a[i];
    }
  int maxind = -1;
  int maxoff = 0;
  for (int i = 0; i < n; ++i)
    if (off[i] - on[i] > maxoff) {
      maxoff = off[i] - on[i];
      maxind = i;
    }
  if (maxind == -1) {
    printf("%d", on[0] + a[0]);
    return 0;
  }
  int val = a[maxind] - 1;
  int ind = maxind - 1;
  while (val && val == a[ind]) {
    val--;
    ind--;
  }
  if (val) {
    printf("%d", (off[maxind] - on[maxind]) + (on[0] - on[maxind]) + a[0]);
    return 0;
  }
  val = a[maxind] + 1;
  ind = maxind + 1;
  while (val && val == a[ind]) {
    val++;
    ind++;
  }
  printf("%d", (off[maxind] - on[maxind]) + (on[0] - on[maxind]) + a[0] + 1);
  return 0;
}
