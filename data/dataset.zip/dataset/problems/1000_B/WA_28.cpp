#include <bits/stdc++.h>
using namespace std;
const int MEA = 100005;
int n, m;
long long times[MEA], onTime = 0, offTime = 0, totalTime = 0;
long long on[MEA], off[MEA];
long long ans = 0;
int main() {
  cin >> n >> m;
  times[0] = 0;
  times[n + 1] = m;
  bool isOn = true;
  for (int i = 1; i <= n; i++) {
    cin >> times[i];
    if (isOn) {
      on[i] = on[i - 1] + (times[i] - times[i - 1]);
      off[i] = off[i - 1];
      isOn = false;
      onTime += times[i] - times[i - 1];
    } else {
      off[i] = off[i - 1] + (times[i] - times[i - 1]);
      on[i] = on[i - 1];
      isOn = true;
      offTime += times[i] - times[i - 1];
    }
  }
  if (isOn) {
    on[n + 1] = on[n] + (times[n + 1] - times[n]);
    off[n + 1] = off[n];
    onTime += times[n + 1] - times[n];
  } else {
    off[n + 1] = off[n] + (times[n + 1] - times[n]);
    on[n + 1] = on[n];
    offTime += times[n + 1] - times[n];
  }
  totalTime = onTime;
  for (int i = 1; i <= n; i += 2) {
    long long On = onTime - on[i];
    long long Off = offTime - off[i];
    if (Off > On) {
      if (times[i] + 1 < times[i + 1]) {
        Off--;
        swap(On, Off);
        ans = max(ans, totalTime - Off + On);
      }
    }
  }
  cout << ans;
}
