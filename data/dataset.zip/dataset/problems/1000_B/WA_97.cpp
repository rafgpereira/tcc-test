#include <bits/stdc++.h>
using namespace std;
const long long M = 998244353;
const long long oo = 1e13;
long long n, i, m, q, h, r, l, u, v, t, y, ans;
long long a[1200005], b[1205000], sa[1205000][2];
int main() {
  freopen("input.txt", "r", stdin);
  cin >> n >> m;
  for (int i = 0; i < n; i++) cin >> a[i];
  b[0] = a[0];
  for (int i = 0; i < n - 1; i++) b[i + 1] = a[i + 1] - a[i];
  b[n] = m - a[n - 1];
  for (int i = 0; i <= n; i++) {
    sa[i + 1][0] = sa[i][0];
    sa[i + 1][1] = sa[i][1];
    sa[i + 1][i % 2] += b[i];
  }
  long long ans = sa[n + 1][0];
  for (int i = 0; i <= n; i++) {
    long long cur = sa[i][0];
    if (b[i] < 2) continue;
    cur += b[i] - 1;
    cur += sa[n + 1][1] - sa[i + 1][1];
    ans = max(ans, cur);
  }
  cout << ans << endl;
  return 0;
}
