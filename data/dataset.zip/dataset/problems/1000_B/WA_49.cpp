#include <bits/stdc++.h>
using namespace std;
const long long lt = 100005;
long long mod = 1000000007;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  long long n, m;
  cin >> n >> m;
  long long i, val;
  vector<long long> a;
  vector<long long> lit(100005, 0);
  vector<long long> off(100005, 0);
  for (i = 0; i < n; i++) {
    cin >> val;
    a.push_back(val);
  }
  long long x = a[1];
  lit[0] = a[0];
  off[1] = a[1] - a[0];
  long long totallit = 0;
  long long totaloff = 0;
  for (i = 2; i < n; i++) {
    if (i % 2 == 0)
      lit[i] = lit[i - 2] + a[i] - x;
    else
      off[i] = lit[i - 2] + a[i] - x;
    x = a[i];
  }
  if (n % 2 == 0) {
    lit[n] = lit[n - 2] + m - a[n - 1];
    totallit = lit[n];
    totaloff = off[n - 1];
  } else {
    off[n] = off[n - 2] + m - a[n - 1];
    totaloff = off[n];
    totallit = lit[n - 1];
  }
  long long ans = totallit;
  x = 0;
  for (i = 0; i < n; i++) {
    if (a[i] - 1 == x) {
      x = a[i];
      continue;
    }
    if (i % 2 == 0) {
      long long tmp;
      if (i == 0)
        tmp = lit[i] - 1 + totaloff;
      else
        tmp = lit[i] - 1 + totaloff - off[i - 1];
      ans = max(ans, tmp);
    } else {
      long long x = a[i] + 1;
      long long tmp = lit[i - 1] + 1 + totaloff - off[i];
      ans = max(ans, tmp);
    }
    x = a[i];
  }
  cout << ans << endl;
  return 0;
}
