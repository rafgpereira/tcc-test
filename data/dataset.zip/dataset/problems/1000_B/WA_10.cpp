#include <bits/stdc++.h>
using namespace std;
long long n, m, a[100005], sum, b[100005];
int main() {
  cin >> n >> m;
  for (int i = 1; i <= n; i++) {
    cin >> a[i];
    if (i & 1) b[i - 1] = a[i] - a[i - 1];
  }
  b[n] = m - a[n];
  for (int i = n; i >= 0; i--) b[i] += b[i + 1];
  long long mx = b[0];
  for (int i = 0; i <= n; i++)
    mx = max(mx, b[0] - b[i] + (m - a[i] - b[i] - 1));
  mx = max(mx, m - b[0]) - 1;
  cout << mx;
  return 0;
}
