#include <bits/stdc++.h>
using namespace std;
vector<int> divisors;
long long arr[100005], sumlon[100005], b[100005], sumloff[100005],
    sumron[100005], sumroff[100005];
int main() {
  int n;
  long long m;
  cin >> n >> m;
  int flag = 1;
  arr[0] = 0;
  b[0] = flag;
  for (int i = 1; i <= n; i++) {
    cin >> arr[i];
    flag = abs(flag - 1);
    b[i] = flag;
  }
  arr[n + 1] = m;
  flag = 1;
  for (int i = 1; i <= n; i++) {
    if (flag) {
      sumron[i] = sumron[i - 1] + (arr[i] - arr[i - 1]);
      sumroff[i] = sumroff[i - 1];
    } else {
      sumroff[i] = sumroff[i - 1] + (arr[i] - arr[i - 1]);
      sumron[i] = sumron[i - 1];
    }
    flag = abs(flag - 1);
  }
  if (flag) {
    sumron[n + 1] = sumron[n] + (arr[n + 1] - arr[n]);
    sumroff[n + 1] = sumroff[n];
  } else {
    sumroff[n + 1] = sumroff[n] + (arr[n + 1] - arr[n]);
    sumron[n + 1] = sumron[n];
  }
  for (int i = n; i >= 1; i--) {
    if (b[i]) {
      sumlon[i] = sumlon[i + 1] + arr[i + 1] - arr[i];
      sumloff[i] = sumloff[i + 1];
    } else {
      sumloff[i] = sumloff[i + 1] + arr[i + 1] - arr[i];
      sumlon[i] = sumlon[i + 1];
    }
  }
  sumlon[0] = sumlon[1] + arr[1];
  sumloff[0] = sumloff[1];
  long long ans = sumron[n + 1];
  for (int i = 1; i <= n + 1; i++) {
    if (b[i]) {
      ans = max(ans, sumloff[i] + sumron[i - 1] + 1);
      ans = max(ans, sumron[i] + 1 + sumloff[i + 1]);
    } else {
      ans = max(ans, sumron[i] + sumloff[i + 1] + arr[i + 1] - (arr[i] + 1));
      ans = max(ans, sumloff[i] + sumron[i - 1] + (arr[i] - 1) - arr[i]);
    }
  }
  cout << ans << "\n";
  return 0;
}
