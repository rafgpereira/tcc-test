#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, q;
  vector<int> v;
  cin >> n >> q;
  int t;
  int sum1 = 0;
  for (int i = 0; i < n; i++) {
    cin >> t;
    v.push_back(t);
  }
  sum1 += v[0];
  int len1 = v.size();
  for (int i = 1; i < len1 - 1; i = i + 2) sum1 += (v[i + 1] - v[i]);
  if ((len1) % 2 == 0) sum1 += (q - v[len1 - 1]);
  int maxx = -1;
  for (int i = 1; i < q; i++) {
    int sum = 0;
    vector<int>::iterator it;
    it = find(v.begin(), v.end(), i);
    if (it == v.end())
      v.push_back(i);
    else
      continue;
    sort(v.begin(), v.end(), less<int>());
    int len = v.size();
    sum += v[0];
    for (int i = 1; i < len - 1; i = i + 2) {
      sum += (v[i + 1] - v[i]);
    }
    if ((len) % 2 == 0) sum += (q - v[len - 1]);
    maxx = max(maxx, sum);
    maxx = max(maxx, sum1);
    it = find(v.begin(), v.end(), i);
    v.erase(it);
  }
  cout << maxx << endl;
  return 0;
}
