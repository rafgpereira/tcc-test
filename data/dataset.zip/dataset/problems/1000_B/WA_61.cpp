#include <bits/stdc++.h>
using namespace std;
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  int n, m;
  cin >> n >> m;
  int sum = 0;
  vector<pair<int, int> > v;
  int a = 0, b;
  while (n) {
    cin >> b;
    n--;
    v.push_back(pair<int, int>(a, b));
    sum += b - a;
    if (n) {
      cin >> a;
      n--;
      if (n == 0) {
        b = m;
        v.push_back(pair<int, int>(a, b));
        sum += b - a;
      }
    }
  }
  long long ans = sum, s;
  int add = 0;
  if (v[0].second != 1) {
    long long s = 1;
    ans = max(ans, 2 * s - 1 + m - sum);
  }
  for (int i = 0; i < v.size(); ++i) {
    add += v[i].second - v[i].first;
    if (v[i].second - 1 != v[i].first) {
      s = add - 1;
      ans = max(ans, 2 * s - v[i].second + 1 + m - sum);
    }
    if (i != v.size() - 1 && v[i].second + 1 != v[i + 1].first) {
      s = add;
      ans = max(ans, 2 * s - v[i].second - 1 + m - sum);
    }
    if (i == v.size() - 1 && v[i].second != m) {
      s = sum;
      ans = max(ans, 2 * s + 1 - sum);
    }
  }
  cout << ans;
}
