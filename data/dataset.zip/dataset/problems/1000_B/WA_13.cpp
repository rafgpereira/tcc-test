#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  long long t;
  t = 1;
  while (t--) {
    long long n, i;
    double ans = 1e9 + 5;
    cin >> n;
    double m;
    cin >> m;
    double a[n], b[n];
    for (i = 0; i < n; i++) cin >> a[i];
    for (i = 0; i < n; i++) cin >> b[i];
    double str = 0, end = 1e9 + 5;
    while (str + 1e-7 < end) {
      double mid = (str + end) / 2, md = mid;
      long long f = 1;
      double w = m + mid;
      for (i = 0; i < n; i++) {
        w = w - w / a[i];
        w = w - w / b[(i + 1) % n];
      }
      if (w >= m) {
        ans = md;
        end = md;
      } else {
        str = md;
      }
    }
    if (ans > 1e9 + 1)
      printf("-1");
    else
      printf("%0.8f", ans);
  }
  return 0;
}
