#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  scanf("%d %d", &n, &m);
  int a[n];
  for (int i = 0; i < n; i++) scanf("%d", &a[i]);
  int left[n], right[n], rightlit[n], rightoff[n];
  for (int i = 0; i < n; i++) {
    if (i == 0) {
      left[i] = a[i];
    } else if (i % 2 == 0 && i != 0) {
      left[i] = left[i - 1] + a[i] - a[i - 1];
    } else
      left[i] = left[i - 1];
  }
  for (int i = n - 1; i >= 0; i--) {
    if (i == n - 1) {
      rightlit[i] = m - a[i];
      rightoff[i] = 0;
      right[i] = rightlit[i];
    } else {
      rightlit[i] = rightoff[i + 1] + a[i + 1] - a[i];
      rightoff[i] = rightlit[i + 1];
      if (rightlit[i] > rightoff[i])
        right[i] = rightlit[i];
      else
        right[i] = rightoff[i];
    }
  }
  int max = 0;
  for (int i = 0; i < n - 1; i++) {
    if ((left[i] + rightlit[i + 1]) > max && i % 2 == 0)
      max = left[i] + rightlit[i + 1];
    if ((left[i] + rightoff[i + 1] + a[i + 1] - a[i] - 1) > max && i % 2 == 0)
      max = left[i] + rightoff[i + 1] + a[i + 1] - a[i] - 1;
    if (i % 2 == 1) {
      if ((left[i] + rightlit[i + 1] + a[i + 1] - a[i] - 1) > max)
        max = left[i] + rightlit[i - 1] + a[i + 1] - a[i] - 1;
      if ((left[i] + rightoff[i + 1] + a[i + 1] - a[i]) > max)
        max = left[i] + rightoff[i + 1] + a[i + 1] - a[i];
    }
  }
  if (rightoff[0] + a[0] > max) max = rightoff[0] + a[0];
  if ((a[0] - 1 + rightlit[0]) > max) max = a[0] - 1 + rightlit[0];
  if (n % 2 == 0) {
    if (left[n - 1] + m - a[n - 1] > max) max = left[n - 1] + m - a[n - 1];
  } else {
    if ((left[n - 1] + m - a[n - 1] - 1) > max)
      max = left[n - 1] + m - a[n - 1] - 1;
  }
  printf("%d", max);
  return 0;
}
