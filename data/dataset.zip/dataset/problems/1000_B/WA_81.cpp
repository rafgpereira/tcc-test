#include <bits/stdc++.h>
using namespace std;
signed main() {
  long long n, close;
  cin >> n >> close;
  vector<long long> on(n);
  vector<long long> off(n);
  vector<long long> V(n);
  for (long long i = 0; i < n; i++) cin >> V[i];
  if (n % 2 == 0) {
    off[n - 1] = 0;
    long long last = V[n - 1];
    for (long long i = n - 2; i >= 0; i--) {
      if (i % 2 == 0)
        off[i] = off[i + 1] + (last - V[i]);
      else
        off[i] = off[i + 1];
      last = V[i];
    }
  } else {
    off[n - 1] = close - V[n - 1];
    long long last = V[n - 1];
    for (long long i = n - 2; i >= 0; i--) {
      if (i % 2 == 0)
        off[i] = off[i + 1] + (last - V[i]);
      else
        off[i] = off[i + 1];
      last = V[i];
    }
  }
  long long last = V[0];
  on[0] = V[0];
  for (long long i = 1; i < n; i++) {
    if (i % 2 == 0)
      on[i] = on[i - 1] + (V[i] - last);
    else
      on[i] = on[i - 1];
    last = V[i];
  }
  long long maxi;
  if (n % 2 == 0)
    maxi = on[n - 1] + (close - V[n - 1]);
  else
    maxi = on[n - 1];
  last = 0;
  for (long long i = 0; i < n; i++) {
    if (i % 2 == 0) {
      if (V[i] > last + 1) {
        maxi = max(maxi, on[i] - 1 + off[i]);
      }
    } else {
      if (V[i] > last + 1)
        maxi = max(maxi, on[i - 1] + V[i] - last - 1 + off[i]);
    }
    last = V[i];
  }
  cout << maxi << endl;
  return 0;
}
