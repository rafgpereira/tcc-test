#include <bits/stdc++.h>
using namespace std;
const int MOD = 1e9 + 7;
long long power(long long a, long long b) {
  long long ans = 1;
  while (b > 0) {
    if (b & 1) ans *= a;
    a = a * a;
    b >>= 1;
  }
  return ans;
}
long long powm(long long a, long long b) {
  a %= MOD;
  long long ans = 1;
  while (b > 0) {
    if (b & 1) ans = (ans * a) % MOD;
    a = (a * a) % MOD;
    b >>= 1;
  }
  return ans;
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  ;
  int n, m;
  cin >> n >> m;
  vector<int> A;
  A.push_back(0);
  for (int i = 1; i <= n; i++) {
    int x;
    cin >> x;
    A.push_back(x);
  }
  A.push_back(m);
  n += 2;
  int onIdx = 0, offIdx = 0;
  int onTime = 0, offTime = 0;
  int totOn = 0, totOff = 0;
  for (int i = 0; i < n - 1; i += 2) {
    if (A[i + 1] - A[i] > onTime) {
      onTime = A[i + 1] - A[i];
      onIdx = i;
    }
    totOn += A[i + 1] - A[i];
    ;
  }
  for (int i = 1; i < n - 1; i += 2) {
    if (A[i + 1] - A[i] > offTime) {
      offTime = A[i + 1] - A[i];
      offIdx = i;
    }
    totOff += A[i + 1] - A[i];
  }
  int on = 0;
  bool flag = false;
  if (A[onIdx + 1] - 1 != A[onIdx]) {
    A.insert(A.begin() + onIdx + 1, A[onIdx + 1] - 1);
    for (int i = 0; i < (int)A.size() - 1; i += 2) on += A[i + 1] - A[i];
    flag = true;
  }
  if (flag) {
    onTime = max(totOn, on);
    A.erase(A.begin() + onIdx + 1);
  }
  on = 0;
  flag = false;
  if (A[offIdx] + 1 != (offIdx + 1 < n ? A[offIdx + 1] : -1)) {
    A.insert(A.begin() + offIdx + 1, A[offIdx] + 1);
    for (int i = 0; i < (int)A.size() - 1; i += 2) on += A[i + 1] - A[i];
    flag = true;
  }
  if (flag) onTime = max(onTime, on);
  cout << onTime << "\n";
  return 0;
}
