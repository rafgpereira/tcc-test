#include <bits/stdc++.h>
using namespace std;
void mohammed() {
  ios::sync_with_stdio(0);
  ios_base::sync_with_stdio(0);
  cin.tie(0), cout.tie(0);
}
int main() {
  mohammed();
  long long n, m, x, dif1 = 0, dif2 = 0, Dif1 = 0;
  cin >> n >> m;
  vector<long long> v, vec, V, VEC;
  map<long long, long long> mp, a;
  v.push_back(0);
  mp[0]++;
  for (int i = 0; i < n; i++) {
    cin >> x;
    v.push_back(x);
    mp[x]++;
  }
  v.push_back(m);
  mp[m]++;
  a = mp;
  for (int i = 1; i < v.size(); i++) {
    vec.push_back(v[i] - v[i - 1]);
  }
  for (int i = 0; i < vec.size(); i++) {
    if (i % 2 == 0)
      dif1 += vec[i];
    else
      dif2 += vec[i];
  }
  if (dif1 > dif2) {
    cout << dif1;
    return 0;
  } else {
    for (int i = 0; i < v.size() - 1; i++) {
      if (mp[v[i] + 1] == 0 && v[i] + 1 < m && i % 2 == 1) {
        a[v[i] + 1]++;
        break;
      }
      if (mp[v[i] - 1] == 0 && v[i] - 1 > 0 && i % 2 == 1) {
        a[v[i] - 1]++;
        break;
      }
    }
  }
  for (map<long long, long long>::iterator it = a.begin(); it != a.end();
       it++) {
    V.push_back(it->first);
  }
  for (int i = 1; i < V.size(); i++) {
    VEC.push_back(V[i] - V[i - 1]);
  }
  for (int i = 0; i < VEC.size(); i++) {
    if (i % 2 == 0) Dif1 += VEC[i];
  }
  cout << Dif1;
  return 0;
}
