#include <bits/stdc++.h>
using namespace std;
vector<int> tol(vector<int> v) {
  int s = v.size();
  vector<int> q(s - 1);
  for (int i = 1; i < s; i++) q[i - 1] = v[i] - v[i - 1];
  return q;
}
int sum2(vector<int> y, int b, int e) {
  int r = 0;
  for (int i = b; i < e; i += 2) r += y[i];
  return r;
}
int main() {
  int n, m;
  cin >> n >> m;
  vector<int> a(n + 2), v(n + 1);
  for (int i = 1; i < n + 1; i++) cin >> a[i];
  a[n + 1] = m;
  v = tol(a);
  m = sum2(v, 0, n + 1);
  for (int i = 1; i < n + 1; i += 2) {
    int d = sum2(v, i, n + 1) - 1;
    if (d > sum2(v, i + 1, n + 1)) {
      int q = sum2(v, 0, i) + d;
      if (q > m) {
        cout << i << ' ' << m << endl;
        m = q;
      }
    }
  }
  cout << m;
  return 0;
}
