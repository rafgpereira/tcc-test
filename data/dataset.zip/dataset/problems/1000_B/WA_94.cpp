#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n, m;
  cin >> n >> m;
  long long int arr[n];
  vector<long long int> a;
  long long int sum = 0, sum1 = 0, sum2 = 0;
  for (long long int i = 0; i < n; i++) {
    cin >> arr[i];
  }
  a.push_back(arr[0]);
  for (long long int i = 1; i < n; i++) {
    a.push_back(arr[i] - arr[i - 1]);
  }
  a.push_back(m - arr[n - 1]);
  if (n % 2 == 0) {
    long long int max = 0;
    long long int x = 0;
    for (long long int i = 1; i < n; i += 2) {
      if (a[i] > max) {
        x = i;
        max = a[i];
        ;
      }
    }
    sum = sum + max - 1;
    for (long long int i = 0; i < x; i += 2) sum = sum + a[i];
    for (long long int i = x + 2; i < n + 1; i += 2) sum = sum + a[i];
    sum1 = sum1 + a[n] - 1;
    for (long long int i = 0; i < n; i += 2) sum1 = sum1 + a[i];
  } else {
    long long int max = 0;
    long long int x = 0;
    for (long long int i = 1; i < n; i += 2) {
      if (a[i] > max) {
        x = i;
        max = a[i];
      }
    }
    sum = sum + max - 1;
    for (long long int i = 0; i < x; i += 2) sum = sum + a[i];
    for (long long int i = x + 2; i < n + 1; i += 2) sum = sum + a[i];
    sum1 = sum1 + a[n] - 1;
    for (long long int i = 0; i < n; i += 2) sum1 = sum1 + a[i];
  }
  for (long long int i = 0; i < n + 1; i += 2) sum2 = sum2 + a[i];
  long long int y = max(sum, sum1);
  cout << max(y, sum2);
  return 0;
}
