#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
const long long int MXN = 1e18;
set<int> a;
char str[105], ch[105];
int p[N];
void solve(int r) {
  int l = 0;
  for (int i = r - 1; i >= 0; i--) {
    ch[l++] = str[i];
  }
  l = 0;
  for (int i = 0; i < r; i++) {
    str[i] = ch[l++];
  }
}
int main() {
  int n;
  cin >> n;
  cin >> str;
  for (int i = 1; i * i <= n; i++) {
    if (n % i == 0) {
      a.insert(i);
      a.insert(n / i);
    }
  }
  for (set<int>::iterator it = a.begin(); it != a.end(); it++) {
    solve(*it);
  }
  cout << str << endl;
}
