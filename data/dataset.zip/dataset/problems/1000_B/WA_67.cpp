#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  int a[n + 2];
  int diff[n + 1];
  a[0] = 0;
  a[n + 1] = m;
  long long on = 0;
  long long off = 0;
  for (int i = 1; i <= n + 1; i++) {
    if (i != (n + 1)) cin >> a[i];
    diff[i - 1] = a[i] - a[i - 1];
    if ((i - 1) & 1) {
      off += diff[i - 1];
    } else {
      on += diff[i - 1];
    }
  }
  if (on > off) {
    cout << on;
    return 0;
  } else {
    long long finalon = 0;
    long long finaloff = 0;
    for (int i = 0; i <= n; i++) {
      if (diff[i] == 1) {
        if (i & 1) {
          finaloff++;
        } else {
          finalon++;
        }
      } else {
        long long curon = finalon + off, curoff = finaloff + on;
        if (i & 1) {
          curon += -1;
          curoff += 1;
        } else {
          curon += diff[i] - 1;
          curoff += 1 - diff[i];
        }
        if (curon > curoff) {
          cout << curon;
          return 0;
        }
      }
      if (i & 1) {
        off -= diff[i];
      } else {
        on -= diff[i];
      }
    }
  }
}
