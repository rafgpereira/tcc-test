#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  int A[n + 5];
  for (int i = 1; i <= n; i++) cin >> A[i];
  int i, j, diff = 0, idx;
  if (n == 1) {
    cout << max(A[1], m - A[1]) << "\n";
    return 0;
  }
  for (i = 2; i <= n; i += 2) {
    int temp = A[i] - A[i - 1];
    if (temp > diff) {
      diff = temp;
      idx = i;
    }
  }
  long long res = A[1];
  for (i = 1; i <= n; i += 2) {
    if (i + 1 == idx && diff != 1) {
      A[i]++;
      i--;
    } else if (i == 1)
      continue;
    else
      res += (A[i] - A[i - 1]);
  }
  if (i != n + 2) res += (m - A[n]);
  cout << res << "\n";
  return 0;
}
