#include <bits/stdc++.h>
using namespace std;
const int N = 1002;
class cmp {
 public:
  bool operator()(const pair<long long int, long long int> &a,
                  const pair<long long int, long long int> &b) {
    if (a.first == b.first) return a.second > b.second;
    return a.first < b.first;
  }
};
void solve() {
  long long int n, m;
  cin >> n >> m;
  long long int a[n + 2], i;
  a[0] = 0, a[n + 1] = m;
  for (i = 1; i <= n; i++) cin >> a[i];
  long long int s1 = 0, s2 = 0, pre[n + 2], suf[n + 2];
  pre[0] = 0;
  for (i = 1; i <= n + 1; i++) {
    if (i % 2) {
      s1 += (a[i] - a[i - 1]);
    }
    pre[i] = s1;
  }
  if (n % 2)
    i = n + 1;
  else
    i = n;
  if (i == n) suf[n + 1] = 0;
  for (; i >= 1; i--) {
    if (i % 2 == 0) {
      s2 += (a[i] - a[i - 1]);
    }
    suf[i] = s2;
  }
  long long int ans = s1;
  for (i = 1; i <= n; i++) {
    if (i % 2) {
      ans = max(ans, pre[i] - 1 + suf[i + 1]);
      ans = max(ans, pre[i] + suf[i] - 1);
    } else {
      ans = max(ans, pre[i - 1] + 1 + suf[i + 1]);
    }
  }
  cout << ans << endl;
}
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
  cout.tie(NULL);
  ;
  int t = 1;
  while (t--) {
    solve();
  }
  return 0;
}
