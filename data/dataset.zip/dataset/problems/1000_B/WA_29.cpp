#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 20;
int a[maxn];
int ps[maxn][2];
int main() {
  ios_base::sync_with_stdio(0);
  cin.tie(0);
  ;
  int n;
  cin >> n;
  int k;
  cin >> k;
  a[n + 1] = k;
  for (int i = 1; i <= n; i++) {
    cin >> a[i];
  }
  ps[0][0] = 0;
  ps[0][1] = 1;
  for (int i = 1; i <= n + 1; i++) {
    if (i % 2 == 1) {
      ps[i][0] = ps[i - 1][0] + a[i] - a[i - 1];
      ps[i][1] = ps[i - 1][1];
    } else {
      ps[i][1] = ps[i - 1][1] + a[i] - a[i - 1];
      ps[i][0] = ps[i - 1][0];
    }
  }
  int maxx = ps[n + 1][0];
  for (int i = 0; i <= n; i++) {
    if (i == 0) {
      if (a[i] + 1 != a[i + 1]) {
        maxx = max(maxx, ps[n + 1][1] + 1);
      }
    } else {
      if (i % 2 == 1) {
        maxx = max(maxx, ps[i][0] - 1 + ps[n + 1][1] - ps[i][1]);
      } else {
        maxx = max(maxx, ps[i][0] + 1 + ps[n + 1][1] - ps[i][1]);
      }
    }
  }
  cout << maxx << endl;
  return 0;
}
