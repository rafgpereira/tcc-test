#include <bits/stdc++.h>
inline long long read() {
  char c = getchar();
  long long f = 1, num = 0;
  while (c < 48 || c > 57) {
    if (c == '-') f = -1;
    c = getchar();
  }
  while (c >= '0' && c <= '9')
    num = (num << 3) + (num << 1) + (c ^ 48), c = getchar();
  return f * num;
}
int main() {
  int y = 0, ans = 0, maxn = 0, n = read(), m = read();
  for (int i = 0; i < n; i++) {
    int x = read();
    if (n == 2 && x - 1 == y && i == 1) {
      printf("%d\n", m - 1);
      return 0;
    }
    if (i & 1) {
      maxn = maxn > x - y - 1 ? maxn : x - y - 1;
      ("upd maxn to %d\n", maxn);
    } else {
      ans += x - y;
      ("upd ans to %d\n", ans);
    }
    y = x;
  }
  if (n & 1)
    ans += m - y - 1, ("upd ans to %d\n", ans);
  else
    maxn = maxn > m - y - 1 ? maxn : m - y - 1, ("upd maxn to %d\n", maxn);
  printf("%d\n", ans + maxn);
  return 0;
}
