/*Template by hemnath_d(Enlightened by chamow)*/
#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define ld long double
#define vec vector<ll>
#define pll pair<ll,ll>
#define fastread ios_base::sync_with_stdio(false); cin.tie(NULL);
#define pb push_back
#define mp make_pair
#define fx first
#define sx second
#define inf 100000000000000
#define minf -100000000000000

int main()
{
    fastread;
    ll n,m;
    cin>>n>>m;
    vec arr(n+1);
    for(ll i=0;i<n;i++)
    	cin>>arr[i];
    arr[n]=m;
    vec preon(n+1),preoff(n+1);
    preon[0]=arr[0];
    preoff[0]=0;
    bool flag[n+1]={false};
    flag[0]=true;
    for(ll i=1;i<=n;i++)
    {
    	if(i%2)
    	{
    		preoff[i]=preoff[i-1]+(arr[i]-arr[i-1]);
    		preon[i]=preon[i-1];
    		flag[i]=false;
    	}
    	else
    	{
    		preon[i]=preon[i-1]+(arr[i]-arr[i-1]);
    		preoff[i]=preoff[i-1];
    		flag[i]=true;
    	}
    }
    ll prevon=0;
    ll maxi=preon[n];
    for(ll i=0;i<n;i++)
    {
        ll seg;
        //cout<<"at i "<<i<<endl;
    	if(i==0)
    		seg=arr[i];
    	else
    		seg=arr[i]-arr[i-1];
    	if(i%2==0)
    	{
    		// on segment
    		ll on=prevon+seg-1;
    		ll temp=preoff[n]-preoff[i];
    		//cout<<on<<" "<<temp<<endl;
    		on=max(on,maxi);
    		maxi=max(on,maxi);
    	}
    	else
    	{
    		//off segment
    		ll on=prevon+seg-1;
    		ll temp=preon[n]-preon[i];
    		//cout<<on<<" "<<temp<<endl;
    		on=max(on,maxi);
    		maxi=max(on,maxi);
    	}
    	prevon+=preon[i];
    }
    cout<<maxi<<endl;
    return 0;
}