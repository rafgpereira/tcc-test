#include <bits/stdc++.h>
using namespace std;
int main() {
  long long int n, m;
  cin >> n >> m;
  vector<long long int> pos;
  for (long long int i = 0; i < n; i++) {
    long long int cur;
    cin >> cur;
    pos.push_back(cur);
  }
  bool lit = pos.size() % 2 == 0;
  long long int totalLit = 0;
  long long int onTime = 0;
  long long int offTime = 0;
  long long int last = 0;
  for (long long int i = 0; i < n + 1; i++) {
    long long int cur;
    if (i == n) {
      cur = m;
    } else {
      cur = pos[i];
    }
    long long int duration = cur - last;
    if (lit) {
      totalLit += duration;
    }
    lit = !lit;
    last = cur;
  }
  reverse(pos.begin(), pos.end());
  lit = pos.size() % 2 == 0;
  pos.push_back(0);
  long long int answer = totalLit;
  last = m;
  for (long long int i = 0; i < n + 1; i++) {
    long long int duration = last - pos[i];
    if (lit) {
      onTime += duration;
    } else {
      offTime += duration;
    }
    if (duration > 1) {
      if (lit) {
        long long int p1 = totalLit - onTime + offTime + 1;
        long long int p2 = totalLit - onTime + offTime + duration - 1;
        ;
        answer = max(answer, p1);
        answer = max(answer, p2);
      } else {
        long long int p1 = totalLit + offTime - onTime - 1;
        long long int p2 = totalLit + offTime - onTime - (duration - 1);
        ;
        answer = max(answer, p1);
        answer = max(answer, p2);
      }
    }
    lit = !lit;
    last = pos[i];
  };
  cout << answer << endl;
}
