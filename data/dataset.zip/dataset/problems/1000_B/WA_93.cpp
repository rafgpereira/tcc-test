#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  scanf("%d %d", &n, &m);
  vector<int> vc;
  priority_queue<pair<int, pair<int, int> > > pq;
  set<pair<int, pair<int, int> > > st;
  vc.push_back(0);
  for (int i = 0; i < n; i++) {
    int x;
    scanf("%d", &x);
    vc.push_back(x);
  }
  vc.push_back(m);
  for (int i = 2; i < vc.size(); i += 2)
    if (vc[i] - vc[i - 1] > 1) pq.push({vc[i] - vc[i - 1], {i, i - 1}});
  if (pq.size() == 0)
    if (n % 2 || m - vc[vc.size() - 2] <= 1)
      cout << vc[1] - 1 << endl, exit(0);
    else
      cout << m - 1 << endl, exit(0);
  int number2 = vc[pq.top().second.first];
  int number1 = vc[pq.top().second.second];
  if (n % 2)
    cout << number1 + 1 << endl;
  else
    cout << number2 - 1 << endl;
  return 0;
}
