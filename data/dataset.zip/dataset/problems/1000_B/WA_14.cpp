#include <bits/stdc++.h>
using namespace std;
const long long MAXN = 1e5 + 5;
long long n, M, ans, ANSWER;
pair<long long, long long> seg[MAXN];
long long psum1[MAXN];
long long psum2[MAXN];
int main() {
  cin >> n >> M;
  long long last = 0;
  bool H = 1;
  for (long long i = 0; i < n; i++) {
    long long x;
    cin >> x;
    seg[i] = {H, x - last};
    ANSWER += H * (x - last);
    H ^= 1;
    last = x;
  }
  seg[n] = {H, M - last};
  ANSWER += H * (M - last);
  psum1[1] = seg[0].first * seg[0].second;
  for (long long i = 2; i <= n; i++)
    psum1[i] = psum1[i - 1] + (seg[i - 1].first * seg[i - 1].second);
  psum2[n - 1] = (!seg[n].first) * seg[n].second;
  for (long long i = n - 2; ~i; i--)
    psum2[i] = psum2[i + 1] + (!seg[i + 1].first) * seg[i + 1].second;
  for (long long i = 0; i <= n; i++)
    if (seg[i].second > 1)
      ans = max(ans, psum1[i] + psum2[i] + seg[i].second - 1);
  cout << ANSWER << "\n";
  cout << max(ans, ANSWER) << "\n";
}
