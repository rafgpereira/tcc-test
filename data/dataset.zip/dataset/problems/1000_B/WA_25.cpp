#include <bits/stdc++.h>
using namespace std;
int main() {
  int n, m;
  cin >> n >> m;
  vector<int> a;
  a.push_back(0);
  int i, no;
  for (i = 0; i < n; i++) {
    cin >> no;
    a.push_back(no);
  }
  a.push_back(m);
  vector<int> diff;
  int last_off = 0;
  if (n % 2) last_off = 1;
  for (i = 1; i < n + 2; i++) diff.push_back(a[i] - a[i - 1]);
  int max_time = 0, lit_time = 0;
  for (i = 0; i < n + 1; i += 2) max_time += diff[i];
  vector<pair<int, int>> off;
  for (i = 1; i < n + 1; i += 2) off.push_back(make_pair(diff[i], i));
  sort(off.begin(), off.end(), greater<pair<int, int>>());
  int z = off.size();
  int ind = off[0].second;
  if (z > 1 && last_off == 1 && ind == n) {
    ind = off[1].second;
    diff.erase(diff.begin() + ind);
    diff.insert(diff.begin() + ind, 1);
    diff.insert(diff.begin() + ind + 1, off[1].first - 1);
  } else if (last_off == 0) {
    diff.erase(diff.begin() + ind);
    diff.insert(diff.begin() + ind, 1);
    diff.insert(diff.begin() + ind + 1, off[0].first - 1);
  }
  for (i = 0; i < n + 2; i += 2) lit_time += diff[i];
  if (max_time > lit_time)
    cout << max_time << endl;
  else
    cout << lit_time << endl;
  return 0;
}
