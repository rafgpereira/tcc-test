#include <bits/stdc++.h>
using namespace std;
const int maxn = 2e5 + 7;
const int mod = 1e9 + 7;
const double eps = 1e-15;
const double pi = acos(-1);
const int INF = 0x3f3f3f;
long long read() {
  long long c = getchar(), Nig = 1, x = 0;
  while (!isdigit(c) && c != '-') c = getchar();
  if (c == '-') Nig = -1, c = getchar();
  while (isdigit(c)) x = ((x << 1) + (x << 3)) + (c ^ '0'), c = getchar();
  return Nig * x;
}
long long gcd(long long a, long long b) { return b == 0 ? a : gcd(b, a % b); }
int a[maxn];
set<int> s;
int main() {
  int n, m;
  cin >> n >> m;
  for (int i = 1; i <= n; ++i) {
    a[i] = read();
    s.insert(a[i]);
  }
  long long mx = -1;
  s.insert(0);
  s.insert(m);
  for (int i = 1; i <= n; ++i) {
    long long sum1 = 0, sum2 = 0;
    int k = a[i] - 1, p, q;
    int flag = 0;
    if (s.find(k) != s.end()) flag = 1;
    s.insert(k);
    set<int>::iterator it = s.begin();
    while (it != s.end()) {
      p = *it;
      it++;
      if (it == s.end()) break;
      q = *it;
      sum1 += (q - p);
      it++;
    }
    if (!flag) s.erase(k);
    s.insert(a[i] + 1);
    it = s.begin();
    while (it != s.end()) {
      p = *it;
      it++;
      if (it == s.end()) break;
      q = *it;
      sum2 += (q - p);
      it++;
    }
    s.erase(a[i] + 1);
    mx = max(mx, max(sum1, sum2));
  }
  long long sum3 = 0, p, q;
  set<int>::iterator it = s.begin();
  while (it != s.end()) {
    p = *it;
    it++;
    if (it == s.end()) break;
    q = *it;
    sum3 += (q - p);
    it++;
  }
  mx = max(mx, sum3);
  cout << mx << endl;
}
