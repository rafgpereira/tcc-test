#include <bits/stdc++.h>
using namespace std;
const int INF = 0x3f3f3f3f;
long long a[100000 + 5], b[100000 + 5], c[100000 + 5], sumo[100000 + 5],
    sume[100000 + 5];
int main() {
  int i, j, k;
  long long n, m, x = 0;
  cin >> n >> m;
  for (i = 0; i < n; i++) cin >> a[i];
  a[n] = m;
  b[0] = a[0];
  for (i = 1; i <= n; i++) b[i] = a[i] - a[i - 1];
  long long sum = 0, sum2 = b[0], sum1 = 0;
  sume[0] = b[0];
  for (i = 2; i <= n; i += 2) sum2 += b[i], sume[i] = sum2;
  for (i = 1; i <= n; i += 2) sum1 += b[i], sumo[i] = sum1;
  long long maxn = 0;
  for (i = 1; i <= n; i++) {
    if (i % 2 == 0) {
      if (b[i] == 1) continue;
      k = b[i] - 1;
      maxn = max(sume[i] - b[i] + k + sum1 - sumo[i - 1], maxn);
    } else {
      if (b[i] == 1) continue;
      k = b[i] - 1;
      maxn = max(maxn, sume[i - 1] + k + sum1 - sumo[i]);
    }
  }
  if (b[0] == 1) {
    cout << maxn << endl;
    return 0;
  }
  k = b[0] - 1;
  maxn = max(k + sum1, maxn);
  cout << maxn << endl;
}
