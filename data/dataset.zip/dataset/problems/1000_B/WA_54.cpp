#include <bits/stdc++.h>
using namespace std;
long long ans, n, m, a[100005], d, res1, f1[100005], f2[100005];
int main() {
  cin >> n >> m;
  a[n + 1] = m;
  for (int i = 1; i <= n; i++) {
    cin >> a[i];
  }
  if (n % 2 == 1)
    d = 2;
  else
    d = 1;
  for (int i = n; i >= 0; i--) {
    if (d == 1) {
      f1[i] = a[i + 1] - a[i] + f1[i + 1];
      f2[i] = f2[i + 1];
      d = 2;
    } else {
      f2[i] = a[i + 1] - a[i] + f2[i + 1];
      f1[i] = f1[i + 1];
      d = 1;
    }
  }
  ans = f1[0];
  for (int i = 1; i <= n; i++) {
    if (a[i] == m - 1) break;
    if (a[i + 1] - a[i] > 1)
      res1 = f1[i - 1] - f1[i] + a[i + 1] - a[i] - 1 + f2[i + 1];
    else
      res1 = 0;
    ans = max(ans, res1);
  }
  cout << ans;
}
