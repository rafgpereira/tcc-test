#include <bits/stdc++.h>
using namespace std;
int a[100010], b[100010];
int main() {
  ios::sync_with_stdio(false);
  cin.tie(0);
  int n, m, pos, minx = -1;
  long long ans = 0;
  cin >> n >> m;
  for (int i = 1; i <= n; i++) cin >> a[i];
  a[0] = 0;
  a[n + 1] = m;
  for (int i = 1; i <= n + 1; i++) {
    if (i & 1) ans += a[i] - a[i - 1];
    if (a[i] - a[i - 1] > minx) {
      minx = a[i] - a[i - 1];
      pos = i;
    }
  }
  if (minx > 1) {
    b[0] = 0;
    b[n + 2] = m;
    for (int i = 1; i <= n; i++) {
      if (i < pos)
        b[i] = a[i];
      else if (i == pos) {
        if (pos & 1)
          b[i] = a[i] - 1, b[i + 1] = a[i];
        else
          b[i] = a[i - 1] + 1, b[i + 1] = a[i];
      } else
        b[i + 1] = a[i];
    }
    long long t = 0;
    for (int i = 1; i <= n + 2; i++) {
      if (i & 1) t += b[i] - b[i - 1];
    }
    ans = max(ans, t);
  }
  cout << ans;
  return 0;
}
