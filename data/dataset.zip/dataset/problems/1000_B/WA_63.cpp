#include <bits/stdc++.h>
using namespace std;
const int MAXN = 1e5 + 4;
int main() {
  int n, m, ss[MAXN][2], a[MAXN], csum = 0, cstat = 1, sol = 0, lp = 0;
  cin >> n >> m;
  for (int i = 0; i < n; i++) cin >> a[i];
  ss[n][0] = 0;
  ss[n][1] = 0;
  a[n] = m;
  for (int i = n - 1; i >= 0; i--) {
    ss[i][0] = ss[i + 1][1];
    ss[i][1] = ss[i + 1][0] + a[i + 1] - a[i];
  }
  for (int i = 0; i < n; i++) {
    if (cstat == 1)
      sol = max(sol, a[i] - 1 - lp + csum + ss[i][1]);
    else
      sol = max(sol, a[i] - 1 - a[i - 1] + csum + ss[i][0]);
    if (cstat == 1) {
      csum = a[i] - lp;
      lp = a[i + 1];
      cstat = 0;
    } else
      cstat = 1;
  }
  if (cstat == 0)
    sol = max(sol, csum + m - a[n - 1] - 1);
  else
    csum += m - a[n - 1];
  cout << max(sol, csum);
  return 0;
}
