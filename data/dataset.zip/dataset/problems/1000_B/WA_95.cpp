#include <bits/stdc++.h>
#pragma comment(linker, "/STACK:1024000000,1024000000")
using namespace std;
const int maxn = 100020;
struct node {
  unsigned long long st;
  unsigned long long x0;
  unsigned long long x1;
};
node s[maxn];
unsigned long long a[maxn];
unsigned long long t[maxn];
int main() {
  std::ios::sync_with_stdio(false);
  unsigned long long n, m;
  cin >> n >> m;
  int kt = 1;
  a[0] = 0;
  for (int i = 1; i <= n; i++) {
    cin >> a[i];
    t[i] = kt;
    kt = 1 - kt;
  }
  t[n + 1] = kt;
  a[n + 1] = m;
  n = n + 1;
  unsigned long long s0 = 0;
  unsigned long long s1 = 0;
  for (int i = n; i >= 1; i--) {
    if (t[i] == 0) {
      s0 += a[i] - a[i - 1];
    } else {
      s1 += a[i] - a[i - 1];
    }
    s[i - 1].x0 = s0;
    s[i - 1].x1 = s1;
    s[i - 1].st = 1 - t[i];
  }
  s[n].st = 1 - t[n - 1];
  s[n].x0 = 0;
  s[n].x1 = 0;
  unsigned long long mx = s[0].x1;
  for (int i = 1; i <= n; i++) {
    if (a[i] - a[i - 1] <= 1) continue;
    if (s[i].st == 1) {
      unsigned long long tmp = s[i - 1].x1 - s[i].x1;
      mx = max(mx, tmp - 1 + s[i].x0);
    } else {
      unsigned long long tmp = s[i - 1].x0 - s[i].x0;
      mx = max(mx, tmp - 1 + s[i].x0);
    }
  }
  cout << mx << endl;
  return 0;
}
