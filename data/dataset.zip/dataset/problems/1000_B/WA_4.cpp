#include <bits/stdc++.h>
using namespace std;
long long n, M;
long long niz[100010];
int main() {
  ios_base::sync_with_stdio(false);
  cin.tie(0);
  cin >> n >> M;
  for (int i = 1; i <= n; ++i) {
    cin >> niz[i];
  }
  niz[0] = 0;
  niz[n + 1] = M;
  long long razlika = 0;
  long long frazlika = 0;
  long long br, pos = 987654321;
  bool on;
  if (n % 2 == 0) {
    on = true;
  } else {
    on = false;
  }
  for (int i = n; i >= 0; --i) {
    if (!on) {
      razlika += niz[i + 1] - niz[i];
    } else {
      razlika -= niz[i + 1] - niz[i];
    }
    if (on) {
      on = false;
    } else {
      on = true;
    }
    if (razlika > frazlika &&
        ((niz[i + 1] - niz[i] > 1) || (niz[i] - niz[max(i - 1, 0)] > 1))) {
      frazlika = razlika;
      pos = i + 1;
      if (niz[i + 1] - niz[i] == 1) {
        br = niz[i] - 1;
        --pos;
      } else {
        br = niz[i] + 1;
      }
    }
  }
  for (int i = pos; i <= n + 2; ++i) {
    long long tmp = niz[i];
    niz[i] = br;
    br = tmp;
  }
  long long resenje = 0;
  on = true;
  for (int i = 1; i <= n + 2; ++i) {
    if (on) {
      resenje += niz[i] - niz[i - 1];
    }
    if (on) {
      on = false;
    } else {
      on = true;
    }
  }
  cout << resenje << "\n";
  return 0;
}
