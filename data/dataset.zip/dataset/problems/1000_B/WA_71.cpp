#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false);
  int n, m;
  while (cin >> n >> m) {
    vector<int> diff;
    int temp = 0, temp1;
    while (n--) cin >> temp1, diff.push_back(temp1 - temp), temp = temp1;
    diff.push_back(m - temp);
    long long sume = 0, sumo = 0;
    for (int i = 0; i < diff.size(); i++) {
      if (i & 1)
        sumo += diff[i];
      else
        sume += diff[i];
    }
    long long ans = 0;
    for (int i = 0; i < diff.size(); i += 2) {
      if (sume <= sumo) {
        if (diff[i] == 1 && i == diff.size() - 3) {
          ans += sumo;
          break;
        } else if (diff[i] != 1) {
          ans += (diff[i] - 1) + sumo;
          break;
        }
      }
      ans += diff[i];
      sume -= diff[i];
      if (i != diff.size() - 1) sumo -= diff[i + 1];
    }
    cout << ans << endl;
  }
}
