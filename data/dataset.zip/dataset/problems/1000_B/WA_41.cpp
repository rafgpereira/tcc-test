#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n, M;
  cin >> n >> M;
  long long* a = new long long[n];
  for (int i = 0; i < n; i++) {
    cin >> a[i];
  }
  long long ans = 0, p = 0, i;
  bool flag = 0;
  for (i = 0; i < n; i += 2) {
    ans += a[i] - p;
    if (a[i + 1] != a[i] + 1 && !flag) {
      p = a[i] + 1;
      flag = 1;
      i--;
    } else
      p = a[i + 1];
  }
  if (i == n) ans += M - p;
  cout << ans;
  return 0;
}
