#include <bits/stdc++.h>
using namespace std;
const int maxn = 100001;
int a[maxn];
long long sum1[maxn], sum2[maxn];
unordered_set<int> us;
int n, m;
int main() {
  ios::sync_with_stdio(false);
  while (cin >> n >> m) {
    us.clear();
    memset(sum1, 0, sizeof(sum1));
    memset(sum2, 0, sizeof(sum2));
    us.insert(0);
    for (int i = 1; i <= n; i++) {
      cin >> a[i];
      us.insert(a[i]);
    }
    int flag = 1;
    long long pre = 0;
    for (int i = 1; i <= n; i++) {
      if (flag) {
        sum1[i] = sum1[i - 1] + (long long)a[i] - pre;
        sum2[i] = sum2[i - 1];
      } else {
        sum1[i] = sum1[i - 1];
        sum2[i] = sum2[i - 1] + (long long)a[i] - pre;
      }
      pre = a[i];
      if (flag)
        flag = 0;
      else
        flag = 1;
    }
    long long ans = sum1[n];
    flag = 0;
    long long tmp = -1;
    for (int i = 1; i < n; i++) {
      tmp = -1;
      if (us.find(a[i] - 1) == us.end()) {
        tmp = sum1[i] - 1 + sum2[n] - sum2[i];
      }
      if (tmp > ans) {
        flag = 0;
        ans = tmp;
      }
      if (us.find(a[i] + 1) == us.end()) {
        tmp = sum1[i] + a[i + 1] - a[i] - 1 + sum2[n] - sum2[i + 1];
      }
      if (tmp > ans) {
        flag = 1;
        ans = tmp;
      }
    }
    if (flag == 0) ans += (m - a[n]);
    cout << ans << endl;
  }
  return 0;
}
