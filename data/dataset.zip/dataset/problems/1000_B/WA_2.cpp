#include <bits/stdc++.h>
using namespace std;
int main() {
  int T;
  cin >> T;
  while (T--) {
    int n, m;
    cin >> n >> m;
    vector<int> a(n + 2);
    for (int i = 1; i <= n; i++) cin >> a[i];
    a[0] = 0, a[n + 1] = m;
    vector<int> light(n + 2, 0), dark(n + 2, 0);
    for (int i = 1; i <= n + 1; i++) {
      light[i] = light[i - 1], dark[i] = dark[i - 1];
      if (i % 2)
        light[i] += a[i] - a[i - 1];
      else
        dark[i] += a[i] - a[i - 1];
    }
    int ans = light[n + 1];
    for (int i = 1; i <= n + 1; i++) {
      ans =
          max(ans, light[i - 1] + dark[n + 1] - dark[i] + a[i] - a[i - 1] - 1);
    }
    cout << ans << endl;
  }
}
