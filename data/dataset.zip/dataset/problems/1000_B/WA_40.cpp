#include <bits/stdc++.h>
using namespace std;
const int MAX_INT = 0x7fffffff;
const unsigned long long MAX_LL = 9223372036854775807;
int main() {
  unsigned long long n, m, mxsum = 0;
  cin >> n >> m;
  vector<unsigned long long> a(n + 2), p1, p2, p1s, p2s;
  a[0] = 0;
  for (auto i = 1; i < n + 1; i++) cin >> a[i];
  a[n + 1] = m;
  for (auto i = 1; i < n + 2; i++) {
    if (i % 2 == 1) {
      p1.push_back(a[i] - a[i - 1]);
    } else {
      p2.push_back(a[i] - a[i - 1]);
    }
  }
  reverse(p2.begin(), p2.end());
  p1s.push_back(0);
  p2s.push_back(0);
  p1s.push_back(p1[0]);
  p2s.push_back(p2[0]);
  for (auto i = 1; i < p1.size(); i++) {
    p1s.push_back(*p1s.rbegin() + p1[i]);
  }
  for (auto i = 1; i < p2.size(); i++) {
    p2s.push_back(*p2s.rbegin() + p2[i]);
  }
  reverse(p2s.begin(), p2s.end());
  mxsum = *p1s.rbegin();
  for (auto i = 1; i < n + 1; i++) {
    unsigned long long tmpsum = 0;
    if (i % 2 == 1) {
      tmpsum = (a[i] - 1) - a[i - 1];
      if (tmpsum == 0) continue;
      tmpsum += p2s[i - 1];
      tmpsum += p1s[i - 1];
    } else {
      tmpsum = a[i] - (a[i - 1] + 1);
      if (tmpsum == 0) continue;
      tmpsum += p2s[i - 1];
      tmpsum += p1s[i - 1];
    }
    mxsum = max(mxsum, tmpsum);
  }
  cout << mxsum;
  return 0;
}
