#include <bits/stdc++.h>
using namespace std;
int main() {
  long n, m;
  while (cin >> n >> m) {
    vector<long> arr(n + 2);
    long maxtime = 0;
    arr[0] = 0;
    arr[n + 1] = m;
    for (long i = 1; i <= n; i++) {
      cin >> arr[i];
      if (i % 2 == 1) {
        maxtime += (arr[i] - arr[i - 1]);
      }
    }
    if (n % 2 == 0) {
      maxtime += m - arr[n];
    }
    long temp = 0;
    for (long i = 0; i < n + 2; i++) {
      if (i % 2 == 1) {
        temp += arr[i] - arr[i - 1];
      } else if (i != 0) {
        if (arr[i] - arr[i - 1] > 1) {
          maxtime = max(maxtime, m - arr[i] - (maxtime - temp) + temp + arr[i] -
                                     arr[i - 1] - 1);
        }
      }
    }
    cout << maxtime << endl;
  }
  return 0;
}
