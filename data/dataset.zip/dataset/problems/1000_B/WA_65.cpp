/*TUSHAR GUPTA*/
/*Consistency is the Key.*/

#include <bits/stdc++.h>
using namespace std;
#define int long long
#define pb push_back
#define intmax INT_MAX
#define intmin INT_MIN
#define f first
#define ss second
#define endl "\n"
#define rep(i, k, n) for (int i = k; i < n; i++)
#define all(a) a.begin(), a.end()
typedef vector<int> vi;
typedef vector<pair<int, int>> vii;
typedef map<int, int> mii;
typedef map<string, int> msi;
typedef map<char, int> mci;
const long long m = 1e9 + 7;

/*-------------------------------------------------------------------------------------------------------*/
bool prime(int a)
{
    if (a == 1)
    {
        return 0;
    }
    for (int i = 2; i <= round(sqrt(a)); ++i)
    {
        if (a % i == 0)
        {
            return 0;
        }
    }
    return 1;
}
int lcm(int a, int b) { return a / __gcd(a, b) * b; }
int min(int a, int b)
{
    if (a > b)
    {
        return b;
    }
    else
    {
        return a;
    }
}
int max(int a, int b)
{
    if (a > b)
    {
        return a;
    }
    else
    {
        return b;
    }
}
/*-------------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------------*/
void print_dfs(int curr, vector<int> &vis, vector<int> adj[], vector<int> &v)
{
    vis[curr] = 1;
    v.push_back(curr);
    for (auto it : adj[curr])
    {
        if (vis[it] == 0)
        {
            print_dfs(it, vis, adj, v);
        }
    }
}
/*-------------------------------------------------------------------------------------------------------*/

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    // int t;
    // cin >> t;
    // while (t--)
    // {
    int n, m;
    cin >> n >> m;
    vi v;
    int arr[n];
    rep(i, 0, n)
    {
        cin >> arr[i];
    }
    if (arr[0] != 0)
    {
        v.pb(0);
    }
    rep(i, 0, n)
    {
        v.pb(arr[i]);
    }
    if (arr[n - 1] != m)
    {
        v.pb(m);
    }
    int oo = 0, cc = 0;
    vi o(v.size());
    vi c(v.size());
    o[0] = 0;
    c[0] = 0;
    for (int i = 1; i < v.size(); i++)
    {
        if (i % 2 == 0)
        {
            cc += v[i] - v[i - 1];
        }
        else
        {
            oo += v[i] - v[i - 1];
        }
        o[i] = oo;
        c[i] = cc;
    }
    int ans = oo;
    for (int i = 0; i < v.size(); i++)
    {
        //cout << c[i] << " ";
    }
    for (int i = 1; i < v.size() - 1; i++)
    {
        if (i % 2 == 0)
        {
            int x = o[i];
            x += 1;
            int y = c[v.size() - 1] - c[i];
            x += y;
            ans = max(ans, x);
        }
        else
        {
            int x = o[i];
            x -= 1;
            int y = c[v.size() - 1] - c[i];
            x += y;
            ans = max(ans, x);
        }
        //cout << ans << endl;
    }
    cout << ans << endl;
    // }
}