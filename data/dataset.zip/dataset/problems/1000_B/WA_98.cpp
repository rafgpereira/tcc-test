#include <bits/stdc++.h>
using namespace std;
int main() {
  ios_base::sync_with_stdio(false), cin.tie(NULL);
  long long int t = 1, i, j;
  cin >> t;
  while (t--) {
  }
  return 0;
}
