#include <bits/stdc++.h>
using namespace std;
long long calc(vector<long long> &ve) {
  long long res = 0;
  bool state = 1;
  for (int i = 0; i < ve.size() - 1; i++) {
    if (state) {
      res += (ve[i + 1] - ve[i]);
    }
    state = !state;
  }
  return res;
}
int main() {
  ios::sync_with_stdio(false);
  long long n, m;
  cin >> n >> m;
  vector<long long> ve;
  ve.push_back(0);
  for (int i = 0; i < n; i++) {
    long long x;
    cin >> x;
    ve.push_back(x);
  }
  ve.push_back(m);
  long long res = calc(ve);
  for (int i = 1; i < ve.size() - 1; i++) {
    bool ok = 0;
    if (ve[i + 1] - ve[i] != 1) {
      vector<long long> temp;
      temp = ve;
      temp.push_back(ve[i] + 1);
      sort(temp.begin(), temp.end());
      res = max(res, calc(temp));
      ok = 1;
    }
    if (ve[i] - ve[i - 1] != 1) {
      vector<long long> temp;
      temp = ve;
      temp.push_back(ve[i] - 1);
      sort(temp.begin(), temp.end());
      res = max(res, calc(temp));
      ok = 1;
    }
    if (ok) break;
  }
  cout << res << endl;
  return 0;
}
