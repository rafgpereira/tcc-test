#include <bits/stdc++.h>
using namespace std;
long long a[100099], sm, mx, m, sm2, n;
set<long long> s;
int main() {
  cin >> n >> m;
  for (int i = 1; i <= n; i++) cin >> a[i];
  a[n + 1] = m;
  for (int i = 1; i <= n + 1; i += 2) sm += a[i] - a[i - 1];
  mx = sm;
  for (int i = 1; i < n + 1; i += 2) {
    if (a[i] + 1 == a[i + 1]) continue;
    sm2 += a[i] - a[i - 1];
    mx = max(mx, 2 * sm2 + m - a[i] - 1 - sm);
  }
  cout << mx;
  return 0;
}
