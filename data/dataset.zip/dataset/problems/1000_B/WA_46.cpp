#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 10;
const int p = 1;
int n, m, has[maxn], las[maxn], g[maxn];
namespace Tzh {
long long qpow(long long a, long long b) {
  long long sum = 1;
  while (b) {
    if (b & 1) sum = sum * a % p;
    a = a * a % p;
    b >>= 1;
  }
  return sum;
}
void work() {
  cin >> n >> m;
  int flag, last = m, mx = 0, x;
  if (n % 2 == 0)
    flag = 1;
  else
    flag = 0;
  for (int i = 1; i <= n; i++) cin >> g[i];
  for (int i = n; i; i--) {
    has[i] = has[i + 1];
    las[i] = las[i + 1];
    if (flag)
      has[i] += last - g[i];
    else
      las[i] += last - g[i];
    flag ^= 1;
    last = g[i];
  }
  int ans = has[1] + g[1], now = g[1];
  flag = 0;
  last = 0;
  if (g[1] != 1) ans = max(ans, 1 + las[1]);
  for (int i = 1; i <= n; i++) {
    if (g[i] + 1 != g[i + 1] || i == n) {
      if (flag)
        ans = max(ans, now + 1 + las[i]);
      else
        ans = max(ans, now + las[i] - 1);
    }
    now += (g[i] - last) * flag;
    flag ^= 1, last = g[i];
  }
  ans += max(0, mx - 1);
  cout << ans;
  return;
}
}  // namespace Tzh
int main() {
  ios::sync_with_stdio(false);
  Tzh::work();
  return 0;
}
