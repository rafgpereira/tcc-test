#include <bits/stdc++.h>
using namespace std;
long long s[100002], d[100002], a[100002];
int main() {
  std::ios_base::sync_with_stdio(false);
  int n, m;
  cin >> n >> m;
  for (int i = 0; i < n; ++i) cin >> a[i];
  s[0] = a[0];
  s[1] = s[0];
  for (int i = 2; i < n; i += 2) {
    s[i - 1] = s[i - 2];
    s[i] += s[i - 2] + a[i] - a[i - 1];
  }
  int l;
  if (n & 1) {
    l = n - 1;
    d[n - 1] = m - a[n - 1];
  } else {
    l = n - 2;
    d[n - 2] = a[n - 1] - a[n - 2];
  }
  for (int i = l - 2; i >= 0; i -= 2) {
    d[i + 1] = d[i + 2];
    d[i] += d[i + 2] + a[i + 1] - a[i];
  }
  long long mx = s[n - 1];
  if (!(n & 1)) mx += m - a[n - 1];
  if (a[0] - 1 > 0) mx = max(mx, a[0] - 1 + d[0]);
  for (int i = 1; i < n; ++i) {
    if (i & 1) {
      if (a[i - 1] + 1 < a[i])
        mx = max(mx, s[i - 1] + a[i] - a[i - 1] - 1 + d[i]);
    } else {
      if (a[i] - 1 > a[i - 1])
        mx = max(mx, s[i - 1] + a[i] - a[i - 1] - 1 + d[i]);
    }
  }
  if (n & 1) {
    if (a[n - 1] + 1 < m) mx = max(mx, s[n - 1] + m - a[n - 1] - 1);
  }
  cout << mx << endl;
  return 0;
}
