#include<bits/stdc++.h>

#define hell                         1000000007
#define sll(x)                      scanf("%lld",&x)
#define lcm(a,b)                     (a*b)/__gcd(a,b)
#define ll                           long long
#define vll                          vector<ll>
#define vi                           vector<int>
#define pll                          vector< pair<ll,ll> >
#define pb                           push_back
#define mp                           make_pair
#define all(v)                       v.begin(),v.end()
#define lbnd                         lower_bound
#define ubnd                         upper_bound
#define bs                           binary_search
#define F                            first
#define S                            second
#define rep(i,a,b)                   for(i=a;i<b;i++)
#define parr(a,n)                    for(i=0;i<n;i++) cout<<a[i]<<" ";cout<<endl;
#define pcont(a)                     for(auto i:a) cout<<i<<" ";cout<<endl;
#define ret(x)                       return cout<<x,0;
#define dbg(x)                       cerr << #x << " is " << x << endl;
#define endl                           '\n'

using namespace std;
ll mm[1000002];
int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);cout.tie(NULL);

    ll i,j,n,t=1,k=0,cnt=0,mini=LLONG_MAX,maxi=LLONG_MIN,ans=0;
    ll m;
    cin>>n>>m;
    vll v;
    v.pb(0);
    rep(i,0,n)
    {
        cin>>j;
        v.pb(j);
    }
    ll on[n+3]={0},off[n+3]={0};
    v.pb(m);
    rep(i,1,n+2)
    {
        if(i%2==1)
            on[i]=on[i-1]+v[i]-v[i-1],off[i]=off[i-1];
        else
            on[i]=on[i-1],off[i]=off[i-1]+v[i]-v[i-1];
    }
    rep(i,1,n+1)
    {
        maxi=max(on[i]-on[0]+on[n+1]-on[i],maxi);
        if(v[i]>1)
        {
            if(i%2==1)
                maxi=max(maxi,on[i]-on[0]-1+off[n+1]-off[i]);
            else maxi=max(maxi,on[i]-on[0]+off[n+1]-off[i]+1);
        }
        if(v[i]<m)
        {
            if(i%2==1)
                maxi=max(maxi,on[i]-on[0]+off[n+1]-off[i]-1);
            else maxi=max(maxi,on[i]-on[0]+off[n+1]-off[i]+1);
        }
    }
    ret(maxi)
    return 0;
}
