#include <bits/stdc++.h>
using namespace std;
const int N = 100010;
int a[N];
int n;
int s1[N], s2[N];
int main() {
  int T;
  cin >> T;
  while (T--) {
    int n, m;
    cin >> n >> m;
    for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
    a[++n] = m;
    s1[n] = s2[n] = 0;
    for (int i = n - 1; i >= 0; i--) {
      s1[i] = s1[i + 1];
      s2[i] = s2[i + 1];
      if (i % 2 == 0) {
        s1[i] += a[i + 1] - a[i];
      } else {
        s2[i] += a[i + 1] - a[i];
      }
    }
    int res = s1[0];
    for (int i = n - 1; i >= 0; i--) {
      int t = a[i + 1] - a[i];
      if (t == 1) continue;
      res = max(res, s2[i + 1] + s1[0] - s1[i] + t - 1);
    }
    cout << res << endl;
  }
  return 0;
}
