#include <bits/stdc++.h>
using namespace std;
int main() {
  long long n, m;
  cin >> n >> m;
  vector<long long> v, v1, v2;
  long long i, a;
  for (i = 0; i < n; i++) {
    cin >> a;
    v.push_back(a);
    v1.push_back(a);
    v2.push_back(a);
  }
  long long t = 0, prev = 0, max1 = 0;
  for (i = 0; i < n; i += 2) {
    t += v[i] - prev;
    if (i + 1 < n) prev = v[i + 1];
  }
  if (n % 2 == 0) {
    t += m - v[n - 1];
  }
  max1 = t;
  t = 0;
  prev = 0;
  long long maxd = 0, maxp = 0;
  for (i = 0; i < n; i += 2) {
    if (v[i + 1] - v[i] > maxd) {
      maxd = v[i + 1] - v[i];
      maxp = i;
    }
  }
  v.push_back(v[maxp] + 1);
  sort(v.begin(), v.end());
  prev = 0;
  for (i = 0; i < v.size(); i += 2) {
    t += v[i] - prev;
    if (i + 1 < n) prev = v[i + 1];
  }
  if (v.size() % 2 == 0) {
    t += m - v[v.size() - 1];
  }
  if (t > max1) max1 = t;
  if (v1[0] > 1) {
    t = 0;
    v1.push_back(v1[0] - 1);
    sort(v1.begin(), v1.end());
    prev = 0;
    for (i = 0; i < v1.size(); i += 2) {
      t += v1[i] - prev;
      if (i + 1 < n) prev = v1[i + 1];
    }
    if (v1.size() % 2 == 0) {
      t += m - v[v.size() - 1];
    }
    if (t > max1) max1 = t;
  }
  if (v2[v2.size() - 1] < m - 1) {
    t = 0;
    prev = 0;
    v2.push_back(v2[v2.size() - 1] + 1);
    sort(v2.begin(), v2.end());
    for (i = 0; i < v2.size(); i += 2) {
      t += v2[i] - prev;
      if (i + 1 < n) prev = v2[i + 1];
    }
    if (v2.size() % 2 == 0) {
      t += m - v[v.size() - 1];
    }
    if (t > max1) max1 = t;
  }
  cout << max1 << endl;
  return 0;
}
