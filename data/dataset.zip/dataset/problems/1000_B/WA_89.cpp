#include <bits/stdc++.h>
using namespace std;
const double pi = acos(-1.);
const long long mod = 1000000007;
int gcd(int a, int b) {
  if (b == 0) return a;
  return gcd(b, a % b);
}
long long lcm(int a, int b) {
  return ((long long)a * (long long)b) / gcd(a, b);
}
inline void prep() {
  cin.tie(0);
  cin.sync_with_stdio(0);
};
int main() {
  prep();
  int n, m;
  cin >> n >> m;
  vector<int> lst;
  lst.push_back(0);
  for (int i = 0; i < n; i++) {
    int num;
    cin >> num;
    lst.push_back(num);
  }
  lst.push_back(m);
  int bigdif = -1;
  int bigdif_on = -1;
  int place;
  int place2;
  bool off = false;
  long long bef = 0;
  for (int i = 0; i < lst.size() - 1; i++) {
    if (lst[i + 1] - lst[i] > bigdif && off) {
      bigdif = lst[i + 1] - lst[i];
      place = i;
    }
    if (lst[i + 1] - lst[i] > bigdif_on && !off) {
      bigdif_on = lst[i + 1] - lst[i];
      place2 = i;
    }
    if (!off) {
      bef += lst[i + 1] - lst[i];
    }
    off = !off;
  }
  long long now = 0;
  vector<int> newlst = lst;
  if (bigdif != 1) {
    newlst.insert(newlst.begin() + place + 1, lst[place] + 1);
    bool off = false;
    for (int i = 0; i < newlst.size() - 1; i++) {
      if (!off) {
        now += newlst[i + 1] - newlst[i];
      }
      off = !off;
    }
    bef = max(bef, now);
  }
  newlst = lst;
  now = 0;
  if (bigdif_on != 1) {
    newlst.insert(newlst.begin() + place2 + 1, lst[place2 + 1] - 1);
    bool off = false;
    for (int i = 0; i < newlst.size() - 1; i++) {
      if (!off) {
        now += newlst[i + 1] - newlst[i];
      }
      off = !off;
    }
    bef = max(bef, now);
  }
  cout << bef;
  return 0;
}
